[TOC]

#  pf

## property

```
Option Explicit

Private logger_ As cls_logger
Private error_manager_ As cls_error_handler
'Private otime_ As New cls_timer
'

Public Sub reset_all()
    Set error_manager_ = Nothing
    Set logger_ = Nothing
    'Set otime_ = Nothing
End Sub

Property Get logger() As cls_logger
    If logger_ Is Nothing Then
        Set logger_ = New cls_logger
    End If
    Set logger = logger_
End Property

Property Get error_manager() As cls_error_handler
    If error_manager_ Is Nothing Then
        Set error_manager_ = New cls_error_handler
    End If
    Set error_manager = error_manager_
End Property
```
## tools 

```
Function fct_locate_ij_date_bmf(tab_bmf As Variant, date_input As String) As Integer

    Dim dico_bmf_ij_date    As Dictionary
    Dim j                   As Integer
    Dim i                   As Integer
    Dim i_date_var          As Integer
    Dim j_date_var          As Integer
    Dim locate_ij_date      As String

    '--------------------------------------------------
    'Récuperation n° de colonne de la date selectionnée
    '--------------------------------------------------
    Set dico_bmf_ij_date = New Dictionary
    For j = LBound(tab_bmf, 2) To UBound(tab_bmf, 2)
        For i = LBound(tab_bmf, 1) + 1 To UBound(tab_bmf, 1)
            If tab_bmf(1, j) = date_input Then
                i_date_var = i
                j_date_var = j
                locate_ij_date = i_date_var & ":" & j_date_var
                If Not dico_bmf_ij_date.Exists(locate_ij_date) Then
                    dico_bmf_ij_date.Add locate_ij_date, "find"
                End If
                Exit For
            End If
        Next i
    Next j
    
    If Not dico_bmf_ij_date.count > 0 Then
        MsgBox "date : " & date_input & vbCrLf & " doesn't exist in BMF cube in the file :", vbInformation
    End If

    fct_locate_ij_date_bmf = j_date_var

End Function

Function fct_display_result(tab_result As Variant, AfterTitle As Boolean)

    Dim ws_output                       As Worksheet
    Dim tab_title                       As Variant
    Dim last_row                        As Integer
    
    With ws_buffer
        If AfterTitle = True Then
            .Range("A2").Resize(UBound(tab_result, 1), UBound(tab_result, 2)) = tab_result
        Else
            last_row = .Cells(Rows.count, "A").End(xlUp).Offset(1, 0).row
            .Range("A" & last_row).Resize(UBound(tab_result, 1), UBound(tab_result, 2)) = tab_result
        
        End If
    End With

End Function

Public Function GetRange(ByVal sListName As String) As String

    Dim wb          As Workbook
    Dim ws          As Worksheet
    
    Set wb = ThisWorkbook
    
    For Each ws In wb.Sheets
        If ws.name = sListName Then
            GetRange = "[" & ws.name & "$" & "]"
            Exit Function
        End If
    Next ws

End Function

Sub Optimize_VBA(isOn As Boolean)
    Application.EnableEvents = Not (isOn)
    Application.ScreenUpdating = Not (isOn)
    Application.DisplayAlerts = Not (isOn)
End Sub

Function fct_col_letter(ColumnNumber As Long) As String
    Dim n As Long
    Dim c As Byte
    Dim s As String

    n = ColumnNumber
    Do
        c = ((n - 1) Mod 26)
        s = Chr(c + 65) & s
        n = (n - c) \ 26
    Loop While n > 0
    fct_col_letter = s
End Function

Function fct_get_key(Dic As Dictionary, str_item As String) As String

    Dim key As Variant
    For Each key In Dic.Keys
        If Dic.item(key) = str_item Then
            fct_get_key = CStr(key)
            Exit Function
        End If
    Next
    
End Function

Public Function fct_SortDict_ByValue(dict As Object _
                    , Optional sortorder As XlSortOrder = xlAscending) As Object
    
    Dim item As Variant
    Dim arrayList As Object
    Dim DictTemp As Object
    Dim key As Variant, value As Variant, coll As Collection
    
    On Error GoTo eh
    
    Set arrayList = CreateObject("System.Collections.ArrayList")
    Set DictTemp = CreateObject("Scripting.Dictionary")
   
    For Each key In dict
    
        value = dict(key)
        
        If DictTemp.Exists(value) = False Then

            Set coll = New Collection
            DictTemp.Add value, coll
            arrayList.Add value
            
        End If
        
        DictTemp(value).Add key
    Next key
    
    arrayList.Sort

    If sortorder = xlDescending Then
        arrayList.Reverse
    End If
    
    dict.RemoveAll
    
    For Each value In arrayList
        Set coll = DictTemp(value)
        For Each item In coll
            dict.Add item, value
        Next item
    Next value
    
    Set arrayList = Nothing
    Set fct_SortDict_ByValue = dict
        
Done:
    Exit Function
eh:
    If Err.Number = 450 Then
        Err.Raise vbObjectError + 100, "fct_SortDict_ByValue" _
                , "Cannot sort the dictionary if the value is an object"
    End If
    
End Function

Public Function fct_is_string(ByVal v As Variant) As Boolean
    Dim s As String
    On Error Resume Next
    s = v
    If Err.Number = 0 Then
        If Not IsNumeric(v) Then fct_is_string = True
    End If
End Function

Function fct_col_offset_date(ancre_range As Range, date_begin As String)

    Dim ancre_range_date            As Range
    Dim ancre_range_date_address    As String
    Dim column_result               As Long

    Set ancre_range_date = ws_reporting.Range("A1:ZZ100").Find(CDate(date_begin)) 'string for .find
    If Not ancre_range_date Is Nothing Then
        ancre_range_date_address = ancre_range_date.Address
    Else
        MsgBox " impossible de trouver : " & date_begin & " dans la feuille : " & ws_reporting.name, vbInformation
    End If
    column_result = ws_reporting.[rng_date_begin].Column - ancre_range.Column
    fct_col_offset_date = column_result
    
End Function

Function fct_get_last_day(n_ante As Long) As String

    Dim d_year      As Date
    Dim d_month     As Date
    Dim get_date    As Date
    Dim str_date    As String

    d_year = Year(Now)
    d_month = Month(Now)

    get_date = DateSerial(d_year, d_month - n_ante, 0)
    'fct_get_last_day = get_date
    str_date = Replace(CStr(get_date), "/", "-")
    fct_get_last_day = Right(str_date, 4) & "-" & Mid(str_date, 4, 2) & "-" & Left(str_date, 2)
    
End Function

Function fct_get_date(n_ante As Long, var_date As Date) As String

    Dim d_year      As Date
    Dim d_month     As Date
    Dim get_date    As Date
    Dim str_date    As String

    d_year = Year(var_date)
    d_month = Month(var_date)

    get_date = DateSerial(d_year, d_month + n_ante, 0)
    str_date = Replace(CStr(get_date), "/", "-")
    fct_get_date = Right(str_date, 4) & "-" & Mid(str_date, 4, 2) & "-" & Left(str_date, 2)
    
End Function

Function file_exist(FilePath As String) As Boolean
    Dim test_str As String
    On Error Resume Next
    test_str = Dir(FilePath)
    On Error GoTo 0
    If test_str = "" Then
        file_exist = False
    Else
        file_exist = True
    End If
End Function

Public Function path_exists(pname) As Boolean

    If Dir(pname, vbDirectory) = "" Or pname = "" Then
        path_exists = False
    Else
        path_exists = (GetAttr(pname) And vbDirectory) = vbDirectory
    End If
    
End Function

Public Function folder_exists(ByVal str_folder_path As String, Optional ByVal print_error_message As Boolean) As Boolean
    Dim fso As New FileSystemObject
    
    folder_exists = True
    
    If Not fso.FolderExists(str_folder_path) Then
        If print_error_message Then MsgBox "Folder '" & str_folder_path & "' not found", vbCritical
        folder_exists = False
    End If
End Function

Function is_workbook_open(name As String) As Boolean

    Dim xWb As Workbook
    On Error Resume Next
    Set xWb = Application.Workbooks.item(name)
    is_workbook_open = (Not xWb Is Nothing)
    On Error GoTo 0
    
End Function

Public Function sheet_exists(sheetToFind As String, Optional InWorkbook As Workbook) As Boolean

    Dim sheet As Object
    If InWorkbook Is Nothing Then Set InWorkbook = ThisWorkbook
    For Each sheet In InWorkbook.Sheets
        If sheetToFind = sheet.name Then
            sheet_exists = True
            Exit Function
        End If
    Next sheet
    sheet_exists = False
    
End Function

Function fct_purgato(WsNameTemp As String, StartCellTemp As String, NumMethod As Byte)

    Dim rng_data    As Range
    Dim last_col    As Long
    Dim last_row    As Long
    
    With ActiveWorkbook.Worksheets(WsNameTemp)
        Select Case NumMethod
            Case 1
                Set rng_data = .Range(.Range(StartCellTemp), .Range(StartCellTemp).End(xlDown))
                Set rng_data = .Range(rng_data, rng_data.End(xlToRight))
                rng_data.Clear
                Set rng_data = Nothing
            Case 2
                last_col = .Cells(.Range(StartCellTemp).row, .Columns.count).End(xlToLeft).Column
                last_row = .Cells(.Rows.count, .Range(StartCellTemp).Column).End(xlUp).row
                .Range(StartCellTemp & ":" & fct_col_letter(last_col) & last_row).Clear
            Case 3
                last_col = .Range(StartCellTemp).Offset(-1, 0).End(xlToRight).Column
                last_row = .Range(StartCellTemp).Offset(0, -2).End(xlDown).row
                .Range(.Range(StartCellTemp), .Cells(last_row, last_col)).ClearContents
        End Select
    End With
    
End Function

Function fct_debug_dictionary(var_dictionary As Dictionary)

    Dim key As Variant
    For Each key In var_dictionary.Keys
        Debug.Print key, var_dictionary(key)
    Next key

End Function

Function fct_Transpose_StringArray(array_input As Variant) As String()
    Dim x       As Long
    Dim y       As Long
    Dim max_i   As Long
    Dim min_i   As Long
    Dim max_j   As Long
    Dim min_y   As Long
    
    Dim arr_temp() As String
    
    max_i = UBound(array_input, 1)
    min_i = LBound(array_input, 1)
    max_j = UBound(array_input, 2)
    min_y = LBound(array_input, 2)
    
    ReDim arr_temp(min_y To max_j, min_i To max_i)
    
    For x = min_i To max_i
        For y = min_y To max_j
            If Not IsNull(array_input(x, y)) Then
                arr_temp(y, x) = array_input(x, y)
            End If
        Next y
    Next x
    
    fct_Transpose_StringArray = arr_temp
    
End Function

Function get_ut() As String
    get_ut = LCase(Environ("username"))
End Function

Function TransposeArray(inputArray As Variant) As Variant

    Dim tmp() As Variant
    ReDim tmp(LBound(inputArray, 2) To UBound(inputArray, 2), LBound(inputArray, 1) To UBound(inputArray, 1))
    Dim i As Long
    Dim j As Long
    
    For i = LBound(inputArray, 2) To UBound(inputArray, 2)
        For j = LBound(inputArray, 1) To UBound(inputArray, 1)
            If IsNull(inputArray(j, i)) Then
                tmp(i, j) = ""
            Else
                tmp(i, j) = inputArray(j, i)
            End If
        Next j
    Next i
    TransposeArray = tmp
    
End Function

Function getFilePath() As String
    With Application.FileDialog(msoFileDialogOpen)
        .AllowMultiSelect = False
        .Show
        getFilePath = .SelectedItems(1)
    End With
End Function

Function getSaveLocationwithPopUp() As String
    With Application.FileDialog(msoFileDialogSaveAs)
        .Show
        getSaveLocationwithPopUp = .SelectedItems(1)
    End With
End Function

Private Function DictionaryFromArray(arr) As Dictionary

    Dim val
    Set DictionaryFromArray = New Dictionary
    For Each val In arr
        DictionaryFromArray.Add val, Nothing
    Next

End Function

Public Function fct_redim_preserve(MyArray As Variant, nNewFirstUBound As Long, nNewLastUBound As Long) As Variant

    Dim nOldFirstUBound, nOldLastUBound, nOldFirstLBound, nOldLastLBound As Long
    Dim i As Long
    Dim j As Long
    Dim TempArray() As Variant
    
    fct_redim_preserve = False
    
    If Not IsArray(MyArray) Then MsgBox "You didn't pass the function an array.", vbCritical, "No Array Detected": End
    
    nOldFirstUBound = UBound(MyArray, 1): nOldLastUBound = UBound(MyArray, 2)
    nOldFirstLBound = LBound(MyArray, 1): nOldLastLBound = LBound(MyArray, 2)
    
    ReDim TempArray(nOldFirstLBound To nNewFirstUBound, nOldLastLBound To nNewLastUBound)
    For i = LBound(MyArray, 1) To nNewFirstUBound
        For j = LBound(MyArray, 2) To nNewLastUBound
            If nOldFirstUBound >= i And nOldLastUBound >= j Then
                TempArray(i, j) = MyArray(i, j)
            End If
        Next
    Next
 
    If IsArray(TempArray) Then fct_redim_preserve = TempArray
End Function


Sub Get_path()
    Dim chemin As String
    On Error GoTo errorhandler
    With Application.FileDialog(msoFileDialogFilePicker)
        .InitialFileName = ""
        .Title = "Select a file "
        .Show
        If .SelectedItems.count = 0 Then
            'MsgBox "Canceled"
        Else
            MsgBox .SelectedItems(1), vbInformation
            chemin = Application.FileDialog(msoFileDialogFolderPicker).SelectedItems(1)
            uda_config.[rng_bilan_liq] = chemin
        End If
    End With

Exit Sub
errorhandler:
        MsgBox Err.Description, vbCritical
End Sub
```

## log error

```
Public Enum CustomError
    CustomError1 = vbObjectError + 42
    CustomError2 = vbObjectError + 43
    CustomError3 = vbObjectError + 44
End Enum

Public Sub CustomErrorHandler(Err As Object, Erl As Integer)

    Dim msg_error As String
    
    Select Case Err.Number
        Case CustomError.CustomError1
            msg_error = "Custom Error Message 1"
            MsgBox msg_error, vbExclamation
        
        Case CustomError.CustomError2
            msg_error = "Custom Error Message 2"
            MsgBox msg_error, vbExclamation
            
        Case CustomError.CustomError3
            msg_error = "Custom Error Message 3"
            MsgBox msg_error, vbExclamation
        
        Case Else
            Select Case Erl
                Case 1
                    msg_error = "Impossible de retrouver dans le cube BMF le champ suivant : " & cst_field_bmf_998
                    MsgBox msg_error, vbInformation
                Case 2
                    msg_error = "Impossible de retrouver dans le cube BMF le champ suivant : " & cst_field_bmf_122
                    MsgBox msg_error, vbInformation
                Case 3
                    msg_error = "Impossible de retrouver dans le cube BMF le champ suivant : " & cst_field_bmf_876
                    MsgBox msg_error, vbInformation
                Case Else
                    MsgBox "Unexpected Error: " & Err.Number & "- " & Err.Description, vbCritical
            End Select
    End Select
    
    Call fct_LogError(err_custom:=True, err_msg:=msg_error)
End Sub


Sub show_LogFile()

    Dim sLogFile As String: sLogFile = ThisWorkbook.path & Application.PathSeparator & "LogErrors.txt"
    
    On Error GoTo log_error
    Shell "notepad.exe " & sLogFile, vbNormalFocus
    
exit_error:
    On Error Resume Next
    Exit Sub
log_error:
    MsgBox fct_LogError(err_custom:=False, sModule:="MyModule", sProc:="ShowLogFile", Err:=Err), vbExclamation, "Error No " & Err.Number
    Resume exit_error

End Sub

Public Function fct_LogError(err_custom As Boolean, Optional ByVal err_msg As String, _
                    Optional ByVal sModule As String, Optional ByVal sProc As String, Optional Err As ErrObject, Optional err_plus As String) As String

    Dim sLogFile    As String: sLogFile = ThisWorkbook.path & Application.PathSeparator & "LogErrors.txt"
    Dim sLogTxt     As String
    Dim lFile       As Long
    
    If err_custom = True Then
        sLogTxt = "Error Caught :" & vbCrLf & err_msg
    Else
        sLogTxt = "Error Not Caught :" & vbCrLf & sModule & "|" & sProc & "|" & "Err " & Err.Number & "|" & Err.Description & "|" & err_plus
    End If
    
    On Error Resume Next
    lFile = FreeFile
    
    Open sLogFile For Append As lFile
    Print #lFile, Format$(Now(), "yy.mm.dd hh:mm:ss") & ";" & Environ("UserName") & ";"; sLogTxt

    Close lFile

    fct_LogError = sLogTxt
    
End Function


'Non utilisé
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Sub add_to_text_file(ByVal Content As String, ByVal path As String)

    Dim fso As New FileSystemObject
    Dim ts As TextStream
    
    Set ts = fso.OpenTextFile(path, ForAppending)
    ts.WriteLine Content
    ts.Close
    
    Set ts = Nothing
    Set fso = Nothing

End Sub

Sub save_new_text(ByVal Content As String, ByVal path As String)

    Dim fso As New FileSystemObject
    Dim file As Object
    
    Set file = fso.CreateTextFile(path)
    file.WriteLine Content
    file.Close
    
    Set fso = Nothing
    Set file = Nothing

End Sub

Public Sub log_content(ByVal Content As String, Optional header As Boolean, Optional log_ut As Boolean)

    Dim fso As New FileSystemObject
    Dim logs As String
    Dim path As String
   
    On Error GoTo errorhandler

    path = ThisWorkbook.FullName & "\.."
    
    If Not header Then Application.StatusBar = Content
    
    If header Then
        logs = "--------------------------- " & Content & " ---------------------------"
    Else
        If log_ut Then
            logs = Now() & ";" & Environ("UserName") & ";" & Content
        Else
            logs = Content
        End If
    End If
    
    If Not fso.FileExists(path & "\log.txt") Then
        Call save_new_text(logs, path & "\log.txt")
    Else
        Call add_to_text_file(logs, path & "\log.txt")
    End If
    
errorhandler:

End Sub

```

## find excel

```
Function fct_DictMaquette_date_projections(code_aggregat As String, bool_Get_TypePerimetreGrannulaire As Boolean, TemplateLabel As String) As Dictionary

    Dim find_current            As Range
    Dim find_CodeAggregat       As Range
    Dim DictTempMaquette        As New Dictionary
    Dim first_address           As String
    Dim date_maquette           As String
    Dim last_row                As Integer
    Dim last_col                As Integer
    Dim col_current             As Integer
    Dim j                       As Integer
    Dim CodeAggregat_NumRow     As Integer
    Dim row_title               As Integer
    Dim nb_date                 As Integer
    Dim numero_row              As Integer
    Dim TypePerimetre_NumRow    As Integer
     
    With ws_maquette
        last_row = .UsedRange.Rows.count
        last_col = .UsedRange.Columns.count
        
        'Recherche ligne Code Aggregat
        Set find_CodeAggregat = .Range("A1:A" & last_row).Find(What:=code_aggregat, LookAt:=xlWhole, SearchOrder:=xlByColumns, MatchCase:=True)
        CodeAggregat_NumRow = .Range(find_CodeAggregat.Address).row
        
        'Récuperer le montant somme ou grannulaire
        If bool_Get_TypePerimetreGrannulaire = True Then
            'Recherche Type Périmètre associé au Code Aggregat
            Set find_CodeAggregat = .Cells.Find(TemplateLabel, After:=.Range("C" & CodeAggregat_NumRow), SearchDirection:=xlNext)
            TypePerimetre_NumRow = .Range(find_CodeAggregat.Address).row
            numero_row = TypePerimetre_NumRow
        Else
            numero_row = CodeAggregat_NumRow
        End If
    
        'Recherche de la ligne des titres de la maquette contenant les dates
        Set find_current = .Cells.Find(What:=cst_repere_RowDateMaquette, LookAt:=xlWhole, SearchOrder:=xlRows, MatchCase:=True)
        first_address = find_current.Address
        row_title = .Range(find_current.Address).row
        col_current = .Range(find_current.Address).Column
    
        nb_date = 1
        
        'On ne récupere pas la date d'ouverture que les dates projections (j=6)
        For j = 6 To last_col
            If Len(.Cells(row_title, j)) = 10 And IsDate(.Cells(row_title, j)) Then
            
                'On convertit les dates en format BMF pour correspondance avec les dates projections
                date_maquette = Format(Application.WorkDay(Application.EoMonth(CDate(.Cells(row_title, j)), 0) - 7, 5), "DD/MM/YYYY")
                
                If Not DictTempMaquette.Exists(date_maquette) Then
                    'Somme+Levées+Tombées+RA
                    DictTempMaquette.Add date_maquette, nb_date & "__" & .Cells(numero_row, j) _
                    & "__" & fct_range_NotEmpty(.Cells(numero_row, j - 4)) _
                    & "__" & fct_range_NotEmpty(.Cells(numero_row, j - 3)) _
                    & "__" & fct_range_NotEmpty(.Cells(numero_row, j - 2))
                    nb_date = nb_date + 1
                End If
                
            End If
        Next j
        
        'Call fct_debug_dictionary(DictTempMaquette)
           
    End With
     
    Set fct_DictMaquette_date_projections = DictTempMaquette
    Set DictTempMaquette = Nothing

End Function

```

## map

```
Function fct_dict_ParamMapping() As Dictionary

    Dim my_tab_mapping      As Variant
    Dim DictTemp_mapping    As Dictionary
    Dim i                   As Integer
    Dim str_split           As String
    Dim str_key             As String
    Dim str_value           As String
    
    str_split = "__"
    Set DictTemp_mapping = New Dictionary
    my_tab_mapping = ws_mapping.Range("rng_param_mapping").CurrentRegion
    
    For i = LBound(my_tab_mapping, 1) + 1 To UBound(my_tab_mapping, 1)
        str_key = Trim(my_tab_mapping(i, 1)) & str_split & Trim(my_tab_mapping(i, 2)) & str_split & Trim(my_tab_mapping(i, 4)) & str_split & Trim(my_tab_mapping(i, 5)) _
         & str_split & Trim(my_tab_mapping(i, 6)) & str_split & Trim(my_tab_mapping(i, 7)) & str_split & Trim(my_tab_mapping(i, 8)) _
         & str_split & Trim(my_tab_mapping(i, 9)) & str_split & Trim(my_tab_mapping(i, 10)) & str_split & Trim(my_tab_mapping(i, 11))
         
         
        str_value = Trim(my_tab_mapping(i, 3))
    
        If Not DictTemp_mapping.Exists(str_key) Then
            DictTemp_mapping.Add Trim(str_key), str_value
        ElseIf DictTemp_mapping.Exists(str_key) Then
                DictTemp_mapping.item(str_key) = DictTemp_mapping.item(str_key) & "," & str_value
        End If
    Next i
    
    Set fct_dict_ParamMapping = DictTemp_mapping
    Set DictTemp_mapping = Nothing

End Function

Function fct_dict_DateCodeNewDeal_BucketCodeBMF() As Dictionary

    Dim my_tab_mapping      As Variant
    Dim DictTemp_mapping    As Dictionary
    Dim i                   As Integer

    Set DictTemp_mapping = New Dictionary
    my_tab_mapping = ws_mapping.Range("rng_param_date_projection").CurrentRegion
    
    For i = LBound(my_tab_mapping, 1) + 1 To UBound(my_tab_mapping, 1)
        If Not DictTemp_mapping.Exists(my_tab_mapping(i, 1)) Then
            DictTemp_mapping.Add my_tab_mapping(i, 1), CStr(my_tab_mapping(i, 2))
        End If
    Next i
    
    Set fct_dict_DateCodeNewDeal_BucketCodeBMF = DictTemp_mapping
    'Call fct_debug_dictionary(DictTemp_mapping)
    Set DictTemp_mapping = Nothing

End Function

Function fct_GetKey_dictionary(Dic As Dictionary, str_item As Variant) As String

    Dim key As Variant
    
    For Each key In Dic.Keys
        If Dic.item(key) = str_item Then
            fct_GetKey_dictionary = CStr(key)
            Exit Function
        End If
    Next
    
    If fct_GetKey_dictionary = "" Then fct_GetKey_dictionary = "bucket code : " & str_item & " not found"
       
End Function

Function fct_dict_MappingBMF_nested() As Dictionary

    'ex:
        'LIABDATLT
        'Section (level 2) - Label FR - BMF| 1319 : Ressources Marché LT
        'PCAL - Code - BMF| 1033 : PREMENNCL,PREMEVGLT

    Dim my_tab_mapping          As Variant
    Dim DictTemp_MappingBMF     As Dictionary
    Dim i                       As Integer
    Dim label_row_mapping       As Integer
    Dim col_code_aggregat       As Integer
    Dim temp_code_rubrique      As String

    Set DictTemp_MappingBMF = New Dictionary

    With ws_mapping
        label_row_mapping = .Range("rng_param_mapping_bmf").row
        col_code_aggregat = Application.WorksheetFunction.match("Code Agregat (NewDeal)", .Rows(label_row_mapping), 0) - 1
        my_tab_mapping = .Range("rng_param_mapping_bmf").CurrentRegion
    End With
    
    For i = LBound(my_tab_mapping, 1) + 1 To UBound(my_tab_mapping, 1)
        If Not DictTemp_MappingBMF.Exists(my_tab_mapping(i, col_code_aggregat)) Then
            temp_code_rubrique = my_tab_mapping(i, col_code_aggregat)
            DictTemp_MappingBMF.Add my_tab_mapping(i, col_code_aggregat), fct_DictTemp_MappingBMF_inside(temp_code_rubrique)
        End If
    Next i
    
    Set fct_dict_MappingBMF_nested = DictTemp_MappingBMF
    'Call fct_print_DictNested(DictTemp_MappingBMF)
    Set DictTemp_MappingBMF = Nothing

End Function

Private Function fct_print_DictNested(my_dict As Dictionary, Optional nested_bool = True)

    Dim my_key      As Variant
    Dim my_element  As Variant
    
    For Each my_key In my_dict.Keys
        Debug.Print my_key
        If nested_bool Then
            For Each my_element In my_dict(my_key).Keys
                Debug.Print vbTab & my_element & " : " & my_dict(my_key)(my_element)
            Next
            Debug.Print "----------"
        Else
            Debug.Print my_dict(my_key)
        End If
    Next
    
End Function

Function fct_DictTemp_MappingBMF_inside(temp_code_rubrique As String) As Dictionary

    Dim my_tab_mapping              As Variant
    Dim DictTemp_mapping_inside     As Dictionary
    Dim dict_ForNotSameFilter       As Dictionary
    Dim i                           As Integer
    Dim j                           As Integer
    Dim label_row_mapping           As Integer
    Dim col_code_aggregat           As Integer
    
    Set DictTemp_mapping_inside = New Dictionary
    Set dict_ForNotSameFilter = New Dictionary

    With ws_mapping
        label_row_mapping = .Range("rng_param_mapping_bmf").row
        col_code_aggregat = Application.WorksheetFunction.match("Code Agregat (NewDeal)", .Rows(label_row_mapping), 0) - 1
        my_tab_mapping = .Range("rng_param_mapping_bmf").CurrentRegion
    End With

    For j = LBound(my_tab_mapping, 2) To UBound(my_tab_mapping, 2)
    
         If Not my_tab_mapping(1, j) = "PCAL - Label" Xor _
                my_tab_mapping(1, j) = "Code Agregat (NewDeal)" Xor _
                my_tab_mapping(1, j) = "Libellé Code Agregat" Then
            
            For i = LBound(my_tab_mapping, 1) + 1 To UBound(my_tab_mapping, 1)
            
                If my_tab_mapping(i, col_code_aggregat) = temp_code_rubrique And Not my_tab_mapping(i, j) = "" Then
                
                    If Not DictTemp_mapping_inside.Exists(my_tab_mapping(1, j)) Then
                        DictTemp_mapping_inside.Add my_tab_mapping(1, j), my_tab_mapping(i, j)
                        dict_ForNotSameFilter.Add my_tab_mapping(i, j), "seen"
                    ElseIf DictTemp_mapping_inside.Exists(my_tab_mapping(1, j)) Then
                            If Not dict_ForNotSameFilter.Exists(my_tab_mapping(i, j)) Then
                                DictTemp_mapping_inside.item(my_tab_mapping(1, j)) = DictTemp_mapping_inside.item(my_tab_mapping(1, j)) & "," & my_tab_mapping(i, j)
                            End If
                    End If
                
                End If
            Next i
        End If
        
    Next j
    
    Set fct_DictTemp_MappingBMF_inside = DictTemp_mapping_inside
    Set DictTemp_mapping_inside = Nothing
    Set dict_ForNotSameFilter = Nothing

End Function
```


## array

```
Option Explicit
Option Base 1

Sub filter_range_with_autofilter(code_aggregat As String)

    Dim key_code_rubrique       As Variant
    Dim key_LabelFilter         As Variant
    Dim list_filter_fields_new  As Variant
    Dim range_ToFilter          As Range
    Dim dict_input              As New Dictionary
    Dim col_bmf                 As Integer

    Set range_ToFilter = ws_cube_bmf_value.Range("A1").CurrentRegion
    Set dict_input = fct_dict_MappingBMF_nested
    
    range_ToFilter.AutoFilter
    For Each key_code_rubrique In dict_input.Keys
        
        If key_code_rubrique = code_aggregat Then
        
            For Each key_LabelFilter In dict_input(key_code_rubrique).Keys
                
                If InStr(CStr(dict_input(key_code_rubrique)(key_LabelFilter)), ",") Then
                    list_filter_fields_new = Split(dict_input(key_code_rubrique)(key_LabelFilter), ",")
                Else
                    list_filter_fields_new = dict_input(key_code_rubrique)(key_LabelFilter)
                End If
                
                col_bmf = Application.WorksheetFunction.match(key_LabelFilter, ws_cube_bmf_value.Rows("1:1"), 0)
                range_ToFilter.AutoFilter Field:=col_bmf, Criteria1:=list_filter_fields_new, Operator:=xlFilterValues
            Next key_LabelFilter
        
        End If
        
    Next key_code_rubrique
    
        'DEBUG
        '    ws_test.Cells.Clear
        '    ws_cube_bmf_value.Range("A1").CurrentRegion.Copy
        '    ws_test.Range("A1").PasteSpecial xlPasteValues
        '    Application.CutCopyMode = False
        '    range_ToFilter.AutoFilter
 
End Sub

Function fct_GetData_WithAutoFilter()

    Dim arr_temp        As Variant
    Dim row             As Range
    Dim range_ToFilter  As Range
    Dim rg              As Range
    Dim i               As Long
    Dim j               As Long
    Dim last_col        As Integer
    Dim last_row        As Integer
    Dim last_row_filter As Integer
    
    '---------------------------
    'Méthode 1 : variable Tableau
    '---------------------------
    last_col = ws_cube_bmf_value.UsedRange.Columns.count
    last_row = ws_cube_bmf_value.UsedRange.Rows.count
    last_row_filter = ws_cube_bmf_value.AutoFilter.Range.Columns(1).SpecialCells(xlCellTypeVisible).Cells.count
    Set range_ToFilter = ws_cube_bmf_value.Range("A1").CurrentRegion
    
    Set rg = ws_cube_bmf_value.Range("A1" & ":" & fct_ConvertToLetter(last_col) & last_row).SpecialCells(xlCellTypeVisible)
    
    If Not rg.SpecialCells(xlCellTypeVisible).count > 0 Then Exit Function
    
    i = 1
    ReDim arr_temp(1 To last_col, 1 To last_row_filter)

    For Each row In rg.Rows
        If Not row.Hidden Then
            For j = LBound(arr_temp, 1) To UBound(arr_temp, 1)
                arr_temp(j, i) = row.Cells(j)
            Next j
            i = i + 1
        End If
    Next row
    
    arr_temp = WorksheetFunction.Transpose(arr_temp)
    ws_test.Range("A1").Resize(UBound(arr_temp, 1), UBound(arr_temp, 2)) = arr_temp
    
    fct_GetData_WithAutoFilter = arr_temp
    range_ToFilter.AutoFilter
    Set arr_temp = Nothing
    
    
    '----------------------
    'Méthode 2 : Cop/coller
    '----------------------
        'ws_test.Cells.Clear
        'ws_cube_bmf_value.Range("A1").CurrentRegion.Copy
        'ws_test.Range("A1").PasteSpecial xlPasteValues
        'Application.CutCopyMode = False
        'range_ToFilter.AutoFilter
        'arr = sht_calc.UsedRange.value
        'fct_GetData_WithAutoFilter = arr
    
         
End Function

'-------------------------------------------------------------------------------------------------------
'-------------------------------------------------------------------------------------------------------

Function fct_FilterAndLoad_BMFValues(data_ToFilter As Variant, list_filter_fields As Variant) As Variant

    Dim ArrayTemp_filtered()    As Variant
    Dim i                       As Long
    Dim j                       As Long
    Dim k                       As Integer
    Dim Z                       As Integer

    ReDim ArrayTemp_filtered(1 To UBound(data_ToFilter, 2), 1 To 1)
    
    For j = 1 To UBound(data_ToFilter, 2)
        ArrayTemp_filtered(j, 1) = data_ToFilter(1, j)
    Next j
    
    k = 2
    Z = 1
    For i = 1 To UBound(data_ToFilter)
     
        If fct_CheckFilters(data_ToFilter, i, list_filter_fields) Then
            ReDim Preserve ArrayTemp_filtered(1 To UBound(data_ToFilter, 2), 1 To 1 + Z)
            For j = 1 To UBound(data_ToFilter, 2)
                ArrayTemp_filtered(j, k) = data_ToFilter(i, j)
            Next j
            k = k + 1
            Z = Z + 1
        End If
        
    Next i

    fct_FilterAndLoad_BMFValues = TransposeArray(ArrayTemp_filtered)

End Function

Function fct_CheckFilters(array_ToFilter As Variant, i As Long, list_filter_fields As Variant) As Boolean

    Dim key_col_num As Variant
    fct_CheckFilters = True
    
    For Each key_col_num In list_filter_fields
    
        If array_ToFilter(i, col_cpy_level) <> CStr(key_col_num) Then
            fct_CheckFilters = False
        Else
            fct_CheckFilters = True
            Exit Function
        End If
         
    Next key_col_num
   
End Function

Function fct_DictFilter_HorsGroup_amount(tab_data_BMF As Variant, col_date As Integer) As Dictionary
    
    Dim my_dico         As Dictionary
    Dim i               As Integer
    
    Set my_dico = New Dictionary
    
    For i = LBound(tab_data_BMF, 1) + 1 To UBound(tab_data_BMF, 1)
        If tab_data_BMF(i, col_entity_code) = "BLANK" And tab_data_BMF(i, col_perim_cpy) = "Externe C.A" Then
            If Not my_dico.Exists(code_HorsGroup) Then
                my_dico.Add code_HorsGroup, tab_data_BMF(i, col_date) / 1000
            ElseIf my_dico.Exists(code_HorsGroup) Then
                my_dico.item(code_HorsGroup) = my_dico.item(code_HorsGroup) + tab_data_BMF(i, col_date) / 1000
            End If
        End If
    Next i
    
    Set fct_DictFilter_HorsGroup_amount = my_dico
    Set my_dico = Nothing
    
End Function

Function fct_DictFilter_entity_amount(tab_data_BMF As Variant, col_date As Integer) As Dictionary
    
    Dim my_dico         As Dictionary
    Dim i               As Integer
      
    Set my_dico = New Dictionary
    
    For i = LBound(tab_data_BMF, 1) + 1 To UBound(tab_data_BMF, 1)
        If Not tab_data_BMF(i, col_entity_code) = "BLANK" And Not tab_data_BMF(i, col_entity_code) = "" And Not tab_data_BMF(i, col_perim_cpy) = "Externe C.A" Then
            If Not my_dico.Exists(tab_data_BMF(i, col_entity_code)) Then
                my_dico.Add tab_data_BMF(i, col_entity_code), tab_data_BMF(i, col_date) / 1000
            ElseIf my_dico.Exists(tab_data_BMF(i, col_entity_code)) Then
                my_dico.item(tab_data_BMF(i, col_entity_code)) = my_dico.item(tab_data_BMF(i, col_entity_code)) + tab_data_BMF(i, col_date) / 1000
            End If
        End If
    Next i
    
    'Call fct_debug_dictionary(my_dico)
    Set fct_DictFilter_entity_amount = fct_sum_dict(my_dico)
    Set my_dico = Nothing
    
End Function

Function fct_sum_dict(dict_temp As Dictionary)

    Dim key_temp    As Variant
    Dim sum_values  As Variant
    
    For Each key_temp In dict_temp.Keys
        sum_values = sum_values + dict_temp(key_temp)
    Next key_temp

    dict_temp.Add "", sum_values
    Set fct_sum_dict = dict_temp
    
End Function

Function fct_DictBMF_HG_flux(tab_data_BMF As Variant, col_date_ouverture As Integer, col_date As Integer) As Dictionary
    
    Dim my_dico         As Dictionary
    Dim i               As Integer
    
    Set my_dico = New Dictionary
    
    For i = LBound(tab_data_BMF, 1) + 1 To UBound(tab_data_BMF, 1)

        If tab_data_BMF(i, col_entity_code) = "BLANK" And tab_data_BMF(i, col_perim_cpy) = "Externe C.A" Then
            If Not my_dico.Exists(code_HorsGroup) Then
                my_dico.Add code_HorsGroup, (tab_data_BMF(i, col_date) - tab_data_BMF(i, col_date_ouverture)) / 1000
            ElseIf my_dico.Exists(code_HorsGroup) Then
                my_dico.item(code_HorsGroup) = my_dico.item(code_HorsGroup) + (tab_data_BMF(i, col_date) - tab_data_BMF(i, col_date_ouverture)) / 1000
            End If
        End If
        
    Next i
    
    Set fct_DictBMF_HG_flux = my_dico
    Set my_dico = Nothing
    
End Function

Function fct_DictBMF_HG_flux_cpy(tab_data_BMF As Variant, col_date_ouverture As Integer, col_date As Integer) As Dictionary
    
    Dim my_dico         As Dictionary
    Dim i               As Integer
    
    Set my_dico = New Dictionary
    
    For i = LBound(tab_data_BMF, 1) + 1 To UBound(tab_data_BMF, 1)
        If Not tab_data_BMF(i, col_entity_code) = "BLANK" And Not tab_data_BMF(i, col_entity_code) = "" And Not tab_data_BMF(i, col_perim_cpy) = "Externe C.A" Then
            If Not my_dico.Exists(tab_data_BMF(i, col_entity_code)) Then
                my_dico.Add tab_data_BMF(i, col_entity_code), (tab_data_BMF(i, col_date) - tab_data_BMF(i, col_date_ouverture)) / 1000
            ElseIf my_dico.Exists(tab_data_BMF(i, col_entity_code)) Then
                my_dico.item(tab_data_BMF(i, col_entity_code)) = my_dico.item(tab_data_BMF(i, col_entity_code)) + (tab_data_BMF(i, col_date) - tab_data_BMF(i, col_date_ouverture)) / 1000
            End If
        End If
    Next i
    
    Set fct_DictBMF_HG_flux_cpy = fct_sum_dict(my_dico)
    Set my_dico = Nothing
    
End Function

Function fct_array_WithoutAmountNul(arr_data_current As Variant, num_col_amount As Integer) As Variant

    Dim ArrayTemp_filtered()    As Variant
    Dim i                       As Long
    Dim j                       As Long
    Dim k                       As Integer
    Dim Z                       As Integer

    ReDim ArrayTemp_filtered(1 To UBound(arr_data_current, 2), 1 To 1)
    k = 1
    Z = 1
    For i = 1 To UBound(arr_data_current)
        If Len(arr_data_current(i, num_col_amount)) >= 2 Then
            ReDim Preserve ArrayTemp_filtered(1 To UBound(arr_data_current, 2), 1 To 1 + Z)
            For j = 1 To UBound(arr_data_current, 2)
                ArrayTemp_filtered(j, k) = arr_data_current(i, j)
            Next j
            k = k + 1
            Z = Z + 1
        End If
    Next i

    fct_array_WithoutAmountNul = fct_Transpose_StringArray(ArrayTemp_filtered)
    NbRows_InTabComplete = UBound(fct_array_WithoutAmountNul, 1)
        
End Function

Function fct_array_AggregateIfSameRows(array_input As Variant, col_amount_ToAggregate As Integer, ParamArray arr_ColToIgnore() As Variant) As String()

    Dim array_result()  As String
    Dim array_temp()    As Variant
    Dim key_iter        As Variant
    Dim dict            As New Dictionary
    Dim i               As Long
    Dim j               As Integer
    Dim key             As String

    For i = 1 To UBound(array_input, 1)
    
        key = ""
        For j = 1 To UBound(array_input, 2)
            If Not j = 29 Then
                key = key & CStr(array_input(i, j)) & ","
            End If
        Next j
        
        If Not dict.Exists(key) Then
            ReDim array_temp(1 To UBound(array_input, 2))
            
            For j = 1 To UBound(array_input, 2)
                array_temp(j) = array_input(i, j)
            Next j
            dict.Add key, array_temp
        Else
            array_temp = dict.item(key)
            
            For j = 2 To UBound(array_input, 2)
                If j = col_amount_ToAggregate Then
                    array_temp(j) = CDbl(array_temp(j)) + CDbl(array_input(i, j))
                End If
            Next j
        
            dict.item(key) = array_temp
        End If
    Next i

    ReDim array_result(1 To dict.count, 1 To UBound(array_input, 2))
    i = 0
    For Each key_iter In dict.Keys
        i = i + 1
        array_temp = dict.item(key_iter)
        
        For j = 1 To UBound(array_input, 2)
        
            If j = 2 Then
                array_result(i, j) = CStr(array_temp(j))
            Else
                array_result(i, j) = array_temp(j)
            End If
        Next j
        
    Next key_iter
    
    fct_array_AggregateIfSameRows = array_result
    Set dict = Nothing
       
End Function
```


# AS

## tools

```
Option Explicit

'Intervention Commando 2023

Sub StartProcessUserform()
    
    'Call Logger.log_content("Start", True)
    'Call Logger.log_content("Info", False, True)
    userform_loading.Show vbModeless
    
End Sub

Sub EndProcessUserForm()
    
    userform_loading.Hide
    Unload userform_loading
    Call clean_userform
    'Call Logger.log_content("End", True)
    Application.StatusBar = ""
    
End Sub

Function FctOptimizeVBA(isOn As Boolean)
    Application.EnableEvents = Not (isOn)
    Application.ScreenUpdating = Not (isOn)
    Application.DisplayAlerts = Not (isOn)
    Application.DisplayStatusBar = Not (isOn)
    Application.AskToUpdateLinks = Not (isOn)
End Function

Function FctIfDictIsNotEmpty(ArrDict As Dictionary, NameDict As String) As Dictionary
    If ArrDict.count = 0 Then
        MsgBox "Error, Dictionary : " & NameDict & " is empty", vbCritical
    Else
        Set FctIfDictIsNotEmpty = ArrDict
    End If
End Function

Function FctIfArrIsNotEmpty(ArrTemp As Variant, NameArray As String) As Variant

    On Error GoTo ErrorHandler:
    
    If IsEmpty(ArrTemp) Then
        MsgBox "Error, Array Function : " & NameArray & " is empty", vbCritical
    Else
        FctIfArrIsNotEmpty = ArrTemp
    End If
    Exit Function
ErrorHandler:
    MsgBox "Error, Array Function : " & NameArray & " is empty", vbCritical

End Function

Function FctDisplayArr(WsToDisplay As Worksheet, ArrTemp As Variant, BoolDisplayToSide As Boolean, Optional AddressToDisplay As String)
    Dim LastCol As Integer
    With WsToDisplay
        If BoolDisplayToSide = False Then
            .Range(AddressToDisplay).Resize(UBound(ArrTemp, 1), UBound(ArrTemp, 2)) = ArrTemp
        Else
            LastCol = .Cells(.Range("A1").row, .Columns.count).End(xlToLeft).Column + 1
            .Range(FctGetColLetterFromInt(LastCol) & "1").Resize(UBound(ArrTemp, 1), UBound(ArrTemp, 2)) = ArrTemp
        End If
    End With
End Function

Function PrintDict(DictTemp As Dictionary)
    Dim Key As Variant
    For Each Key In DictTemp.Keys
        Debug.Print Key, DictTemp(Key)
    Next Key
End Function

Function PrintDictArrItem(DictTemp As Dictionary, NbArray As Integer)
    Dim Key         As Variant
    Dim ArrItem     As Variant
    Dim i           As Integer
    For Each Key In DictTemp.Keys
        ArrItem = ""
        For i = 0 To NbArray - 1
            ArrItem = ArrItem & "|" & DictTemp(Key)(i)
        Next i
        Debug.Print Key, ArrItem
    Next Key
End Function

Sub PrintArray(arr As Variant, headerText As String)
    Dim entry As Variant
    Debug.Print vbNewLine & headerText
    For Each entry In arr
        Debug.Print entry
    Next
End Sub

Function FctGetNameLastPivot(ShtName As String) As String

    Dim clsError    As cls_error_handler
    Dim WsTemp      As Worksheet
    Dim Pivot       As PivotTable
    Dim LastPivot   As PivotTable
    Dim MaxCol      As Integer
    
    On Error GoTo ErrorHandler:
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Tools", "FctGetNameLastPivot"
    
    Set WsTemp = Workbooks(CStr(ThisWorkbook.Name)).Worksheets(ShtName)
    MaxCol = 0
    For Each Pivot In WsTemp.PivotTables
        If Pivot.TableRange2.Column > MaxCol Then
            MaxCol = Pivot.TableRange2.Column
            Set LastPivot = Pivot
        End If
    Next Pivot
    If Not LastPivot Is Nothing Then
        FctGetNameLastPivot = LastPivot.Name
    Else
        MsgBox "None Pivot found on : " & WsTemp, vbCritical, "FctGetNameLastPivot"
    End If
    
    Exit Function
    
ErrorHandler:
    ErrorManager.description = Split(clsError.Location, "]")(1) & "Problème sur Pivot feuille:" & ShtName
    Err.Number = 1
    Call ErrorManager.handle_error(Err)
    
End Function

Private Function FctGetColIntFromLetter(sLetter As String) As Integer
  FctGetColIntFromLetter = Asc(UCase(sLetter)) - 64
End Function

Function FctGetColLetterFromInt(ColumnNumber As Integer) As String

    Dim n As Long
    Dim c As Byte
    Dim s As String

    n = ColumnNumber
    Do
        c = ((n - 1) Mod 26)
        s = Chr(c + 65) & s
        n = (n - c) \ 26
    Loop While n > 0
    FctGetColLetterFromInt = s
    
End Function

Function FctDictGetKey(Dic As Dictionary, str_item As Long) As Long

    Dim Key As Variant
    For Each Key In Dic.Keys
        If Dic.item(Key) = str_item Then
            FctDictGetKey = Key
            Exit Function
        End If
    Next
    
End Function

Function FctMergeDict(DictPost As Dictionary, DictAnte As Dictionary)

    Dim KeyT As Variant
    For Each KeyT In DictAnte.Keys
        If Not DictPost.Exists(KeyT) Then
            DictPost.Add KeyT, DictAnte(KeyT)
        End If
    Next KeyT

End Function

Public Function FctGetNumColumn(ws_temp As Worksheet, ColumnName As String) As Integer

    Dim clsError    As cls_error_handler
    
    On Error GoTo ErrorHandler:
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Tools", "FctGetNumColumn"
    
    FctGetNumColumn = Application.WorksheetFunction.Match(ColumnName, ws_temp.Rows("1:1"), 0)

    Exit Function
    
ErrorHandler:
    ErrorManager.description = Split(clsError.Location, "]")(1) & "Nom Champ introuvable:" & ColumnName & " sur la feuille:" & ws_temp.Name
    Err.Number = 1
    Call ErrorManager.handle_error(Err)
    
End Function

Public Function FctSortDictByValues(dict As Object _
                    , Optional sortorder As XlSortOrder = xlAscending) As Object
    
    Dim item        As Variant
    Dim Key         As Variant
    Dim value       As Variant
    Dim arrayList   As Object
    Dim DictTemp    As Object
    Dim coll        As Collection
    
    On Error GoTo ErrorHandler
    
    Set arrayList = CreateObject("System.Collections.ArrayList")
    Set DictTemp = CreateObject("Scripting.Dictionary")
   
    For Each Key In dict
        value = dict(Key)
        
        If Not DictTemp.Exists(value) Then
            Set coll = New Collection
            DictTemp.Add value, coll
            arrayList.Add value
        End If
        
        DictTemp(value).Add Key
    Next Key
    
    arrayList.Sort

    If sortorder = xlDescending Then
        arrayList.Reverse
    End If
    
    dict.RemoveAll
    
    For Each value In arrayList
        Set coll = DictTemp(value)
        For Each item In coll
            dict.Add item, value
        Next item
    Next value
    
    Set arrayList = Nothing
    Set FctSortDictByValues = dict
        
Done:
    Exit Function
ErrorHandler:
    If Err.Number = 450 Then
        Err.Raise vbObjectError + 100, "FctSortDictByValues" _
                , "Cannot sort the dictionary if the value is an object"
    End If
    
End Function


```

## property

```
Option Explicit

Private Logger_                     As cls_logger
Private ErrorManager_               As cls_error_handler
Private DictTempMappingException    As Dictionary
Private DictTempMappingExclusion    As Dictionary
Private userform_loading_           As Object
'

Public Sub ResetPropetyGet()
    Set ErrorManager_ = Nothing
    Set Logger_ = Nothing
    Set DictTempMappingException = Nothing
End Sub

Property Get Logger() As cls_logger
    If Logger_ Is Nothing Then
        Set Logger_ = New cls_logger
    End If
    Set Logger = Logger_
End Property

Property Get ErrorManager() As cls_error_handler
    If ErrorManager_ Is Nothing Then
        Set ErrorManager_ = New cls_error_handler
    End If
    Set ErrorManager = ErrorManager_
End Property

Public Property Get DictMappingExclusion() As Dictionary

    If DictTempMappingExclusion Is Nothing Then
       Set DictTempMappingExclusion = LoadDictMappingException(CStr(sht_pil.Range("rng_mapping_exclusion").Address), False)
    End If
    Set DictMappingExclusion = DictTempMappingExclusion
    
End Property

Public Property Get DictMappingException() As Dictionary

    If DictTempMappingException Is Nothing Then
       Set DictTempMappingException = LoadDictMappingException(CStr(sht_pil.Range("rng_mapping").Address), True)
    End If
    Set DictMappingException = DictTempMappingException
    
End Property

Public Function LoadDictMappingException(ByVal StartCellTemp As String, BoolMapping2Col As Boolean) As Dictionary

    Dim ArrMapping  As Variant
    Dim DictArray   As Dictionary
    Dim LastCol     As Integer
    Dim LastRow     As Long
    Dim x           As Integer
    Dim count       As Integer
    
    Set DictArray = New Dictionary

    With sht_pil
        LastRow = .Range(StartCellTemp).End(xlDown).row
        If BoolMapping2Col = True Then
            LastCol = .Range(StartCellTemp).Offset(0, 4).Column
        Else
            LastCol = .Range(StartCellTemp).Column
        End If
        ArrMapping = .Range(StartCellTemp & ":" & FctGetColLetterFromInt(LastCol) & LastRow)
    End With
    
    For x = LBound(ArrMapping, 1) To UBound(ArrMapping, 1)
        If Not DictArray.Exists(ArrMapping(x, 1)) Then
            If BoolMapping2Col = True Then
                DictArray.Add ArrMapping(x, 1), MappingNoEmpty(ArrMapping(x, 2)) & PublicVarSplit & MappingNoEmpty(ArrMapping(x, 3)) & _
                PublicVarSplit & MappingNoEmpty(ArrMapping(x, 4)) & PublicVarSplit & MappingNoEmpty(ArrMapping(x, 5))
            Else
                DictArray.Add ArrMapping(x, 1), ""
            End If
        End If
        count = count + 1
    Next x
        
    Set LoadDictMappingException = DictArray
    Set DictArray = Nothing
  
End Function

Function MappingNoEmpty(ArrTemp As Variant)
    If ArrTemp = vbNullString Then
        MappingNoEmpty = "No Mapping"
    Else
        MappingNoEmpty = ArrTemp
    End If
End Function




Public Sub clean_userform()
    
    If Not userform_loading_ Is Nothing Then
        Set userform_loading_ = Nothing
    End If
    
End Sub
Property Get userform_loading() As Object
    
    If userform_loading_ Is Nothing Then
        Set userform_loading_ = UserformProgressBar
    End If
    
    Set userform_loading = userform_loading_
    
End Property
```

## hidebar

```
Option Explicit
Option Private Module

Public Const GWL_STYLE = -16
Public Const WS_CAPTION = &HC00000
#If VBA7 Then
    Public Declare PtrSafe Function GetWindowLong _
                           Lib "user32" Alias "GetWindowLongA" ( _
                           ByVal hWnd As Long, _
                           ByVal nIndex As Long) As Long
    Public Declare PtrSafe Function SetWindowLong _
                           Lib "user32" Alias "SetWindowLongA" ( _
                           ByVal hWnd As Long, _
                           ByVal nIndex As Long, _
                           ByVal dwNewLong As Long) As Long
    Public Declare PtrSafe Function DrawMenuBar _
                           Lib "user32" ( _
                           ByVal hWnd As Long) As Long
    Public Declare PtrSafe Function FindWindowA _
                           Lib "user32" (ByVal lpClassName As String, _
                           ByVal lpWindowName As String) As Long
#Else
    Public Declare Function GetWindowLong _
                           Lib "user32" Alias "GetWindowLongA" ( _
                           ByVal hWnd As Long, _
                           ByVal nIndex As Long) As Long
    Public Declare Function SetWindowLong _
                           Lib "user32" Alias "SetWindowLongA" ( _
                           ByVal hWnd As Long, _
                           ByVal nIndex As Long, _
                           ByVal dwNewLong As Long) As Long
    Public Declare Function DrawMenuBar _
                           Lib "user32" ( _
                           ByVal hWnd As Long) As Long
    Public Declare Function FindWindowA _
                           Lib "user32" (ByVal lpClassName As String, _
                           ByVal lpWindowName As String) As Long
#End If
Sub HideTitleBar(frm As Object)
    Dim lngWindow As Long
    Dim lFrmHdl As Long
    lFrmHdl = FindWindowA(vbNullString, frm.Caption)
    lngWindow = GetWindowLong(lFrmHdl, GWL_STYLE)
    lngWindow = lngWindow And (Not WS_CAPTION)
    Call SetWindowLong(lFrmHdl, GWL_STYLE, lngWindow)
    Call DrawMenuBar(lFrmHdl)
End Sub
```

## main

```
Option Explicit

Public PublicFirstError                         As Boolean

Public Const PublicVarStr_GrappeBilanSteve      As String = "Grappe_Bilan_Steve"
Public Const PublicVarStr_Devise                As String = "Devise"
Public Const PublicVarStr_Domaine               As String = "Domaine"
Public Const PublicVarStr_Ecart                 As String = "Ecart"
Public Const PublicVarSplit                     As String = "__"
Public Const StrColLabelToFiler                 As String = "Grappe_Bilan_Steve" & PublicVarSplit & "Devise" & PublicVarSplit & "Domaine"
Public Const PublicStrMaqCrdAmount              As String = "CRD 31/12/Année N"
Public Const PublicStrMaqEndTreatment           As String = "TCI Taux modelisé M1 "
Public Const PublicStrMaqVolEncoursACX          As String = "Volume d'encours de la production nouvelle (Année N)"
Public Const PublicDebugMode                    As Boolean = False
Public BoolIChangeAandP                         As Boolean

Dim ColGrappeBilanSteve                         As Integer
Dim ColDevise                                   As Integer
Dim ColDomaine                                  As Integer
Dim ColEcart                                    As Integer
Dim ColMaqCrdAmount                             As Integer
Dim ColMaqEndTreatment                          As Integer
Dim ColMaqVolEncoursACX                         As Integer
Dim ColTcdControleSommeCrd                      As Integer
Dim DictTempIChangeAandP                        As Dictionary
Dim DictTempICrdMax                             As Dictionary
Dim DictIRowsToSetNull                          As Dictionary
'

'Intervention Commando 2023
Sub MainStep5()

    Dim otime                       As New cls_timer
    Dim clsError                    As cls_error_handler
    Dim ArrayControle               As Variant
    Dim KeyValueToFilter            As Variant
    Dim ArrAfterFilter              As Variant
    Dim CollectionfromArrFiltered   As Collection
    Dim ArrTreatmentResult          As Variant
    Dim RngToFilter                 As Range
    Dim DictArrControle             As Dictionary
    Dim DictIChangeAandP            As Dictionary
    Dim DictTempIrowsToSetNull      As Dictionary
    Dim MaxCrdMaq                   As Variant
    Dim NewCrd                      As Variant
    Dim SumCrd                      As Variant
    Dim ICrdMaxToModify             As Integer
    Dim Iresult                     As Integer
    
    On Error GoTo ErrorHandler:
    
    otime.start
    Call FctOptimizeVBA(True)
    Call ResetPropetyGet
    
    Call Logger.LogContent("Start Step5NewTreatment", True)
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "MainStep5"
    PublicFirstError = False
    Call StartProcessUserform
    
    ActiveWorkbook.RefreshAll
    
    ColMaqCrdAmount = FctGetNumColumn(sht_maq_traitement1, PublicStrMaqCrdAmount)
    ColMaqVolEncoursACX = FctGetNumColumn(sht_maq_traitement1, PublicStrMaqVolEncoursACX)
    ColMaqEndTreatment = 209
 
    ArrayControle = FctDefineArrayControle
    Set DictArrControle = fctLoadDictArrControle(ArrayControle)
        'Call PrintDictArrItem(DictArrControle, 2)
        
    '==========INFO==============
    'On stock les traitements dans une variable tableau pour appliquer toutes les modifications en une seule fois à la fin
    'Rajout d'une 1 colonne (n-1) pour associé la i ième ligne à modifier du tableau initial
    'Rajout aussi d'une colonne(n) pour discontinuité modification col ACX (Volume d'encours de la production nouvelle (Année N))
    '============================
    ReDim ArrTreatmentResult(1 To DictArrControle.count, 1 To (ColMaqEndTreatment + 1 - ColMaqCrdAmount) + 3)
    
    Set RngToFilter = sht_maq_traitement1.Range("A1").CurrentRegion
    
    Iresult = 1
    Set DictTempICrdMax = New Dictionary
    Set DictIRowsToSetNull = New Dictionary
    For Each KeyValueToFilter In DictArrControle.Keys
        Call userform_loading.update((Iresult / DictArrControle.count) * 100, 100, "Code GRAPPE BILAN: " & KeyValueToFilter)
    
        SumCrd = DictArrControle(KeyValueToFilter)(2)
        NewCrd = DictArrControle(KeyValueToFilter)(0)
        
        Call FctAutoFilter(RngToFilter, KeyValueToFilter)
        
        Set CollectionfromArrFiltered = FctBuildCollectionfromArrFiltered
        MaxCrdMaq = CollectionfromArrFiltered("value Max CRD")
        ICrdMaxToModify = CollectionfromArrFiltered("row i Max CRD")
            'Call StepDebugPrint(DictArrControle, KeyValueToFilter, CollectionfromArrFiltered)
            
        ArrAfterFilter = FctGetDataAfterAutoFilter
            'Call FctDisplayArr(sht_buffer, ArrAfterFilter, False, "K1")
            
        Call FctTreatmentLoadArrResult(ArrAfterFilter, ArrTreatmentResult, MaxCrdMaq, SumCrd, NewCrd, Iresult, ICrdMaxToModify, KeyValueToFilter, DictTempIrowsToSetNull, CollectionfromArrFiltered)
            'Call FctDisplayArr(sht_buffer, ArrTreatmentResult, False, "K22")
    
        Iresult = Iresult + 1
    
    Next KeyValueToFilter
    
    'Modification de la feuille Maquette Finale
    Set DictIChangeAandP = FctDictIChangeAandP(DictTempICrdMax)
    Call FctDisplayResult(ArrTreatmentResult, DictIChangeAandP, DictTempIrowsToSetNull)
    
    Call EndProcessUserForm
    MsgBox "Done ! time :" & otime.stop_timer, vbInformation, "Treatment Maquette Finale"
    Call Logger.LogContent("Done Step 5, Time:" & otime.stop_timer, , True)
    
ErrorExit:
    Call EndProcessUserForm
    Call Logger.LogContent("End Step5NewTreatment", True)
    Call FctOptimizeVBA(False)
    Exit Sub

ErrorHandler:
    If PublicDebugMode = True Then
        Stop: Resume
    Else
        Set clsError = Nothing
        Resume ErrorExit
    End If
    
End Sub

Function FctTreatmentLoadArrResult(ArrAfterFilter As Variant, ArrTreatmentResult As Variant, _
                MaxCrdMaq As Variant, SumCrd As Variant, NewCrd As Variant, Iresult As Integer, _
                 ICrdMaxToModify As Integer, KeyValueToFilter As Variant, DictTempIrowsToSetNull As Dictionary, CollectionfromArrFiltered As Collection)

    'On stock de manière itérative(Iresult) les résultats dans une variable tableau provisoire
    'Valeur absolue car pas de valeurs négatives dnas maquette finale

    Dim clsError    As cls_error_handler
    Dim Calcul      As Double
    Dim i           As Integer
    Dim j           As Integer
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctTreatmentLoadArrResult"
   
   '==========Exception Commuter Actif Passif===========
    If DictMappingException.Exists(Split(KeyValueToFilter, PublicVarSplit)(0)) And NewCrd < 0 Then
            DictTempICrdMax.Add ICrdMaxToModify, KeyValueToFilter
    End If
   '===================================================
   
    If Abs(NewCrd) < SumCrd And DictMappingException.Exists(Split(KeyValueToFilter, PublicVarSplit)(0)) Then
        
        '==========Exception montant à 0===================
        'Montant CRD 31/12/Année N = NewCrd et
        'Mettre à 0 les autres lignes à 0 si Exception et NewCrd<Sum(CRD)
        If Not MaxCrdMaq = 0 Then
            Set DictTempIrowsToSetNull = CollectionfromArrFiltered("Dictionary i rows else Max CRD")
            Call FctMergeDict(DictIRowsToSetNull, DictTempIrowsToSetNull)
        End If
        For i = LBound(ArrAfterFilter, 1) + 1 To UBound(ArrAfterFilter, 1)
            If ArrAfterFilter(i, ColMaqCrdAmount) = MaxCrdMaq Then
                'Calcul New CRD 31/12/Année N
                ArrTreatmentResult(Iresult, 1) = Abs(NewCrd)
                'I ième à modifier dans maquette finale
                ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2)) = ICrdMaxToModify
                'Discontinuité modification col ACX (Volume d'encours de la production nouvelle (Année N))
                If Not MaxCrdMaq = 0 Then
                
                    ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2) - 1) = _
                        Abs(ArrAfterFilter(i, ColMaqVolEncoursACX) / MaxCrdMaq * ArrTreatmentResult(Iresult, 1))
                Else
                    ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2) - 1) = 0
                End If
                'Modification des colonnes CRD 31/12/Année N à CRD contractuel
                For j = ColMaqCrdAmount + 1 To ColMaqEndTreatment + 1 'array begin to 0
                    If Not MaxCrdMaq = 0 Then
                        ArrTreatmentResult(Iresult, j + 1 - ColMaqCrdAmount) = _
                        Abs(ArrAfterFilter(i, j) / MaxCrdMaq * ArrTreatmentResult(Iresult, 1))
                    Else
                        ArrTreatmentResult(Iresult, j + 1 - ColMaqCrdAmount) = 0
                    End If
                Next j
            End If
        Next i
        '===================================================
    Else
        'CAS GENERALE
        For i = LBound(ArrAfterFilter, 1) + 1 To UBound(ArrAfterFilter, 1)
            If ArrAfterFilter(i, ColMaqCrdAmount) = MaxCrdMaq Then
                'Calcul New CRD 31/12/Année N
                ArrTreatmentResult(Iresult, 1) = Abs(MaxCrdMaq - (SumCrd - Abs(NewCrd)))
                'Discontinuité modification col ACX (Volume d'encours de la production nouvelle (Année N))
                If Not MaxCrdMaq = 0 Then
                    ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2) - 1) = _
                        Abs(ArrAfterFilter(i, ColMaqVolEncoursACX) / MaxCrdMaq * ArrTreatmentResult(Iresult, 1))
                Else
                    ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2) - 1) = 0
                End If
                'I ième à modifier dans maquette finale
                ArrTreatmentResult(Iresult, UBound(ArrTreatmentResult, 2)) = ICrdMaxToModify

                'Modification des colonnes CRD 31/12/Année N à CRD contractuel
                For j = ColMaqCrdAmount + 1 To ColMaqEndTreatment + 1 'array begin to 0
                    If Not MaxCrdMaq = 0 Then
                        ArrTreatmentResult(Iresult, j + 1 - ColMaqCrdAmount) = _
                            Abs(ArrAfterFilter(i, j) / MaxCrdMaq * ArrTreatmentResult(Iresult, 1))
                    Else
                        ArrTreatmentResult(Iresult, j + 1 - ColMaqCrdAmount) = 0
                    End If
                Next j
                Exit For
            End If
        Next i
    End If
   
End Function

Function FctDisplayResult(ArrTreatmentResult As Variant, DictIChangeAandP As Dictionary, DictTempIrowsToSetNull As Dictionary)

    Dim clsError    As cls_error_handler
    Dim KeyI        As Variant
    Dim LastRow     As Integer
    Dim ICrdMaxToModify   As Integer
    Dim i           As Long
    Dim j           As Long
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctDisplayResult"
    
    
    On Error GoTo ErrorHandler:
    
    With sht_maq_traitement1
        LastRow = .Cells(Rows.count, "A").End(xlUp).Offset(1, 0).row
        For i = 1 To UBound(ArrTreatmentResult, 1)
            ICrdMaxToModify = ArrTreatmentResult(i, UBound(ArrTreatmentResult, 2))
            'Modification des colonnes CRD 31/12/Année N à CRD contractuel
            For j = 0 To UBound(ArrTreatmentResult, 2) - 2  '(non ICrdMaxToModify(n) et non VolEncoursACX(n-1))
                If j = 190 Then Exit For
                .Cells(ICrdMaxToModify, ColMaqCrdAmount).Offset(0, j) = ArrTreatmentResult(i, j + 1)
                .Cells(ICrdMaxToModify, ColMaqCrdAmount).Offset(0, j).Font.Color = -16776961
            Next j
            'Discontinuité modification col ACX (Volume d'encours de la production nouvelle (Année N))
            .Cells(ICrdMaxToModify, ColMaqVolEncoursACX).Value2 = ArrTreatmentResult(i, UBound(ArrTreatmentResult, 2) - 1)
        Next i
        
        '==========Exception montant à 0===================
        'Mettre à 0 les autres lignes à 0 si Exception et NewCrd<Sum(CRD)
        If Not DictIRowsToSetNull.count = 0 Then
            For Each KeyI In DictIRowsToSetNull.Keys
                For j = 0 To UBound(ArrTreatmentResult, 2) - 2
                    If j = 190 Then Exit For
                    .Cells(KeyI, ColMaqCrdAmount).Offset(0, j) = 0
                    .Cells(KeyI, ColMaqCrdAmount).Offset(0, j).Font.Color = -16776961
                Next j
                .Cells(KeyI, ColMaqVolEncoursACX).Value2 = 0
            Next KeyI
        End If
        '===================================================
        
        '==========Exception Commuter Actif Passif===========
        If BoolIChangeAandP = True Then
            For Each KeyI In DictIChangeAandP.Keys
                .Cells(KeyI, 4).Value2 = Split(DictMappingException(.Cells(KeyI, ColGrappeBilanSteve).Value2), PublicVarSplit)(0) ' Code Produit
                .Cells(KeyI, 5).Value2 = Split(DictMappingException(.Cells(KeyI, ColGrappeBilanSteve).Value2), PublicVarSplit)(1) 'Domaine
                .Cells(KeyI, 6).Value2 = Split(DictMappingException(.Cells(KeyI, ColGrappeBilanSteve).Value2), PublicVarSplit)(2) 'Compartiment ITAC
                .Cells(KeyI, 7).Value2 = Split(DictMappingException(.Cells(KeyI, ColGrappeBilanSteve).Value2), PublicVarSplit)(3) 'Grappe_Bilan_Steve
            Next KeyI
        End If
        '===================================================
    End With
    
ErrorHandler:
    If Err.Number = 91 Then Exit Function
    
End Function

Function FctDefineArrayControle() As Variant

    Dim NameLastPivot   As String
    
    NameLastPivot = FctGetNameLastPivot(sht_TcdControle.Name)
    Call FctGetArrFromPivot(sht_TcdControle.Name, sht_buffer.Name, NameLastPivot)
    Call FctDisplayArr(sht_buffer, FctGetArrEcart(sht_TcdControle.Name), True)
    
    FctDefineArrayControle = FctIfArrIsNotEmpty(sht_buffer.Range("A1").CurrentRegion, "array TCD Controle (sht_buffer)")
    
End Function

Public Function FctGetArrFromPivot(ShtNamePivot As String, ShtNameBuffer As String, PivotName As String)

    'Pour @FctDefineArrayControle

    Dim clsError        As cls_error_handler
    Dim WsTemp          As Worksheet
    Dim WsBuffer        As Worksheet
    Dim LastRow         As Long
    Dim FirstRaw        As Integer
    Dim FirstColumn     As Integer
    Dim LastColumn      As Integer
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctGetArrFromPivot"
    
    Set WsTemp = Workbooks(CStr(ThisWorkbook.Name)).Worksheets(ShtNamePivot)
    Set WsBuffer = Workbooks(CStr(ThisWorkbook.Name)).Worksheets(ShtNameBuffer)
    
    'clear sht buffer for cop/paste
    WsBuffer.Cells.ClearContents
    'find position Pivot
    With WsTemp.PivotTables(PivotName).TableRange1
        FirstRaw = .row
        FirstColumn = .Column
        LastRow = .Rows.count + .row - 1
        LastColumn = .Columns.count + .Column - 1
    End With
    
    WsTemp.Range(WsTemp.Cells(1, FirstColumn), WsTemp.Cells(LastRow, LastColumn)).Copy
    WsBuffer.Range("A1").PasteSpecial Paste:=xlPasteValues
    Application.CutCopyMode = False

End Function

Function FctGetArrEcart(WsName) As Variant

    'Pour @FctDefineArrayControle
    
    Dim clsError        As cls_error_handler
    Dim WsTemp          As Worksheet
    Dim LastRow         As Long
    Dim LastCol         As Integer
    Dim ArrTemp()       As Variant
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctGetArrEcart"
    
    Set WsTemp = Workbooks(CStr(ThisWorkbook.Name)).Worksheets(WsName)
    
    With WsTemp
        LastCol = .Cells(.Range("A1").row, .Columns.count).End(xlToLeft).Column
        LastRow = .Range(FctGetColLetterFromInt(LastCol) & "1").End(xlDown).row
        ArrTemp = .Range(FctGetColLetterFromInt(LastCol - 1) & "1" & ":" & FctGetColLetterFromInt(LastCol) & CStr(LastRow)).value
    End With
    FctGetArrEcart = ArrTemp

End Function

Function fctLoadDictArrControle(ArrControle As Variant) As Dictionary

    'Dictionnaire récupération des corrections à réaliser

    Dim clsError    As cls_error_handler
    Dim DictTemp    As New Dictionary
    Dim StrKey      As String
    Dim i           As Long
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "fctLoadDictArrControle"
    
    ColGrappeBilanSteve = FctGetNumColumn(sht_buffer, PublicVarStr_GrappeBilanSteve)
    ColDevise = FctGetNumColumn(sht_buffer, PublicVarStr_Devise)
    ColDomaine = FctGetNumColumn(sht_buffer, PublicVarStr_Domaine)
    ColEcart = FctGetNumColumn(sht_buffer, PublicVarStr_Ecart)
    ColTcdControleSommeCrd = FctGetNumColumn(sht_buffer, "Somme de " & PublicStrMaqCrdAmount)
    
    For i = LBound(ArrControle, 1) + 1 To UBound(ArrControle, 1)
        ''gestion erreur 2042= NA dans cellule et exclusion (mapping)
        If Not IsError(ArrControle(i, UBound(ArrControle, 2))) Then
            If Not ArrControle(i, ColGrappeBilanSteve) = vbNullString And Not ArrControle(i, ColDevise) = vbNullString And Not ArrControle(i, ColGrappeBilanSteve) = "(vide)" _
           And Not ArrControle(i, UBound(ArrControle, 2)) = 0 And Not DictMappingExclusion.Exists(ArrControle(i, ColGrappeBilanSteve)) Then
            
                StrKey = ArrControle(i, ColGrappeBilanSteve) & PublicVarSplit & _
                        ArrControle(i, ColDevise) & PublicVarSplit & _
                        ArrControle(i, ColDomaine)
                        
                DictTemp.Add StrKey, Array(IIf(IsError(ArrControle(i, ColEcart - 1)), 0, ArrControle(i, ColEcart - 1)), IIf(IsError(ArrControle(i, ColEcart)), 0, ArrControle(i, ColEcart)), ArrControle(i, ColTcdControleSommeCrd))
            End If
        End If
    Next i

    If DictTemp.count = 0 Then
        MsgBox "Aucun écart retrouvé, ou exclu (voir mapping) ", vbInformation, "Steve Etape 5"
        End
    End If
    
    Set fctLoadDictArrControle = FctIfDictIsNotEmpty(DictTemp, "Function fctLoadDictArrControle")
    Set DictTemp = Nothing
    

End Function

Function FctAutoFilter(RngToFilter As Range, KeyValueToFilter As Variant)

    'Pour AutoFilter

    Dim clsError        As cls_error_handler
    Dim DictColToFilter As New Dictionary
    Dim KeyCol          As Variant
    Dim ValueToFilter   As Variant
    Dim i               As Byte
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctAutoFilter"

    ColGrappeBilanSteve = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_GrappeBilanSteve)
    ColDevise = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_Devise)
    ColDomaine = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_Domaine)

    DictColToFilter.Add ColGrappeBilanSteve, ""
    DictColToFilter.Add ColDevise, ""
    DictColToFilter.Add ColDomaine, ""
    
    RngToFilter.AutoFilter
    i = 0
    For Each KeyCol In DictColToFilter.Keys
        ValueToFilter = Split(CStr(KeyValueToFilter), PublicVarSplit)(i)
        RngToFilter.AutoFilter Field:=CInt(KeyCol), Criteria1:=ValueToFilter, Operator:=xlFilterValues
        i = i + 1
        If i = 3 Then Exit For
    Next KeyCol
    
End Function

Function FctGetDataAfterAutoFilter() As Variant

    'Pour AutoFilter

    Dim clsError        As cls_error_handler
    Dim ArrTemp         As Variant
    Dim row             As Range
    Dim RngInitial      As Range
    Dim RngAfterFilter  As Range
    Dim i               As Long
    Dim j               As Long
    Dim LastCol         As Integer
    Dim LastRow         As Integer
    Dim LastRowFilter   As Integer
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctGetDataAfterAutoFilter"

    With sht_maq_traitement1
        LastCol = .UsedRange.Columns.count
        LastRow = .UsedRange.Rows.count
        LastRowFilter = .AutoFilter.Range.Columns(2).SpecialCells(xlCellTypeVisible).Cells.count
        Set RngInitial = .Range("A1").CurrentRegion
        Set RngAfterFilter = .Range("A1" & ":" & FctGetColLetterFromInt(LastCol) & LastRow).SpecialCells(xlCellTypeVisible)
    End With

    If Not RngAfterFilter.SpecialCells(xlCellTypeVisible).count > 0 Then Exit Function

    i = 1
    ReDim ArrTemp(1 To LastCol, 1 To LastRowFilter)

    For Each row In RngAfterFilter.Rows
        If Not row.Hidden Then
            For j = LBound(ArrTemp, 1) To UBound(ArrTemp, 1)
                ArrTemp(j, i) = row.Cells(j)
            Next j
            If i = LastRowFilter Then
                Exit For
            Else
                i = i + 1
            End If
        End If
    Next row

    ArrTemp = WorksheetFunction.Transpose(ArrTemp)
    FctGetDataAfterAutoFilter = FctIfArrIsNotEmpty(ArrTemp, "FctGetDataAfterAutoFilter")
    
    'Retirer Filtre
    RngAfterFilter.AutoFilter
    Set ArrTemp = Nothing
        
End Function

Function FctBuildCollectionfromArrFiltered() As Collection

    'Fonction pour retrouver sur le sous ensemble des données filtrées (Maquette Finale) :
    'Le MaxCrd
    'Le numéro ligne de MaxCRD
    'Dictionnaire des numéros des autres lignes (pour valeurs à 0 si abs(NewCrd)<SumCrd

    Dim clsError                As cls_error_handler
    Dim ArrayIAndMaxCrd         As New Collection
    Dim RngFiltered             As Range
    Dim cell                    As Range
    Dim DictTempRowsElse        As New Dictionary
    Dim MaxCrd                  As Variant
    Dim IMaxCrd                 As Integer
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctBuildCollectionfromArrFiltered"
    
    Set RngFiltered = sht_maq_traitement1.AutoFilter.Range.Columns(21).SpecialCells(xlCellTypeVisible)

    For Each cell In RngFiltered.Cells
        If cell.row > sht_maq_traitement1.AutoFilter.Range.row Then
            If Abs(cell.value) > 0 Then
                DictTempRowsElse.Add cell.row, ""
            End If
            If Abs(cell.value) >= CDbl(MaxCrd) Then
                MaxCrd = cell.value
                IMaxCrd = cell.row
            End If
        End If
    Next cell
    
    ArrayIAndMaxCrd.Add IMaxCrd, "row i Max CRD"
    ArrayIAndMaxCrd.Add MaxCrd, "value Max CRD"
    
    If Not MaxCrd = 0 Then
        DictTempRowsElse.Remove ArrayIAndMaxCrd("row i Max CRD")
        ArrayIAndMaxCrd.Add DictTempRowsElse, "Dictionary i rows else Max CRD"
    End If
    
    Set FctBuildCollectionfromArrFiltered = ArrayIAndMaxCrd
    Set ArrayIAndMaxCrd = Nothing
    
End Function

Function FctDictIChangeAandP(DictTempICrdMax As Dictionary) As Dictionary

    'Fonction Gérér Exception Commuter Actif-Passif si Exception(mapping)
    
    Dim clsError                        As cls_error_handler
    Dim ArrMaquetteFinale               As Variant
    Dim KeyValueToFilter                As Variant
    Dim ColMaqFinaleGrappeBilanSteve    As Integer
    Dim ColMaqFinaleGrappeDevise        As Integer
    Dim ColMaqFinaleGrappeDomaine       As Integer
    Dim i                               As Long
    Dim LastRow                         As Long
    Dim LastCol                         As Integer
    
    Set DictTempIChangeAandP = New Dictionary
    
    Set clsError = New cls_error_handler: clsError.SetLoc "Mod_Step5NewTreatment", "FctIChangeAandP"
    BoolIChangeAandP = False
    ColMaqFinaleGrappeBilanSteve = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_GrappeBilanSteve)
    ColMaqFinaleGrappeDevise = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_Devise)
    ColMaqFinaleGrappeDomaine = FctGetNumColumn(sht_maq_traitement1, PublicVarStr_Domaine)
    
    With sht_maq_traitement1
        LastCol = .Cells(.Range("A1").row, .Columns.count).End(xlToLeft).Column
        LastRow = .Cells(Rows.count, "A").End(xlUp).row
        ArrMaquetteFinale = .Range("A1" & ":" & FctGetColLetterFromInt(LastCol) & LastRow)
    End With
    
    If Not DictTempICrdMax.count = 0 Then
        
        BoolIChangeAandP = True
        For Each KeyValueToFilter In DictTempICrdMax.Keys
        
            For i = LBound(ArrMaquetteFinale, 1) To UBound(ArrMaquetteFinale, 1)
                If ArrMaquetteFinale(i, ColMaqFinaleGrappeBilanSteve) = Split(DictTempICrdMax(KeyValueToFilter), PublicVarSplit)(0) And _
                        ArrMaquetteFinale(i, ColMaqFinaleGrappeDevise) = Split(DictTempICrdMax(KeyValueToFilter), PublicVarSplit)(1) And _
                        ArrMaquetteFinale(i, ColMaqFinaleGrappeDomaine) = Split(DictTempICrdMax(KeyValueToFilter), PublicVarSplit)(2) Then
                        
                    DictTempIChangeAandP.Add i, ""
                End If
            Next i
        Next KeyValueToFilter
    Else
        Exit Function
    End If

    Set FctDictIChangeAandP = FctIfDictIsNotEmpty(DictTempIChangeAandP, "Function FctDictIChangeAandP")
   
End Function

Function StepDebugPrint(DictArrControle As Dictionary, KeyTemp As Variant, CollectionfromArrFiltered As Variant)
    Debug.Print "Chiffre Cible(TCD Controle) :" & DictArrControle(KeyTemp)(0) & vbNewLine _
            ; "Ecart(TCD Controle):" & DictArrControle(KeyTemp)(1) & vbNewLine _
            ; "Somme de CRD (TCD Controle):" & DictArrControle(KeyTemp)(2) & vbNewLine _
            ; "Filtre Concat(TCD Controle-Maquette Finale):" & KeyTemp & vbNewLine _
            ; "Max CRD(Maquette Finale):"; CollectionfromArrFiltered(1) & vbNewLine _
            ; "Ligne i associé:(Maquette Finale):"; CollectionfromArrFiltered(0)
End Function
```

## cls_error_handler

```
Option Explicit
Public description
Private mlErrorID       As Long
Private msProcedureName As String
Private msModuleName    As String
Public msFirstError     As Boolean
'

Sub handle_error(ByVal my_error As ErrObject)

    Select Case my_error.Number
        Case 0
            Exit Sub
        Case 1
            Call Logger.LogContent("Custom Error (" & Now() & ")" & Space(1) & "occured in" & Space(1) & Me.description, , , True)
            'Call EndProcessUserForm
            MsgBox Me.description, vbCritical
            'End
        Case Else
            Call Logger.LogContent("Error number : " & my_error.Number & " ----- Description : " & Me.description)
            'Call EndProcessUserForm

            MsgBox Me.description, vbCritical
    End Select

End Sub

    '================================================================================================================='
    '===============================================RAII=============================================================='
    '================================================================================================================='
    
'Resource acquisition is initialization (Bjarne Stroustrup)
Private Sub Class_Terminate()
    If Err.Number > 0 Then
        If PublicFirstError = False Then
            Debug.Print "Error (" & Now() & ")" & Space(1) & "occured in" & Space(1) & Me.Location & ", " & Me.ErrDescription
            MsgBox "Error (" & Now() & ")" & Space(1) & "occured in" & Space(1) & Me.Location & ", " & Me.ErrDescription, vbInformation, Error & Space(1) & Split(Me.Location, "]")(1)
            Call Logger.LogContent("Error (" & Now() & ")" & Space(1) & "occured in" & Space(1) & Me.Location & ", " & Me.ErrDescription)
            PublicFirstError = True
        Else
            Call Logger.LogContent("Procedure called in:" & Space(1) & Split(Me.Location, "]")(1))
        End If
    End If
End Sub
    
Public Property Get ModuleName() As String
    ModuleName = msModuleName
End Property
Public Property Let ModuleName(ByVal sModuleName As String)
    msModuleName = sModuleName
End Property

Public Property Get ErrorID() As Long
    ErrorID = mlErrorID
End Property
Public Property Let ErrorID(ByVal lErrorID As Long)
    mlErrorID = lErrorID
End Property

Public Property Get ProcedureName() As String
    ProcedureName = msProcedureName
End Property
Public Property Let ProcedureName(ByVal sProcedureName As String)
    msProcedureName = sProcedureName
End Property
 
Static Sub SetLoc(ByVal sModule As String, ByVal sProc As String)
    Me.ModuleName = sModule
    Me.ProcedureName = sProc
End Sub
 
Static Property Get Location() As String
    Location = "[" & ThisWorkbook.Name & "]" & Me.ModuleName & "." & Me.ProcedureName
End Property
 
Public Property Get ErrDescription() As String
    ErrDescription = "Error " & Err.Number & ": " & Err.description
End Property

    '================================================================================================================='
    '==============================================Insert Error Handling=============================================='
    '================================================================================================================='
    
Public Sub InsertErrHandling(modName As String)
    
    Dim Component As Object
    Dim Name As String
    Dim Kind As Long
    
    Dim lngFirstLine_Start As Long
    Dim lngFirstLine_End As Long
    Dim intFirstLine_Len As Integer
    
    Dim ProcLinesCount As Long
    Dim Declaration As String
    Dim ProcedureType As String
    Dim Index As Long
    Dim i As Long
    Dim j As Long
    Dim LastLine As Long
    Dim StartLines As Collection
    Dim LastLines As Collection
    Dim ProcNames As Collection
    Dim ProcedureTypes As Collection
    Dim gotoErr As Boolean
    
    Dim t As Integer
    Dim c As Integer
    Dim strTest As String
    Dim strModuleType As String
    
    'Kind = 0
    'Kind = vbext_pk_Proc
    
    Set StartLines = New Collection
    Set LastLines = New Collection
    Set ProcNames = New Collection
    Set ProcedureTypes = New Collection

    Set Component = Application.VBE.ActiveVBProject.VBComponents(modName) ' modName = form/module name
        With Component.CodeModule

            ' Remove empty lines on the end of the code
            For i = .CountOfLines To 1 Step -1
                If Component.CodeModule.Lines(i, 1) = "" Then
                  Component.CodeModule.DeleteLines i, 1
                Else
                    Exit For
                End If
            Next i

            Index = .CountOfDeclarationLines + 1
            Do While Index < .CountOfLines
                gotoErr = False          ' Flag to indicate exising error handling
                Name = .ProcOfLine(Index, Kind)     ' Get proc name
                'FirstLine = .ProcBodyLine(Name, Kind)       ' Line number of first code line (declaration)  *Bad
                
                lngFirstLine_Start = .ProcBodyLine(Name, Kind)     ' Line number of first code line (declaration)  *Bad
                lngFirstLine_End = lngFirstLine_Start
                intFirstLine_Len = 1
                
                ' Next line includes empty lines and comments!
                ProcLinesCount = .ProcCountLines(Name, Kind)    ' Number of lines in procedure
                
                Declaration = Trim(.Lines(lngFirstLine_Start, 1))       ' Get full proc declaration
                
                Do While Right(Declaration, 1) = "_"
                    ' This is a split declaration
                    lngFirstLine_End = lngFirstLine_Start + intFirstLine_Len
                    Declaration = Trim(.Lines(lngFirstLine_Start, intFirstLine_Len + 1))
                    intFirstLine_Len = intFirstLine_Len + 1
                Loop
                
                'This is incorrect
'                LastLine = lngFirstLine_Start + ProcLinesCount - 2       ' Line number of last line  *Bad
                
                If InStr(1, Declaration, "Function ", vbBinaryCompare) > 0 Then ' Get proc type
                    ProcedureType = "Function"
                Else
                    ProcedureType = "Sub"
                End If
                
                
                'Get correct last line
                strTest = ""
                LastLine = 0
                For t = lngFirstLine_Start To (lngFirstLine_Start + ProcLinesCount)
                    strTest = Trim(.Lines(t, 1))
                    If strTest Like "*End " & ProcedureType & "*" Then
                        LastLine = t
                        Exit For
                    End If
                Next t
                
                If LastLine = 0 Then
                    LastLine = lngFirstLine_Start + ProcLinesCount - 2
                End If
                
                
                'Show details
                'Debug.Print Component.Name & "." & Name, "First: " & lngFirstLine_Start, "Lines:" & _
                            ProcLinesCount, "Last: " & LastLine, Declaration

                ' do not insert error handling if there is one already:
                For i = lngFirstLine_Start To LastLine Step 1
                    If Component.CodeModule.Lines(i, 1) Like "*On Error*" Then
                        gotoErr = True
                        Exit For
                    End If
                    If Component.Name = "modError" Then ' Module that this code is in!
                        gotoErr = True
                        Exit For
                    End If
                Next i
                
                If Not gotoErr Then   ' If FALSE then add error trapping
                    StartLines.Add lngFirstLine_End
                    LastLines.Add LastLine
                    ProcNames.Add Name
                    ProcedureTypes.Add ProcedureType
                Else
                    Debug.Print Component.Name & "." & Name, "Existing Error handling"
                End If

                'Index = lngFirstLine_Start + ProcLinesCount + 1
                Index = LastLine + 1    '?
                
            Loop

            For i = LastLines.count To 1 Step -1
                If Not (Component.CodeModule.Lines(StartLines.item(i) + 1, 1) Like "*On Error GoTo *") Then
                    If (Component.CodeModule.Lines(LastLines.item(i) - 1, 1)) Like "*End " & ProcedureTypes.item(i) Then
                        j = LastLines.item(i) - 1
                    Else
                        j = LastLines.item(i)
                    End If
                    
                    'Add lines to end of procedure
                    Component.CodeModule.InsertLines j, vbCrLf
                    Component.CodeModule.InsertLines j + 1, "ErrorExit:"
                    Component.CodeModule.InsertLines j + 2, "    "
                    
                    If Left(Component.Name, 8) = "Form_frm" Then
                        Component.CodeModule.InsertLines j + 3, "    <Company specific code here - Only for Forms>"
                    End If
                    
                    Component.CodeModule.InsertLines j + 4, "    Exit " & ProcedureTypes.item(i)
                    Component.CodeModule.InsertLines j + 5, vbCrLf
                    Component.CodeModule.InsertLines j + 6, "ErrorHandler:"
                    Component.CodeModule.InsertLines j + 7, "    ErrorManager.description =  """ & modName & """ & """ & ProcNames.item(i) & """ &  """ & "error msg" & """"
                    Component.CodeModule.InsertLines j + 8, "    Err.Number = 1"
                    Component.CodeModule.InsertLines j + 9, "    Call ErrorManager.handle_error(Err)"
                    Component.CodeModule.InsertLines j + 10, "    Resume ErrorExit"
                    
                    ' Add lines to start of procedure
                    Component.CodeModule.InsertLines StartLines.item(i) + 1, vbCrLf
                    Component.CodeModule.InsertLines StartLines.item(i) + 2, "    Dim clsError    As cls_error_handler"
                    Component.CodeModule.InsertLines StartLines.item(i) + 3, vbCrLf
                    Component.CodeModule.InsertLines StartLines.item(i) + 4, "    If BoolErrorHandler = True Then On Error GoTo ErrorHandler"
                    Component.CodeModule.InsertLines StartLines.item(i) + 5, vbCrLf
                    Component.CodeModule.InsertLines StartLines.item(i) + 6, "    Set clsError = New cls_error_handler: clsError.SetLoc """ & modName & ","" & """ & ProcNames.item(i) & """"
                    
                    'Debug.Print Component.Name & "." & ProcNames.item(i), "First: " & StartLines.item(i), "Last: " & j, "   Inserted"
                End If
            Next i
        End With
        
End Sub

    '================================================================================================================='
    '===============================================CUSTOM ERROR======================================================'
    '================================================================================================================='
    
'
'Public Enum CustomError
'    CustomError1 = vbObjectError + 42
'    CustomError2 = vbObjectError + 43
'    CustomError3 = vbObjectError + 44
'    CustomError4 = vbObjectError + 45
'    CustomError5 = vbObjectError + 46
'End Enum
'Public Sub CustomErrorHandler(Err As Object)
'    Select Case Err.Number
'        Case CustomError.CustomError1
'            MsgBox "Custom Error Message 1", vbExclamation
'
'        Case CustomError.CustomError2
'            MsgBox "Custom Error Message 2", vbExclamation
'
'        Case CustomError.CustomError3
'            MsgBox "Custom Error Message 3", vbExclamation
'
'        Case CustomError.CustomError4
'            MsgBox "Custom Error Message 4", vbExclamation
'
'        Case CustomError.CustomError5
'            MsgBox "Custom Error Message 5", vbExclamation
'
'        Case Else
'            MsgBox "Unexpected Error: " & Err.Number & "- " & Err.description, vbCritical
'    End Select
'End Sub

```

## cls_logger
```
Option Explicit

Private Sub AddToTextFile(ByVal Content As String, ByVal path As String)

    Dim fso As New FileSystemObject
    Dim ts As TextStream
    
    Set ts = fso.OpenTextFile(path, ForAppending)
    ts.WriteLine Content
    ts.Close
    
    Set ts = Nothing
    Set fso = Nothing

End Sub

Private Sub SaveNewText(ByVal Content As String, ByVal path As String)

    Dim fso As New FileSystemObject
    Dim file As Object
    
    Set file = fso.CreateTextFile(path)
    file.WriteLine Content
    file.Close
    
    Set fso = Nothing
    Set file = Nothing

End Sub

Public Function SectionHeader(ByVal descriptor As String) As String

    Dim Result As String
    Dim edge As String
    edge = "'"
    Result = edge & String(Len(descriptor) + 2, edge) & edge & vbCrLf _
           & edge & " " & descriptor & " " & edge & vbCrLf _
           & edge & String(Len(descriptor) + 2, edge) & edge
    SectionHeader = Result
    
End Function

Public Function ConsoleHeader(ByVal descriptor As String) As String

    Dim Result As String
    Dim corner As String
    Dim vertice As String
    Dim horizon As String
    corner = "+"
    vertice = "|"
    horizon = "-"
    Result = corner & String(Len(descriptor) + 2, horizon) & corner & vbCrLf _
           & vertice & " " & descriptor & " " & vertice & vbCrLf _
           & corner & String(Len(descriptor) + 2, horizon) & corner
    ConsoleHeader = Result
    
End Function


Public Sub LogContent(ByVal Content As String, Optional header As Boolean, Optional log_ut As Boolean, Optional CustomMsg As Boolean)

    Dim fso As New FileSystemObject
    Dim logs As String
    Dim path As String
   
    On Error GoTo ErrorHandler
    
    path = ThisWorkbook.FullName & "\.."
    
    If Not header Then Application.StatusBar = Content
    
    If header Then
        logs = "--------------------------- " & Content & " ---------------------------"
    Else
        If log_ut Then
            logs = Now() & ";" & Environ("UserName") & ";" & Content
        ElseIf CustomMsg Then
            logs = ConsoleHeader(Content)
        Else
            logs = Content
        End If
    End If
    
    If Not fso.FileExists(path & "\log.txt") Then
        Call SaveNewText(logs, path & "\log.txt")
    Else
        Call AddToTextFile(logs, path & "\log.txt")
    End If
    
ErrorHandler:


End Sub
```

## cls_timer


```
Option Explicit

#If Win64 And VBA7 Then
    Private Declare PtrSafe Function GetTickCount64 Lib "kernel32" () As LongPtr
    Private previous As LongPtr
    Private paused_time As LongPtr
#Else
    Private Declare Function get_tick_count Lib "kernel32" () As Long
    Private previous As Long
    Private paused_time As Long
#End If

Private start_time As Date
Private paused As Boolean

Public Function start()
    start_time = Now()
    previous = 0
    paused_time = 0
    paused = False
    start = start_time
End Function

Public Sub pause()
    If Not paused Then
        previous = GetTicks
        paused = True
    End If
End Sub

Public Sub un_pause()
    If paused Then
        paused_time = paused_time + Abs(GetTicks - previous)
        paused = False
    End If
End Sub

Public Function stop_timer() As Date
    stop_timer = Abs((Now() - start_time) - Ticks2Time(paused_time))
End Function

#If Win64 And VBA7 Then
    Private Function Ticks2Time(ByVal Ticks As LongPtr) As Date
#Else
    Private Function Ticks2Time(ByVal Ticks As Long) As Date
#End If

    Ticks2Time = (Ticks / 1000) * CDbl(TimeValue("00:00:01"))
End Function

#If Win64 And VBA7 Then
    Private Function GetTicks() As LongPtr
        GetTicks = GetTickCount64
#Else
    Private Function GetTicks() As Long
        GetTicks = get_tick_count
#End If
End Function
```

## bar progress

dans mod userform :UserformProgressBar
label description :lbl_description
frame : frm_progress
label progress:lbl_progress

```
Option Explicit
Public my_width As Double
Public Sub update_progress(ByVal pourcentage As Double)

    With Me
        .frm_progress.Caption = Format(pourcentage, "0%")
        .lbl_progress.Width = pourcentage * Me.my_width
        .Repaint
    End With
    
End Sub
Public Sub set_description(ByVal text As String, ByVal no_log As Boolean)
    
    Me.lbl_description.Caption = text
    'If Not no_log Then Call Logger.log_content(text)
    DoEvents
    
End Sub
Private Sub UserForm_Initialize()

    Call HideTitleBar(Me)
    
    With Me
        .lbl_progress.Width = 0
        .my_width = 399.7
    End With
    
End Sub
Public Function update(ByVal step As Long, ByVal total_step As Long, ByVal text As String, Optional ByVal no_log As Boolean) As Long
    
    DoEvents
    Me.frm_progress.SetFocus
    Call Me.set_description(text, no_log)
    Call Me.update_progress(step / total_step)
    
    update = step + 1
    
End Function



```

# up

## cls_ArrResult
```
Private CpyCode_                As Variant
Private PnbAmount_              As Variant
Private GladId_                 As Variant
Private i_                      As Integer
Private NegociationStartDate_   As String
Private ComputationMethod_      As String
Private CpyName_                As String
Private ProfitCenter_           As String
Private ProductLine_            As String
Private GladDate_               As String
Private RwaAmount_              As Variant
Private ElAmount_               As Variant
Private Comment_                As String
Private LocalRevenueTypeCode_   As String
Private Rating_                 As String
Private TypeCouverture_         As String

Public Function ArrResultFtp() As Variant
  
    Dim ArrFtpTemp  As Variant
    ReDim ArrFtpTemp(1 To 1, 1 To 27)
    
    ArrFtpTemp(i, 1) = CstFtp.Action 
    ArrFtpTemp(i, 2) = Me.NegociationStartDate
    'Computation Method
    ArrFtpTemp(i, 3) = Me.ComputationMethod
End Function 


Public Function ArrResultNeoclip() As Variant
  
    Dim ArrNeoclipTemp As Variant
    ReDim ArrNeoclipTemp(1 To 1, 1 To 26)
    

    ArrNeoclipTemp(i, 1) = fct_neoclip_TransactionCode(NegociationStartDate, LocalRevenueTypeCode, CpyCode, ProfitCenter, TypeCouverture, CStr(GladId))
    ArrNeoclipTemp(i, 2) = "" 
    ArrNeoclipTemp(i, 3) = "" 
    'LocalRevenueTypeCode
    ArrNeoclipTemp(i, 4) = Me.LocalRevenueTypeCode
    ArrNeoclipTemp(i, 5) = "" 'LocalRevenueTypeName
    ArrNeoclipTemp(i, 6) = CstNeoclip.LocalInstrumentCode
	
End Function

  
Property Get i() As Integer
    i = i_
End Property
Property Let i(IntI As Integer)
    i_ = IntI
End Property
                                   
Property Get TypeCouverture() As String
    TypeCouverture = TypeCouverture_
End Property
Property Let TypeCouverture(StrTypeCouverture As String)
    TypeCouverture_ = StrTypeCouverture
End Property
                                                       
Property Get GladId() As Variant
    GladId = GladId_
End Property
Property Let GladId(VarGladId As Variant)
    GladId_ = VarGladId
End Property

```

## cls_db_archive

```
Option Explicit
Private path_archive_db As String
Private o_db As ADODB.Connection
'

Private Sub Class_Initialize()
    path_archive_db = ws_main.Range("rng_archive_db").Value
End Sub

Public Function db() As ADODB.Connection
    If o_db Is Nothing Then
        Set o_db = New ADODB.Connection
        o_db.Open "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " & path_archive_db
    End If
    Set db = o_db
End Function

Private Function fct_DeleteData_InArchiveDB(ws_var As String, date_YYYYDD_var As String)

    Dim sql_query As String

    sql_query = "DELETE * FROM §p1§ WHERE §p1§.Prod_Date ='§p2§'"
    sql_query = Replace(sql_query, "§p1§", ws_var)
    sql_query = Replace(sql_query, "§p2§", date_YYYYDD_var)

    Me.db.Execute sql_query

End Function

Public Function fct_ImportData_InArchiveDB(ws_var As String, date_YYYYDD_var As String)
    
    Dim rs_db       As New ADODB.Recordset
    Dim var_data    As Variant
    
    Dim i           As Long
    Dim j           As Long
    Dim sql_query   As String
    Dim ut          As String
    Dim importDate  As Date
    Dim answer      As Integer
    
    var_data = Sheets(ws_var).Range("A1").CurrentRegion

    sql_query = "SELECT count(§p1§.Prod_Date) FROM §p1§ WHERE §p1§.Prod_Date='§p2§' "
    sql_query = Replace(sql_query, "§p1§", ws_var)
    sql_query = Replace(sql_query, "§p2§", date_YYYYDD_var)
    
    rs_db.Open sql_query, Me.db, adOpenKeyset, adLockReadOnly
    With rs_db
        .MoveLast
        .MoveFirst
        If .Fields(0).Value > 0 Then
            answer = MsgBox("Il y a deja " & .Fields(0).Value & " lignes dans la base d'Archive pour la date du " & date_YYYYDD_var & vbLf & _
            "Voulez vous annule et remplace ces enregistrements", vbQuestion + vbYesNo + vbDefaultButton2, "Import " & ws_var & " in Archive DataBase")
            If answer = vbYes Then
                Call fct_DeleteData_InArchiveDB(ws_var, date_YYYYDD_var)
            Else
                Exit Function
            End If
        End If
    End With
    rs_db.Close
    
    ut = get_ut
    importDate = Now

    rs_db.Open ws_var, Me.db, adOpenKeyset, adLockOptimistic, adCmdTable
    
    With rs_db
        For i = LBound(var_data, 1) + 1 To UBound(var_data, 1)
            .AddNew
            .Fields("Imported_Date") = importDate
            .Fields("Prod_Date") = date_YYYYDD_var
            .Fields("Imported_By") = ut

            For j = LBound(var_data, 2) + 1 To UBound(var_data, 2) + 1
                .Fields(j - 1).Value = CStr(var_data(i, j - 1))
            Next j
        Next i
        .Update
        .Close
    End With
    
    MsgBox "Importation des données :" & ws_var & " pour la date du " & date_YYYYDD_var & " dans la base Archive réussie", vbInformation

End Function

Public Function fct_ExportData_FromArchiveDB(ws_var As String, date_YYYYDD_var As String)

    Dim rs_db       As New ADODB.Recordset
    Dim sql_query   As String
    Dim j           As Long
    
    'Date existe dans base archive
    sql_query = "SELECT count(§p1§.Prod_Date) FROM §p1§ WHERE §p1§.Prod_Date='§p2§' "
    sql_query = Replace(sql_query, "§p1§", ws_var)
    sql_query = Replace(sql_query, "§p2§", date_YYYYDD_var)
    rs_db.Open sql_query, Me.db, adOpenKeyset, adLockReadOnly
    With rs_db
        .MoveLast
        .MoveFirst
        If Not .Fields(0).Value > 0 Then
            MsgBox "La récuperation des données pour : " & ws_var & " pour la date du " & date_YYYYDD_var & " n'existe pas dans la base archive", vbCritical
            Exit Function
        End If
    End With
    rs_db.Close
    
    'Query récuperation des donnnées
    sql_query = "SELECT * FROM §p1§ WHERE §p1§.Prod_Date='§p2§' "
    sql_query = Replace(sql_query, "§p1§", ws_var)
    sql_query = Replace(sql_query, "§p2§", date_YYYYDD_var)
    rs_db.Open sql_query, Me.db
    
'------------------------
'Méthode Variable Tableau
'------------------------
'    rs_db.Open sql_query, Me.db, adOpenKeyset, adLockReadOnly
'    ReDim Output(1 To rs_db.RecordCount + 1, 1 To rs_db.Fields.Count)
'    With rs_db
'        'header
'        For j = 1 To .Fields.Count
'            Output(1, j) = .Fields(j - 1).Name
'        Next j
'
'        'data
'        .MoveLast
'        .MoveFirst
'        For i = 1 To .RecordCount
'            For j = 1 To .Fields.Count
'                Output(i + 1, j) = .Fields(j - 1).Value
'            Next j
'            .MoveNext
'        Next i
'    End With
'    Worksheets(ws_var).Range("A1").Resize(UBound(Output, 1), UBound(Output, 2)) = Output
    
    For j = 0 To rs_db.Fields.Count - 1
        Worksheets(ws_var).Cells(Range("A1").Row, Range("A1").Column + j).Value = rs_db.Fields(j).Name
    Next
    Worksheets(ws_var).Range("A2").CopyFromRecordset rs_db
    
    Call fct_DeleteCol_OutputArchiveDB(ws_var)
    
    MsgBox "Récuperation des données : " & ws_var & " pour la date du " & date_YYYYDD_var & " réussie", vbInformation
    
End Function

Private Function fct_DeleteCol_OutputArchiveDB(ws_var As String)

    Dim arr_ColDelete   As Variant
    Dim elmt            As Variant
    Dim num_col         As Integer
    
    arr_ColDelete = Array("N°", "Imported_Date", "Imported_By", "Prod_Date")
    
    For Each elmt In arr_ColDelete
        num_col = Application.WorksheetFunction.Match(CStr(elmt), Worksheets(ws_var).Rows("1:1"), 0)
        Worksheets(ws_var).Columns(num_col).EntireColumn.Delete
    Next elmt
    
End Function

Public Function fct_ImportSpecificData_InArchiveDB(ws_var As String, date_YYYYDD_var As String)
    
    Dim cn                  As ADODB.Connection
    Dim rs_db               As New ADODB.Recordset
    Dim db_wb_data          As String
    Dim sql_query           As String
    
    Dim liste_ChampsInput   As String
    Dim liste_ChampsPrm     As String
    Dim ut                  As String
    Dim importDate          As Date
    Dim prod_date           As String
    Dim answer              As Integer

    sql_query = "SELECT count(§p1§.Prod_Date) FROM §p1§ WHERE §p1§.Prod_Date='§p2§' "
    sql_query = Replace(sql_query, "§p1§", ws_var)
    sql_query = Replace(sql_query, "§p2§", date_YYYYDD_var)
    
    rs_db.Open sql_query, Me.db, adOpenKeyset, adLockReadOnly
    With rs_db
        .MoveLast
        .MoveFirst
        If .Fields(0).Value > 0 Then
            answer = MsgBox("Il y a deja " & .Fields(0).Value & " lignes dans la base d'Archive pour la date du " & date_YYYYDD_var & vbLf & _
            "Voulez vous annule et remplace ces enregistrements", vbQuestion + vbYesNo + vbDefaultButton2, "Import " & ws_var & " in Archive DataBase")
            If answer = vbYes Then
                Call fct_DeleteData_InArchiveDB(ws_var, date_YYYYDD_var)
            Else
                Exit Function
            End If
        End If
    End With
    rs_db.Close

    'Import des données dans la base
    Set cn = New ADODB.Connection
    cn.Open "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " & ThisWorkbook.FullName & ";Extended Properties=Excel 8.0"
    
    db_wb_data = "[" & ws_var & "$]"
    ut = "'" & get_ut & "'"
    importDate = Now
    prod_date = "'" & date_YYYYDD_var & "'"
    
    
    Select Case ws_var
    
    Case "GAP3"
        liste_ChampsInput = "[Clc_Cpy_Code],[Clc_Tie_Alim_Name],[Clc_Ins_Name],[Clc_Nominal_Origine],[Clc_Maturity_Date],[Clc_Protect_Code]," & _
                            "[Clc_Gap_Scaling_Factor],[Clc_Gain_El],[Clc_Sti3_Id],[CLC_BOTRADEID],[Clc_Devise],[Clc_Tie_Alim_Note_Int],"
    Case "PALM"
        liste_ChampsInput = "[MOIS_FIN_SIT],[C_TRA_EAD1_ET_AJST],[C_TRA_RWA1_ET_AJST],[C_TRA_PD1_ET_AJST],[C_TRA_LGD1_ET_AJST],[SLA_AUTHCODE]," & _
                            "[TIERS_ID],[C_GAR_CODE_B],[C_SUR_GARID_B],[CREDITRISK],[C_TRA_PM1_ET],[RATING_COD],[PRODUCTLINECODE],"
    End Select

    liste_ChampsPrm = "[Imported_Date],[Imported_By],[Prod_Date]"
        

    sql_query = "INSERT INTO §p1§ (" & liste_ChampsInput & liste_ChampsPrm & ")" & _
                " in 'C:\HOMEWARE\Dev\Ventilation Optimus Prime\Optimus_Prime.accdb' " & _
                " SELECT " & liste_ChampsInput & "#" & importDate & "#," & ut & "," & prod_date & _
                " FROM " & db_wb_data
    sql_query = Replace(sql_query, "§p1§", ws_var)
                
                
    cn.Execute sql_query
    cn.Close
    Set cn = Nothing
    
    MsgBox "Importation des données :" & ws_var & " pour la date du " & date_YYYYDD_var & " dans la base Archive réussie", vbInformation

End Function
```

## cls_db_import


```
Option Explicit

Private Type db_param
    Name        As String
    Password    As String
    user_id     As String
    Path        As String
    sql_request As String
    ws_name     As String
End Type

Private This As db_param
'

'pour activer la référence à l'instance d'objet de classe (factory pattern)
Public Function Create(ByVal name_var As String, ByVal password_var As String, ByVal user_id_var As String, ByVal path_var As String, ByVal sql_request_var As String, ws_name_var As String) As cls_db_import
    With New cls_db_import
        .Name = name_var
        .Password = password_var
        .user_id = user_id_var
        .Path = path_var
        .sql_request = sql_request_var
        .ws_name = ws_name_var
        Set Create = .Self
    End With
End Function

Public Property Get Self() As cls_db_import
    Set Self = Me
End Property

Sub init(db_name As String)

    Dim class_fastory       As New cls_db_import
    Dim cls_db_instance     As cls_db_import
    Dim sql_request_str     As String
    Dim ws_name_var         As String
    
    Select Case db_name
    
        Case "GAP3" ' Compte Technique
            ws_name_var = CStr(ws_gap3.Name)
            sql_request_str = "select  * from [GAPCALCUL] " & build_where_statement_mx
            Set cls_db_instance = class_fastory.Create("nom_base", "password", "base_READER", "chemin conn", sql_request_str, ws_name_var)
            
        Case "GAP3_RW_PROTECT"
            ws_name_var = CStr(ws_gap3_rw_protect.Name)
            sql_request_str = "Select DISTINCT  [GAPCALCUL].[CLC_PROTECT_TYPE],[GAPCALCUL].[CLC_PROTECT_RW] from [GAPCALCUL]" & build_where_statement_rw_protect
            Set cls_db_instance = class_fastory.Create("GAP2", "motdepasse", "base_READER", "chemin con", sql_request_str, ws_name_var)
            
        Case "PALM" ' Compte Technique
            ws_name_var = ws_palm.Name
            sql_request_str = " SELECT PALM.dbo.VUPLMMTIH_BO.TIERS_ABR,  PALM.dbo.viewBusinessRicosBasle2.MOIS_FIN_SIT, PALM.dbo.viewBusinessRicosBasle2.C_TRA_EAD1_ET_AJST, PALM.dbo.viewBusinessRicosBasle2.C_TRA_RWA1_ET_AJST, PALM.dbo.viewBusinessRicosBasle2.C_TRA_PD1_ET_AJST, " & _
                            " PALM.dbo.viewBusinessRicosBasle2.C_TRA_LGD1_ET_AJST, RTrim(PALM.dbo.VUPLMMENH_BO.SLA_AUTHCODE) AS SLA_AUTHCODE, PALM.dbo.VUPLMMENH_BO.TIERS_ID, RTrim(PALM.dbo.viewBusinessRicosBasle2.C_GAR_CODE_B) AS C_GAR_CODE_B, RTrim(PALM.dbo.viewBusinessRicosBasle2.C_SUR_GARID_B) AS C_SUR_GARID_B , PALM.dbo.viewBusinessRicosBasle2.CREDITRISK, (C_TRA_PD1_ET_AJST * C_TRA_LGD1_ET_AJST  * C_TRA_EAD1_ET_AJST) as EL, PALM.dbo.viewBusinessRicosBasle2.C_TRA_PM1_ET, PALM.dbo.VUPLMMENH_BO.RATING_COD,PALM.dbo.VUPLMMENH_BO.PRODUCTLINECODE" & _
                    " FROM " & _
                            " (PALM.dbo.viewBusinessRicosBasle2 LEFT JOIN PALM.dbo.VUPLMMENH_BO ON PALM.dbo.viewBusinessRicosBasle2.MOIS_FIN_SIT=PALM.dbo.VUPLMMENH_BO.MOIS_FIN_SIT " & _
                    "        and PALM.dbo.viewBusinessRicosBasle2.UNIQUEID=PALM.dbo.VUPLMMENH_BO.UNIQUEID) " & _
                    " LEFT JOIN PALM.dbo.VUPLMMTIH_BO ON  PALM.dbo.VUPLMMENH_BO.TIERS_ID=PALM.dbo.VUPLMMTIH_BO.TIERS_ID AND PALM.dbo.VUPLMMTIH_BO.MOIS_FIN_SIT = PALM.dbo.VUPLMMENH_BO.MOIS_FIN_SIT " & _
                    " where PALM.dbo.viewBusinessRicosBasle2.MOIS_FIN_SIT='" & ws_main.[rng_palm_date] & "'" & build_where_statement_bma & ";"
            
            Set cls_db_instance = class_fastory.Create("PALM", "base.reader", "base_READER", "chemin\chemin", sql_request_str, ws_name_var)
        
        Case "ClientLive" 
            ws_name_var = ws_clientlive.Name
            sql_request_str = "SELECT TOP (1000) [Reference],[ClientName],[STI3], SUBSTRING([GLADiD], PATINDEX('%[^0]%', [GLADiD]+'.'), LEN([GLADiD])),[OP Request Date],[Couverture],[PL],[PLCode],[RwaKey],[NBIKey] FROM [CRMFinDataCenter].[COMMON].[common_OptimusPrimeUDA]"
            Set cls_db_instance = class_fastory.Create("base_name", "", "", "chemin_base", sql_request_str, ws_name_var)
            
    End Select

    This.Name = cls_db_instance.Name
    This.Password = cls_db_instance.Password
    This.user_id = cls_db_instance.user_id
    This.Path = cls_db_instance.Path
    This.sql_request = cls_db_instance.sql_request
    This.ws_name = cls_db_instance.ws_name

End Sub

Function build_where_statement_mx() As String
    
    Dim where_statement As String
    Dim code_or         As String
    Dim code_sti3       As String

    where_statement = "where "
    code_or = "CLC_PROTECT_CODE in ("
    code_or = code_or & Trim(get_NumColumn_Glad(col_glad_murex)) & ")"
    where_statement = where_statement & code_or
 
    code_sti3 = " OR CLC_STI3_ID in (" & Trim(get_NumColumn_Glad(col_glad_itu3)) & ")"
    build_where_statement_mx = where_statement & code_sti3
    
End Function

Function get_NumColumn_Glad(num_col As Integer) As String
    
    Dim elt     As Variant
    Dim my_tab  As Variant
    Dim my_str  As String
    Dim dict As New Dictionary
    Dim i       As Long
    
    my_tab = ws_glad.Range("A1").CurrentRegion
    
    For i = LBound(my_tab, 1) + 1 To UBound(my_tab, 1)
        If Len(Trim(CStr(my_tab(i, num_col)))) > 1 Then
            If my_tab(i, col_glad_flag_op) = "OPTIMUS_PRIME" Then
                If Not dict.Exists(Trim(CStr(my_tab(i, num_col)))) Then
                   dict.Add Trim(CStr(my_tab(i, num_col))), my_tab(i, col_glad_id)
                End If
            End If
        End If
    Next i
    
    my_str = ""
    For Each elt In dict
        my_str = my_str & "'" & elt & "', "
    Next
    
    Set dict = Nothing
    Set my_tab = Nothing
    
    get_NumColumn_Glad = Left(my_str, Len(my_str) - 2)
       
End Function
Private Function build_where_statement_bma() As String
    
    Dim where_statement As String
    Dim itu_string      As String

    where_statement = "and "
    itu_string = "PALM.dbo.VUPLMMENH_BO.SLA_AUTHCODE in ("
    itu_string = itu_string & get_NumColumn_Glad(col_glad_bma) & ")"
    where_statement = where_statement & itu_string
    build_where_statement_bma = where_statement
         
End Function

Private Function build_where_statement_rw_protect() As String
    
    Dim where_statement As String
    Dim rw_protect      As String

    where_statement = "where"
    rw_protect = "[GAPCALCUL].[CLC_PROTECT_TYPE]in ("
    rw_protect = rw_protect & get_NumColumn_Glad(col_program_name) & ")"
    where_statement = where_statement & rw_protect
    build_where_statement_rw_protect = where_statement
        
End Function

Public Property Get Name() As String
    Name = This.Name
End Property

Public Property Let Name(ByVal Value As String)
    This.Name = Value
End Property

Public Property Get Password() As String
    Password = This.Password
End Property

Public Property Let Password(ByVal Value As String)
    This.Password = Value
End Property

Public Property Get user_id() As String
    user_id = This.user_id
End Property

Public Property Let user_id(ByVal Value As String)
    This.user_id = Value
End Property

Public Property Get Path() As String
    Path = This.Path
End Property

Public Property Let Path(ByVal Value As String)
    This.Path = Value
End Property

Public Property Get sql_request() As String
    sql_request = This.sql_request
End Property

Public Property Let sql_request(ByVal Value As String)
    This.sql_request = Value
End Property

Public Property Get ws_name() As String
    ws_name = This.ws_name
End Property

Public Property Let ws_name(ByVal Value As String)
    This.ws_name = Value
End Property

Public Function db_extraction_sql_server(cls_db_instance As cls_db_import) As ADODB.Command

    Dim my_command      As ADODB.Command
    Dim my_con          As ADODB.Connection
    Dim strConn         As String
    Dim Database_Name   As String
    Dim user_id         As String
    Dim Password        As String
    Dim DBPath          As String
    Dim objMyRecordset As Variant
    Dim Col As Long
    
    Set objMyRecordset = New ADODB.Recordset
    
    On Error GoTo error_handler
    
    'Open Connection'
    With cls_db_instance
        Database_Name = .Name
        Password = .Password
        user_id = .user_id
        DBPath = .Path
    End With
    
    strConn = "Driver={SQL Server};Server=" & DBPath & ";Database=" & Database_Name & _
    ";Uid=" & user_id & ";Pwd=" & Password & ";"
    
    Set my_con = New ADODB.Connection
    my_con.ConnectionString = strConn
    
    my_con.CommandTimeout = 500
    my_con.Open
    
    'Set and Excecute SQL Command'
    Set my_command = New ADODB.Command
    Set my_command.ActiveConnection = my_con
    '--
    'Set DBACCESSLOCAL_OpenConnection = my_command
    '--

    my_command.CommandText = cls_db_instance.sql_request
    my_command.CommandType = adCmdText
    my_command.Execute
    
    'Open Recordset'
    Set objMyRecordset.ActiveConnection = my_con
    objMyRecordset.Open my_command

    'Copy Data to Excel'
    Dim rst As Object
    Set rst = my_command.Execute
    
    For Col = 0 To rst.Fields.Count - 1
        Sheets(cls_db_instance.ws_name).Cells(Range("A1").Row, Range("A1").Column + Col).Value = rst.Fields(Col).Name
    Next
    
    Sheets(cls_db_instance.ws_name).Range("A2").CopyFromRecordset (objMyRecordset)
    'MsgBox "Extraction from " & cls_db_instance.Name & " Done !", vbInformation
    
ErrorExit:
    my_con.Close
    Set my_command = Nothing
    Set my_con = Nothing
    Set rst = Nothing
    Exit Function
    
error_handler:
    MsgBox "Error Import From : " & cls_db_instance.Name, vbInformation, "Import Data SQL Server"
    Set db_extraction_sql_server = Nothing
    Resume ErrorExit
    
End Function

Public Function ImportDataGlad()

    Dim tab_title   As Variant
    Dim objHTTP     As Object
    Dim json_object As Object
    Dim data_item   As Object
    Dim url         As String
    Dim str_result  As String
    Dim json        As String
    Dim i           As Long
    
    On Error GoTo error_handler:
    
    Set objHTTP = CreateObject("WinHttp.WinHttpRequest.5.1")
    'url = "https://glad.loanscape.cm.par.emea.cib:10443/api/uda?token=dWRhOmF1dGhlbnRpY2F0aW9udG9rZW4="
    
    url = CStr(ws_main.[rng_api_glad])
    objHTTP.Open "GET", url, False
    objHTTP.send
    str_result = objHTTP.responseText
    json = str_result
     
    Set json_object = Mod_JsonConverter.ParseJson(json)
    ws_glad.Cells.Clear
    
    ReDim tab_title(1 To 13, 1 To 1)
    tab_title(1, 1) = "solutionId"
    tab_title(2, 1) = "sti3"
    tab_title(3, 1) = "bmaF2"
    tab_title(4, 1) = "guarantorRicosId"
    tab_title(5, 1) = "backOfficeId"
    tab_title(6, 1) = "solutionType"
    tab_title(7, 1) = "flagCode"
    tab_title(8, 1) = "programName"
    tab_title(9, 1) = "executedAmount"
    tab_title(10, 1) = "executedFeesPaidToInvestor"
    tab_title(11, 1) = "executedExecutionDate"
    tab_title(12, 1) = "premiumPaidToInsurersBp"
    tab_title(13, 1) = "counterpartyRicosId"
    ws_glad.Range("A1").Resize(1, UBound(Application.Transpose(tab_title), 1)) = Application.Transpose(tab_title)
    
    ws_glad.Range("P1").Value = Now
    i = 1
    For Each data_item In json_object
        ws_glad.Range("A1").Offset(i).Value = data_item("solutionId")
        ws_glad.Range("B1").Offset(i).Value = data_item("sti3")
        ws_glad.Range("C1").Offset(i).Value = "'" & Right(data_item("bmaF2"), 10)
        ws_glad.Range("D1").Offset(i).Value = "'" & data_item("guarantorRicosId")
        ws_glad.Range("E1").Offset(i).Value = data_item("backOfficeId")
        ws_glad.Range("F1").Offset(i).Value = data_item("solutionType")
        ws_glad.Range("G1").Offset(i).Value = data_item("flagCode")
        ws_glad.Range("H1").Offset(i).Value = data_item("programName")
        ws_glad.Range("I1").Offset(i).Value = data_item("executedAmount")
        ws_glad.Range("J1").Offset(i).Value = data_item("executedFeesPaidToInvestor")
        ws_glad.Range("K1").Offset(i).Value = data_item("executedExecutionDate")
        ws_glad.Range("L1").Offset(i).Value = data_item("premiumPaidToInsurersBp")
        ws_glad.Range("M1").Offset(i).Value = "'" & data_item("counterpartyRicosId")
        i = i + 1
    Next
    
    Call fct_CopyTitle(ws_glad, ws_modify_WsGlad)
    
    'MsgBox "Import Data from API GLAD done !", vbInformation, "Optimus Prime"

    Exit Function
    
error_handler:
    MsgBox "Error on API GLAD, please contact : FIN-FPM-ACP-Commandos@msx.cib.cal", vbInformation, "Optimus Prime"
    
End Function

'Plus utilisé actuellement (Import API)
'Private Sub db_extraction_postgresql()
'
'    Dim conn    As New ADODB.Connection
'    Dim cmd     As New ADODB.Command
'    Dim rs      As New ADODB.Recordset
'    Dim strSQL  As String
'    Dim i       As Integer
'
'    conn.ConnectionString = "Driver={PostgreSQL UNICODE};Server=upvpadb0000001u;Port=5432;Database=glad;Uid=ut330l@emea.cib;Pwd="";sslmode=require;"
'    conn.Open
'    strSQL = "SELECT * FROM glad.optimus_prime_executed_solutions_view" '
'    cmd.CommandType = ADODB.CommandTypeEnum.adCmdText
'    cmd.ActiveConnection = conn
'    cmd.CommandText = strSQL
'
'    Set rs = New ADODB.Recordset
'    Set rs = cmd.Execute
'
'    For i = 1 To rs.Fields.Count
'        ActiveSheet.Cells(1, i).Value = rs.Fields(i - 1).Name
'    Next i
'    ActiveSheet.Range(ActiveSheet.Cells(1, 1), _
'    ActiveSheet.Cells(1, rs.Fields.Count)).Font.Bold = True
'    ActiveSheet.Range("A2").CopyFromRecordset rs
'
'    Set rs = Nothing
'    Set cmd = Nothing
'    conn.Close
'
'End Sub

'Private Function fromArrayToSQL(v_array As Variant) As String
'
'    Dim res As String
'    Dim i As Integer
'
'    res = "("
'    For i = LBound(v_array) To UBound(v_array)
'        res = res + CStr(v_array(i, 1)) + ","
'    Next i
'    res = res + ")"
'    fromArrayToSQL = res
'
'End Function


```

modu
```
Sub ImportDataClientLive(Optional BoolAllImport As Boolean)

    Dim db_clientlive As New cls_db_import
    Dim LastCol As Integer
    
    ws_clientlive.Cells.Clear
    db_clientlive.init ("ClientLive")
    Call db_clientlive.db_extraction_sql_server(db_clientlive)
    
    ws_clientlive.Range("D1") = "GLADiD"
    

    LastCol = ws_clientlive.Cells(ws_clientlive.Range("A1").Row, ws_clientlive.Columns.Count).End(xlToLeft).Column
    ws_clientlive.Cells(1, LastCol + 2) = Now
    
    Call fct_CopyTitle(ws_clientlive, ws_modify_WsClientLive)
    If Not BoolAllImport Then
        MsgBox "Import Data from ClientLive" & " Done !", vbInformation
    End If
    
End Sub
```

## tools

```
Function FctOptimizeVBA(isOn As Boolean)
    Application.EnableEvents = Not (isOn)
    Application.ScreenUpdating = Not (isOn)
    Application.DisplayAlerts = Not (isOn)
    Application.DisplayStatusBar = Not (isOn)
    Application.AskToUpdateLinks = Not (isOn)
End Function

Function FctCheckDataInput(Optional BoolPalm As Boolean)

    Dim KeyWs   As Variant
    Dim LastRow As Long
    Dim WsTemp  As Worksheet
    Dim DictTemp As New Dictionary
    
    DictTemp.Add ws_clientlive.Name, ""
    DictTemp.Add ws_glad.Name, ""
    DictTemp.Add ws_gap3.Name, ""
    
    If BoolPalm = True Then
        DictTemp.Add ws_palm.Name, ""
    End If
    For Each KeyWs In DictTemp.Keys
        Set WsTemp = Workbooks(CStr(ThisWorkbook.Name)).Worksheets(CStr(KeyWs))
        LastRow = WsTemp.Cells(Rows.Count, "A").End(xlUp).Row
        If Not LastRow > 2 Then
            MsgBox "No Data in : " & KeyWs & " please import data", vbInformation, "Check Data"
            End
        End If
    Next KeyWs

    Set DictTemp = Nothing
    Set WsTemp = Nothing

End Function

Function fct_display_title(bool_all_ventilation As Boolean, type_output As String)

    Dim ws_output                       As Worksheet
    Dim last_row_after_raw_no_empty     As Integer
    Dim tab_title                       As Variant
    Dim rng                             As Range
    
    Select Case type_output
        Case "FTP"
            Set ws_output = Worksheets(CStr(ws_ftp.Name))
            tab_title = tab_result_title_ftp
        Case "Neoclip"
            Set ws_output = Worksheets(CStr(ws_neoclip.Name))
            tab_title = tab_result_title_neoclip
    End Select

    If bool_all_ventilation = False Then
        With ws_output
            .Rows(1).AutoFilter
            last_row_after_raw_no_empty = .Cells(Rows.Count, "A").End(xlUp).Offset(1, 0).Row
            Set rng = .Range("A1", .Range("A1").End(xlDown))
            Set rng = .Range(rng, rng.End(xlToRight))
            rng.Clear
            Set rng = Nothing
            .Range("A1").Resize(UBound(tab_title, 1), UBound(tab_title, 2)) = tab_title
        End With
    End If

    Set tab_title = Nothing

End Function

Function fct_display_result(type_output As String, Tab_result As Variant)

    Dim ws_output                       As Worksheet
    Dim tab_title                       As Variant
    Dim rng                             As Range
    Dim last_row_after_raw_no_empty     As Integer
    
    Select Case type_output
        Case "FTP"
            Set ws_output = Worksheets(CStr(ws_ftp.Name))
        Case "Neoclip"
            Set ws_output = Worksheets(CStr(ws_neoclip.Name))
    End Select

    With ws_output
        last_row_after_raw_no_empty = .Cells(Rows.Count, "A").End(xlUp).Offset(1, 0).Row
        .Range("A" & last_row_after_raw_no_empty).Resize(UBound(Tab_result, 1), UBound(Tab_result, 2)) = Tab_result
        
        If type_output = "Neoclip" Then
            .Columns("P:P").NumberFormat = "@"
        End If
    End With

End Function

Function fct_CopyTitle(ws_TitleCopy As Worksheet, ws_TitlePaste As Worksheet)

    Dim tab_title       As Variant
    Dim last_row        As Integer
    Dim last_col        As Integer
    Dim rng             As Range
    Dim range_values    As Range
    Dim i               As Integer

    With ws_TitleCopy
        last_row = .Range("A1").End(xlDown).Row
        last_col = .Range("A1").End(xlToRight).Column
        Set rng = .Range("A1", .Cells(1, last_col))
    End With

    ReDim tab_title(1 To last_col, 1 To 1)
    
    i = 1
    For Each range_values In rng
        tab_title(i, 1) = CStr(range_values)
        i = i + 1
    Next range_values
    
    ws_TitlePaste.Range("A1").Resize(1, UBound(Application.Transpose(tab_title), 1)) = Application.Transpose(tab_title)

Function PrintDict(DictTemp As Dictionary)
    Dim Key As Variant
    For Each Key In DictTemp.Keys
        Debug.Print Key, DictTemp(Key)
    Next Key
End Function

Function PrintDictArrItem(DictTemp As Dictionary, NbArray As Integer)
    Dim Key         As Variant
    Dim ArrItem     As Variant
    Dim i           As Integer
    For Each Key In DictTemp.Keys
        ArrItem = ""
        For i = 0 To NbArray - 1
            ArrItem = ArrItem & "|" & DictTemp(Key)(i)
        Next i
        Debug.Print Key, ArrItem
    Next Key
End Function

Sub PrintArray(arr As Variant, headerText As String)
    Dim entry As Variant
    Debug.Print vbNewLine & headerText
    For Each entry In arr
        Debug.Print entry
    Next
End Sub

Function Percent(var_num As Variant)
    Dim cell As Variant
    Dim cellValue As Variant
    For Each cell In Selection
        With cell
            cellValue = .text
            MsgBox cellValue
            If (var_num Like "[0-9]*%") Then
                .NumberFormat = "General"
                .Value = .Value * 100
                Exit Function
            End If
        End With
    Next
End Function

Public Function get_ut() As String
    get_ut = LCase(Environ("username"))
End Function

Function file_exist(FilePath As String) As Boolean
    Dim test_str As String
    On Error Resume Next
    test_str = Dir(FilePath)
    On Error GoTo 0
    If test_str = "" Then
        file_exist = False
    Else
        file_exist = True
    End If
End Function

Public Function sheet_exists(sheetToFind As String, Optional InWorkbook As Workbook) As Boolean

    Dim Sheet As Object
    
    If InWorkbook Is Nothing Then Set InWorkbook = ThisWorkbook

    For Each Sheet In InWorkbook.Sheets
        If sheetToFind = Sheet.Name Then
            sheet_exists = True
            Exit Function
        End If
    Next Sheet

    sheet_exists = False
    
End Function

Public Function path_exists(pname) As Boolean
    ' Returns TRUE if the path exists
    If Dir(pname, vbDirectory) = "" Or pname = "" Then
        path_exists = False
    Else
        path_exists = (GetAttr(pname) And vbDirectory) = vbDirectory
    End If
End Function

Public Function folder_exists(ByVal str_folder_path As String, Optional ByVal print_error_message As Boolean) As Boolean
    Dim fso As New FileSystemObject
    
    folder_exists = True
    
    If Not fso.FolderExists(str_folder_path) Then
        If print_error_message Then MsgBox "Folder '" & str_folder_path & "' not found", vbCritical
        folder_exists = False
    End If
End Function

End Function



'------------------------------USERFOM-----------------------USERFOM-----------------------------------------------
'------------------------------------------------------------------------------------------------------------------

Sub StartProcessUserform()
    userform_loading.Show vbModeless
End Sub

Sub EndProcessUserForm()
    userform_loading.Hide
    Unload userform_loading
    Call clean_userform
    Application.StatusBar = ""
End Sub

Public Sub clean_userform()
    
    If Not userform_loading_ Is Nothing Then
        Set userform_loading_ = Nothing
    End If
    
End Sub
Property Get userform_loading() As Object
    
    If userform_loading_ Is Nothing Then
        Set userform_loading_ = UserformProgressBar
    End If
    
    Set userform_loading = userform_loading_
    
End Property
```

## userform

```
Sub prg_extraction_all()

    ocls_timer.Start
    
    Call FctOptimizeVBA(True)
    Call StartProcessUserform
    
    Call userform_loading.Update((0 / 4) * 100, 100, "Import Data ClientLive")
    Call ImportDataClientLive(True)
    Call userform_loading.Update((1 / 4) * 100, 100, "Import Data Glad")
    Call ImportDataGlad(True)
    Call userform_loading.Update((2 / 4) * 100, 100, "Import Data Palm")
    Call ImportDataPalm(True)
    Call userform_loading.Update((3 / 4) * 100, 100, "Import Data GAP3")
    Call ImportDataGap3(True)
    Call userform_loading.Update((4 / 4) * 100, 100, "Import Data GAP3")
    
    Call EndProcessUserForm
    Call FctOptimizeVBA(False)
    MsgBox "All Import Data Done, Time : " & ocls_timer.stop_timer, vbInformation, "Ventilation Optimus Prime"
End Sub
```


## modify

```
Option Explicit

Dim Label_ToModify              As String
Dim DictTemp_label_value        As Dictionary

Function fct_modify_GladInput()

    Dim ws_ParamModify              As Worksheet
    Dim ws_ToModify                 As Worksheet
    Dim str_col_label_SolutionId    As String
    
    Set ws_ParamModify = Worksheets(CStr(ws_modify_WsGlad.Name))
    Set ws_ToModify = Worksheets(CStr(ws_glad.Name))
    str_col_label_SolutionId = "solutionId"
    
    Call fct_modify(ws_ParamModify, ws_ToModify, str_col_label_SolutionId)

End Function

Function fct_modify_ClientLiveInput()

    Dim ws_ParamModify              As Worksheet
    Dim ws_ToModify                 As Worksheet
    Dim str_col_label_SolutionId    As String
    
    Set ws_ParamModify = Worksheets(CStr(ws_modify_WsClientLive.Name))
    Set ws_ToModify = Worksheets(CStr(ws_clientlive.Name))
    str_col_label_SolutionId = "GLADiD"
    
    Call fct_modify(ws_ParamModify, ws_ToModify, str_col_label_SolutionId)
    
End Function

Function fct_modify(ws_ParamModify As Worksheet, ws_ToModify As Worksheet, str_col_label_SolutionId As String)

    Dim my_tab                      As Variant
    Dim label_temp                  As Variant
    Dim dict_Modify                 As Dictionary
    Dim dict_NumRow_ToDelete        As Dictionary
    Dim label_WithoutSplitDel       As String
    Dim i                           As Integer
    Dim col_CodeId                  As Integer
    Dim col_num_temp                As Integer
    Dim bool_delete_row_validate    As Boolean
    
    my_tab = ws_ToModify.Range("A1").CurrentRegion
    col_CodeId = fct_get_NumColumn(ws_ToModify, str_col_label_SolutionId)
    Set dict_Modify = fct_dict_Modify(ws_ParamModify, str_col_label_SolutionId)
    Set dict_NumRow_ToDelete = New Dictionary
    
    For i = LBound(my_tab, 1) + 1 To UBound(my_tab, 1)
    
        bool_delete_row_validate = False
    
        If fct_dict_SplitExists(dict_Modify, my_tab(i, col_CodeId)) = True Then

            For Each label_temp In DictTemp_label_value.Keys
                If InStr(CStr(label_temp), "del") = 0 Then
                    col_num_temp = fct_get_NumColumn(ws_ToModify, CStr(label_temp))
                    ws_ToModify.Cells(i, col_num_temp) = fct_verify_TenElementsInCode(label_temp, DictTemp_label_value(label_temp))
                    ws_ToModify.Cells(i, col_num_temp).Font.Color = -16776961
                Else
                    label_WithoutSplitDel = Split(CStr(label_temp), "__")(0)
                    col_num_temp = fct_get_NumColumn(ws_ToModify, CStr(label_WithoutSplitDel))
                    If ws_ToModify.Cells(i, col_num_temp) = fct_verify_TenElementsInCode(label_WithoutSplitDel, DictTemp_label_value(label_temp)) Then
                        bool_delete_row_validate = True
                    Else
                        bool_delete_row_validate = False
                    End If
                End If
            Next label_temp
            
            If bool_delete_row_validate = True Then
                dict_NumRow_ToDelete.Add ws_ToModify.Cells(i, col_num_temp).Row, "columns to delete"
            End If

        End If
        
        Set DictTemp_label_value = Nothing
        
    Next i
    
    If bool_delete_row_validate = True Then Call fct_DeleteRows(ws_ToModify, dict_NumRow_ToDelete)

End Function

Function fct_verify_TenElementsInCode(label_temp As Variant, tab_temp As Variant) As String

    Dim i As Byte
    
    If InStr(CStr(label_temp), "Id") Then 'guarantorRicosId et counterpartyRicosId
        If Not Len(CStr(tab_temp)) = 10 Then
            For i = 1 To 10 - Len(tab_temp)
                fct_verify_TenElementsInCode = fct_verify_TenElementsInCode & "0"
            Next i
            fct_verify_TenElementsInCode = "'" & fct_verify_TenElementsInCode & tab_temp
        Else
            fct_verify_TenElementsInCode = "'" & tab_temp
        End If
    ElseIf InStr(CStr(label_temp), "bma") Then 'Exception BMA
        If Len(tab_temp) < 10 Then
            For i = 1 To 10 - Len(tab_temp)
                fct_verify_TenElementsInCode = fct_verify_TenElementsInCode & "0"
            Next i
            fct_verify_TenElementsInCode = "'" & fct_verify_TenElementsInCode & tab_temp
        Else
            fct_verify_TenElementsInCode = "'" & tab_temp
        End If
    Else
          fct_verify_TenElementsInCode = tab_temp
    End If

End Function

Function fct_dict_SplitExists(dict_temp As Dictionary, GladId As Variant) As Boolean

    Dim key_temp As Variant
    fct_dict_SplitExists = False
    Set DictTemp_label_value = New Dictionary
    
    For Each key_temp In dict_temp.Keys
    
        If InStr(CStr(key_temp), "_del") = 0 Then
            If Split(key_temp, "__")(0) = CStr(GladId) Then
                fct_dict_SplitExists = True
                Label_ToModify = Split(key_temp, "__")(1)
                
                If Not DictTemp_label_value.Exists(Label_ToModify) Then
                    DictTemp_label_value.Add Label_ToModify, dict_temp(key_temp)
                End If
            End If
        Else
            If Split(key_temp, "_del")(0) = CStr(GladId) Then
                fct_dict_SplitExists = True
                Label_ToModify = Split(Split(key_temp, "_del")(1), "__")(1)
                    If Not DictTemp_label_value.Exists(Label_ToModify) Then
                        DictTemp_label_value.Add Label_ToModify & "__" & "del", dict_temp(key_temp)
                    End If
            End If
        End If
        
    Next key_temp
    
End Function

Function fct_dict_Modify(ws_ParamModify As Worksheet, str_col_label_SolutionId As String) As Dictionary

    Dim my_tab                  As Variant
    Dim dict_temp               As New Dictionary
    Dim i                       As Integer
    Dim j                       As Integer
    Dim col_GladId              As Integer

    col_GladId = fct_get_NumColumn(ws_ParamModify, str_col_label_SolutionId)
    my_tab = ws_ParamModify.Range("A1").CurrentRegion

    For i = LBound(my_tab, 1) + 1 To UBound(my_tab, 1)
        If Not dict_temp.Exists(my_tab(i, col_GladId)) Then
            For j = LBound(my_tab, 2) To UBound(my_tab, 2)
                If Not j = col_GladId And my_tab(i, j) <> "" Then
                    dict_temp.Add my_tab(i, col_GladId) & "__" & my_tab(1, j), my_tab(i, j)
                End If
            Next j
        End If
    Next i

    Set fct_dict_Modify = dict_temp
    Set my_tab = Nothing
    Set dict_temp = Nothing

End Function

Function fct_DeleteRows(ws_ToModify As Worksheet, dict_NumRow As Dictionary)

    Dim key_NumRow  As Variant
    Dim last_row    As Integer
    Dim last_col    As Integer
    Dim rng         As Range

   With ws_ToModify
        last_row = .Range("A1").End(xlDown).Row
        last_col = .Range("A1").End(xlToRight).Column
        Set rng = .Range("A1", .Cells(last_row, last_col))
    End With
    
    For Each key_NumRow In fct_SortDict(dict_NumRow, xlDescending).Keys
        rng.Rows(key_NumRow).EntireRow.Delete
    Next key_NumRow
    
    Set rng = Nothing
    
End Function

Public Function fct_SortDict(dict_input As Dictionary, Optional sortorder As XlSortOrder = xlAscending) As Dictionary
    
    Dim arr_list    As Object
    Dim Key         As Variant
    Dim dict_temp   As Dictionary
    
    Set arr_list = CreateObject("System.Collections.ArrayList")
    
    For Each Key In dict_input
        arr_list.Add Key
    Next Key
    
    arr_list.Sort

    If sortorder = xlDescending Then
        arr_list.Reverse
    End If
    
    Set dict_temp = New Dictionary
    
    For Each Key In arr_list
        dict_temp.Add Key, dict_input(Key)
    Next Key
    
    Set arr_list = Nothing
    Set fct_SortDict = dict_temp
    Set dict_temp = Nothing
        
End Function
```

## export

```
Option Explicit

Function Create_file_output(output_type_str As String)
       
    Dim bool_file_over_write    As Boolean
    Dim my_path                 As String
    Dim my_file_name            As String
    Dim nom_ws                  As String
    
    Call FctOptimizeVBA(True)
    
    'ICI CHEMIN OUTPUT ENTITE
    Select Case output_type_str
        Case "FTP"
            my_path = ws_main.[rng_output_cream]
            nom_ws = ws_ftp.Name
            my_file_name = "FTP"
        Case "ESSBASE"
            my_path = ws_main.[rng_output_essbase]
            nom_ws = ws_essbase.Name
            my_file_name = "ESSBASE"
        Case "NeoClip"
            my_path = ws_main.[rng_output_neoclip]
            nom_ws = ws_neoclip.Name
            my_file_name = "NeoClip"
    End Select
           
    'On vérifie l'existence du chemin OUTPUT ENTITE
    Call path_exists(CStr(my_path))
    If path_exists(CStr(my_path)) = False Then
        MsgBox "Error on output path, please see Path validity, check that it ends with \"
        Exit Function
    End If
    
    If Not Right(CStr(my_path), 1) = "\" Then
        my_path = my_path & "\"
    End If
    
    
    'On vérifie qu'il y a pas de problèmes au niveau des ranges nommées
    If fct_file_over_write(CStr(my_path), CStr(my_file_name)) = True Then
        bool_file_over_write = True
    Else
        bool_file_over_write = False
    End If
                    
    Call sheet_exists(CStr(nom_ws))
    If sheet_exists(nom_ws) = False Then
        MsgBox "La feuille " & nom_ws & " existe plus"
    End If
    Worksheets(CStr(nom_ws)).Visible = xlSheetVisible
    
    Select Case output_type_str
        Case "FTP"
            ws_ftp.Copy
        Case "ESSBASE"
            ws_essbase.Copy
        Case "NeoClip"
            ws_neoclip.Copy
    End Select
    
    Call fct_create_file(my_path, my_file_name, bool_file_over_write)
    
    Call FctOptimizeVBA(False)
    
End Function

 'Géneration de fichier et Gestionaire de version
 Public Function fct_create_file(ByVal my_path As String, my_file_name, bool_file_over_write As Boolean) As String
 
    Dim save_name   As String
    Dim save_ext    As String
    Dim version_ext As String
    Dim temp_save   As Boolean
    Dim my_array    As Range
    Dim x           As Long
    
    save_ext = ".xlsx"
    x = 1
    version_ext = "_v"

    'Determine le nom du fichier si plusieurs versions
    If InStr(1, my_file_name, version_ext) > 1 Then
        my_array = Split(my_file_name, version_ext)
        save_name = my_array(0)
    Else
        save_name = my_file_name
    End If

    'Si le fichier jamais été crée, on le génère
    If file_exist(my_path & save_name & save_ext) = False Then
        ActiveWorkbook.SaveAs my_path & my_file_name & save_ext
        
        If my_file_name = "FTP" Then
            Workbooks(my_file_name & save_ext).Worksheets(1).Name = "Module_Ajustement"
        End If
        
        Workbooks(my_file_name & save_ext).Close True
        fct_create_file = my_file_name & save_ext
        Exit Function
    End If
  
    temp_save = False

    'Si le fichier existe deja, soit on le remplace, soit on crée une nouvelle version
    'If file_exist(my_path & save_name & save_ext) = True Then
    
    If bool_file_over_write = True Then
    
        Application.DisplayAlerts = False
        ActiveWorkbook.SaveAs my_path & my_file_name & save_ext
        Worksheets(ws_essbase.Name).Name = "merde"
        
        If my_file_name = "FTP" Then
            Workbooks(my_file_name & save_ext).Worksheets(1).Name = "Module_Ajustement"
        End If
        
        Workbooks(my_file_name & save_ext).Close True
        fct_create_file = my_file_name & save_ext
        Application.DisplayAlerts = True
    Else
        'On boucle jusqu'a trouvé une version qui n'existe pas encore
        Do While temp_save = False
            If file_exist(my_path & save_name & version_ext & x & save_ext) = False Then
    
                ActiveWorkbook.SaveAs my_path & save_name & version_ext & x & save_ext
                
                temp_save = True
                If my_file_name = "FTP" Then
                    Workbooks(my_file_name & save_ext).Worksheets(1).Name = "Module_Ajustement"
                End If
                
                Workbooks(save_name & version_ext & x & save_ext).Close True
                fct_create_file = save_name & version_ext & x & save_ext
                'exit do
            Else
                x = x + 1
               End If
        Loop
    End If

End Function
Function fct_file_over_write(path_output As String, my_file_name As String) As Boolean

    Dim save_ext              As String
    Dim ret                   As String

    save_ext = ".xlsx"
    
    If file_exist(path_output & my_file_name & save_ext) = True Then
        ret = MsgBox("Some files in the list have already been produced and are already present in the output file" & vbNewLine & vbNewLine _
        & "Click on YES to overwrite them for all" & vbNewLine _
        & "Click on NO a Vx version will be created, but cannot be used by the mailing", vbQuestion + vbYesNo)
        If ret = vbYes Then
        
            fct_file_over_write = True
            Exit Function
        Else
            fct_file_over_write = False
            Exit Function
        End If
    End If
                 
End Function
```

## cst input

```
Option Explicit
Option Base 1

'constants initialized
Private ci                           As Boolean
Private col_pl_clientlive_           As Integer
Private col_glad_id_clientlive_      As Integer
Private col_rwa_clientlive_          As Integer
Private col_nbi_clientlive_          As Integer
Private col_couverture_clientlive_   As Integer
Private col_clientname_clientlive_   As Integer

'ClientLive Type Couverture_______________________________________________________________
Public Const CstClientLive_TypeCouvertureCds                As String = "CDS"
Public Const CstClientLive_TypeCouvertureCri                As String = "CRI"
Public Const CstClientLive_TypeCouvertureSecuritization     As String = "Securitization"
Public Const CstClientLive_TypeCouverturePicr               As String = "CRCA"

Private Sub init()
    '___________________________________________________________Modification ici___________________________________
    Dim col_glad_id_clientlive_str          As String:          col_glad_id_clientlive_str = "GLADiD"
    Dim col_pl_clientlive_str               As String:          col_pl_clientlive_str = "PLCode"
    Dim col_rwa_clientlive_str              As String:          col_rwa_clientlive_str = "RWAkey"
    Dim col_nbi_clientlive_str              As String:          col_nbi_clientlive_str = "NBIkey"
    Dim col_couverture_clientlive_str       As String:          col_couverture_clientlive_str = "Couverture"
    Dim col_clientname_clientlive_str       As String:          col_clientname_clientlive_str = "ClientName"
    '______________________________________________________________________________________________________________

    On Error GoTo error_handler:
    
    col_glad_id_clientlive_ = fct_get_NumColumn(ws_clientlive, col_glad_id_clientlive_str)
    col_pl_clientlive_ = fct_get_NumColumn(ws_clientlive, col_pl_clientlive_str)
    col_rwa_clientlive_ = fct_get_NumColumn(ws_clientlive, col_rwa_clientlive_str)
    col_nbi_clientlive_ = fct_get_NumColumn(ws_clientlive, col_nbi_clientlive_str)
    col_couverture_clientlive_ = fct_get_NumColumn(ws_clientlive, col_couverture_clientlive_str)
    col_clientname_clientlive_ = fct_get_NumColumn(ws_clientlive, col_clientname_clientlive_str)
    
ErrorExit:
    ci = True
    Exit Sub
    
error_handler:
    Resume ErrorExit
     
End Sub

Public Function fct_get_NumColumn(ws_temp As Worksheet, ColumnName As String) As Integer

    On Error GoTo ErrorHandler_1:
    
    fct_get_NumColumn = Application.WorksheetFunction.Match(ColumnName, ws_temp.Rows("1:1"), 0)

    Exit Function

ErrorHandler_1:
        MsgBox LogErrors("Champ : " & ColumnName & " introuvable dans " & ws_temp.Name, Err), _
    vbOKOnly + vbExclamation, "Error in Module " & Application.VBE.ActiveCodePane.CodeModule.Name
    
    Call init_col_input

End Function

Static Property Get col_pl_clientlive() As Integer
    If Not ci Then init
    col_pl_clientlive = col_pl_clientlive_
End Property

Static Property Get col_glad_id_clientlive() As Integer
    If Not ci Then init
    col_glad_id_clientlive = col_glad_id_clientlive_
End Property

Static Property Get col_rwa_clientlive() As Integer
    If Not ci Then init
    col_rwa_clientlive = col_rwa_clientlive_
End Property

Static Property Get col_nbi_clientlive() As Integer
    If Not ci Then init
    col_nbi_clientlive = col_nbi_clientlive_
End Property

Static Property Get col_couverture_clientlive() As Integer
    If Not ci Then init
    col_couverture_clientlive = col_couverture_clientlive_
End Property

Static Property Get col_clientname_clientlive() As Integer
    If Not ci Then init
    col_clientname_clientlive = col_clientname_clientlive_
End Property


```

## cst cls

```
Option Explicit
Option Base 1

Private tab_result_title_ftp_   As Variant
Public CstFtp_                  As ConstantFtp

Public Type ConstantFtp
    Action              As String
    RicosTrancheId      As String
    BookingEntityCode   As String
    BookingEntityName   As String
    ClcDevise           As String
    SlaSubCategoryCode  As String
    CacibCasaIndicateur As String
    FtpInternalEad      As String
    BoolCreate          As Boolean
End Type

Property Get CstFtp() As ConstantFtp
    If CstFtp_.BoolCreate = False Then
        CstFtp_ = LoadCstFtp
    End If
   CstFtp = CstFtp_
    
End Property

Public Function LoadCstFtp() As ConstantFtp
    Dim LoadCstFtp_ As ConstantFtp
    With LoadCstFtp_
        .BoolCreate = True
        .Action = "C"
        .RicosTrancheId = "1"
        .BookingEntityCode = "'0010"
        .BookingEntityName = "CA-CIB FRANCE"
        .ClcDevise = "EUR"
        .SlaSubCategoryCode = "01A"
        .CacibCasaIndicateur = "0"
        .FtpInternalEad = "0"
    End With
    
    LoadCstFtp = LoadCstFtp_
End Function



Function load_title_ftp() As Variant()

    Dim tab_result_title_ftp_ As Variant
    ReDim tab_result_title_ftp_(1, 1 To 27)
    
    tab_result_title_ftp_(1, 1) = "Action"
    tab_result_title_ftp_(1, 2) = "Period"
    tab_result_title_ftp_(1, 3) = "Computation Method"

    load_title_ftp = tab_result_title_ftp_

End Function

Public Property Get tab_result_title_ftp() As Variant()
    tab_result_title_ftp = load_title_ftp
End Property

```


## load dict

```
Dim dict_temp                                       As Dictionary
Dim code_orchestrade                                As Variant
Dim GladId                                          As Variant
Dim my_tab                                          As Variant
Dim i                                               As Integer

Private temp_dict_gap_CodeOrchestrade_rwa           As Dictionary
Private temp_dict_gap_CodeOrchestrade_el            As Dictionary
Private temp_dict_gap_CodeOrchestrade_CpyName       As Dictionary
Private temp_dict_gap_CodeOrchestrade_notation      As Dictionary
Private temp_dict_gap_CodeOrchestrade_EadAffecte    As Dictionary

Function clear_dict_gap3()
    Set temp_dict_gap_CodeOrchestrade_rwa = Nothing
    Set temp_dict_gap_CodeOrchestrade_el = Nothing
    Set temp_dict_gap_CodeOrchestrade_CpyName = Nothing
    Set temp_dict_gap_CodeOrchestrade_notation = Nothing
    Set temp_dict_gap_CodeOrchestrade_EadAffecte = Nothing
End Function

Function dict_gap_CodeOrchestrade_rwa_() As Dictionary
    
    Dim GladId As Variant
    Set dict_temp = New Dictionary
    my_tab = ws_gap3.Range("A1").CurrentRegion


    For Each GladId In dict_Glad_GladId_CodeOrchestrade.Keys
        code_orchestrade = dict_Glad_GladId_CodeOrchestrade(GladId)
        For i = LBound(my_tab, 1) + 1 To UBound(my_tab, 1)
            If my_tab(i, col_code_orchestrade) = code_orchestrade Then
                If Not dict_temp.Exists(my_tab(i, col_code_orchestrade)) Then
                    dict_temp.Add my_tab(i, col_code_orchestrade), my_tab(i, col_rwa_affecte)
                ElseIf dict_temp.Exists(my_tab(i, col_code_orchestrade)) Then
                    dict_temp.Item(my_tab(i, col_code_orchestrade)) = dict_temp.Item(my_tab(i, col_code_orchestrade)) + my_tab(i, col_rwa_affecte)
                End If
            End If
        Next i
    Next GladId
    
    Set dict_gap_CodeOrchestrade_rwa_ = dict_temp
    Set dict_temp = Nothing
    
End Function
Public Property Get dict_gap_CodeOrchestrade_rwa() As Dictionary

    If temp_dict_gap_CodeOrchestrade_rwa Is Nothing Then
       Set temp_dict_gap_CodeOrchestrade_rwa = dict_gap_CodeOrchestrade_rwa_
    End If
    Set dict_gap_CodeOrchestrade_rwa = temp_dict_gap_CodeOrchestrade_rwa
    
End Property


```

## main

```
Sub prg_cds_ftp(Optional bool_all As Boolean, Optional bool_all_ventilation As Boolean)

    Dim OArrResult As New cls_ArrResult
    
    Call init_col_input
    
    On Error GoTo ErrorHandler

    If bool_all = False Or bool_all_ventilation = False Then
        Call FctOptimizeVBA(True)
        Call FctCheckDataInput
    End If
    TypeCouverture = "CDS"
    TypeOutput = "FTP"
    msg_titre = "Ventilation" & Space(1) & TypeCouverture & Space(1) & TypeOutput

    Call fct_display_title(bool_all_ventilation, TypeOutput)
    Set dict_ClientLive_PrimaryKey_GladId = load_dict_ClientLive_PrimaryKey_GladId(CstClientLive_TypeCouvertureCds)
    Call fct_verify_GladID(TypeCouverture, dict_ClientLive_PrimaryKey_GladId, dict_Glad_GladId_CodeOrchestrade, CstClientLive_TypeCouvertureCds)
    
    For Each GladId In dict_Glad_GladId_CodeOrchestrade.Keys
        
        CodeOrchestrade = dict_Glad_GladId_CodeOrchestrade(GladId)
        
        For Each item_PrimaryKey_ClientLive In dict_ClientLive_PrimaryKey_GladId.Keys

            If CStr(dict_ClientLive_PrimaryKey_GladId.Item(item_PrimaryKey_ClientLive)) = CStr(GladId) Then
            
                Set dico_CalculVentilation_CDS = fct_CalculVentilation_CDS(CodeOrchestrade, item_PrimaryKey_ClientLive, dict_ClientLive_PrimaryKey_GladId.Item(item_PrimaryKey_ClientLive))
                i = 1
                OArrResult.i = i
                OArrResult.TypeCouverture = TypeCouverture
                OArrResult.GladId = GladId
                OArrResult.NegociationStartDate = DateProd
                OArrResult.ComputationMethod = dict_uda_name_ComputationMethod(TypeCouverture)
                OArrResult.CpyCode = dict_Glad_gladId_CodeRicos(GladId)
                OArrResult.CpyName = CStr(dict_gap_CodeOrchestrade_CpyName(CodeOrchestrade))
                OArrResult.ProfitCenter = dict_uda_ProductLine_ProfitCenter(Left(item_PrimaryKey_ClientLive, 5))
                OArrResult.ProductLine = Left(item_PrimaryKey_ClientLive, 5)
                OArrResult.GladDate = FctValidGladDate(dict_Glad_GladId_date(GladId))
                OArrResult.Rating = dict_gap_CodeOrchestrade_notation(CodeOrchestrade)
                OArrResult.RwaAmount = dico_CalculVentilation_CDS("Gain RWA")
                OArrResult.ElAmount = dico_CalculVentilation_CDS("Gain EL")
                OArrResult.Comment = TypeCouverture & Space(1) & GladId

                Call fct_display_result(TypeOutput, OArrResult.ArrResultFtp)
            End If
        Next
    Next

    If bool_all = False Then
        Call FctBuildErrMsg
        Call FctErrMsgDisplay
        MsgBox "Output" & Space(1) & TypeOutput & Space(1) & "Done !", vbInformation, "Ventilation" & Space(1) & TypeCouverture
        ws_ftp.Activate
    Else
        Call FctBuildErrMsg
    End If
    
ErrorExit:
    Call FctOptimizeVBA(False)
    Exit Sub
    
ErrorHandler:
    MsgError_NoCatch = "Error No Catch, please contact : FIN-" & chr(13) & Err.Number & chr(13) & Err.Description
    Call LogErrors(Replace$(MsgError_NoCatch, vbCrLf & vbCrLf, vbCrLf))
    MsgBox "Error No Catch,may be critical, please contact : ", vbCritical, msg_titre
    Resume ErrorExit

End Sub
```

## userform

```


Option Explicit
Public my_width As Double




'
'    Call modProgress.ShowProgress( _
'                lngCounter, _
'                lngNumberOfTasks, _
'                "Excel is working on Task Number " & lngCounter + 1, _
'                False)

'Call ufProgress.UpdateForm(ActionNumber, TotalActions, StatusMessage)

Private Sub cmdAbort_Click()
    Unload Me
    End
End Sub


Public Sub UpdateProgressBar(ByVal pourcentage As Double)
    With Me
        .frm_progress.Caption = Format(pourcentage, "0%")
        .lbl_progress.Width = pourcentage * Me.my_width
        .Repaint
    End With
End Sub


Public Sub SetDescription(ByVal StrStatus As String, Step As Long, TotalStep As Long, Optional DescriptionEvolution As Boolean = False)
    
    Dim StatusCustom As String
    
    'Debug.Print "step:" & Step & " Total:" & TotalStep
    If DescriptionEvolution = True Then
        'StatusCustom = Format(Step, String(Len(CStr(TotalStep)), "0")) & " of " & TotalStep
        'StatusCustom = Left(StatusCustom & " | " & StrStatus, 80) & "..."
        StatusCustom = "Run Optimus Prime" & " | " & StrStatus
    Else
        StatusCustom = StrStatus
    End If
    
    Me.lbl_description.Caption = StatusCustom
    DoEvents
    
    If DescriptionEvolution = True And Step = TotalStep Then
        Me.MousePointer = fmMousePointerDefault
        Me.cmdAbort.Caption = "Close"
        Me.lbl_description.Caption = "Complete. Press Close to exit."
        Me.LabelEnd.Caption = "Breakdown's Optimus Prime done, Time: " & ocls_timer.stop_timer
    End If
End Sub
Private Sub UserForm_Initialize()

    Call HideTitleBar(Me)
    
    'Fait ralentir
    'Call CenterUserForm(Me)

    With Me
        .lbl_progress.Width = 0
        .my_width = 399.7
    End With
    
End Sub

Public Function Update(ByVal Step As Long, ByVal TotalStep As Long, ByVal StrStatus As String, _
                            Optional ByVal Title As String = vbNullString, Optional DescriptionEvolution As Boolean = False) As Long
    
    If Not Title = vbNullString Then
        'Ne marche pas si appel HideTitleBar(Me)
        Me.Caption = Title
    End If
    
    DoEvents
    Me.frm_progress.SetFocus
    Call Me.SetDescription(StrStatus, Step, TotalStep, DescriptionEvolution)
    Call Me.UpdateProgressBar(Step / TotalStep)
    
    If DescriptionEvolution = False And Step = TotalStep Then
        Call EndProcessUserForm
    End If
    
    Update = Step + 1
    
End Function


Sub CenterUserForm(ByRef WhichForm As Object)
    WhichForm.StartUpPosition = 0
    WhichForm.Left = Application.Left + (Application.Width / 2) - (WhichForm.Width / 2)
    WhichForm.Top = Application.Top + (Application.Height / 2) - (WhichForm.Height / 2)
End Sub

Function isFormOpen(ByVal FormName As String) As Boolean
    Dim ufForm As Object
    isFormOpen = False
    For Each ufForm In VBA.UserForms
        If ufForm.Name = FormName Then
            isFormOpen = True
            Exit For
        End If
    Next ufForm
End Function
```


# var B

mat combinaison de 4 trimestre
[1; 2;3;4]
mat 2 somme pr chaque scénario
[]
ma tri croissant des scénarios

longueur de l'échantillon :=NBVAL(B9:B1000000)
niveau de risque :=(100-99,9)/100
Le numéro de la ième perte (quantile de la distribution) est  :longueur de l'échantillon*niveau de risque
Value at Risk  Bootstrap Historical ::= (sur mat tri croissant)
1);(INDEX(I9:I1000000;ENT(L11)+1))+((INDEX(I9:I1000000;ENT(L11)+2))-(INDEX(I9:I1000000;ENT(L11)+1)))*(L11-TRONQUE(L11)))

méthode centile
Value at Risk  Bootstrap Historical :=CENTILE(I9:I1000000;L10)
```
Sub Main_VaR_Bootstrap_Historical()

    Dim my_tab              As Variant
    Dim nb_combinaisons     As Variant
    Dim somme               As Variant
    Dim VaR                 As Variant
    Dim niveau_confiance    As Double
    Dim samples()           As Double
    Dim last_row_used       As Long
    Dim i                   As Long
    Dim j                   As Long
  
    niveau_confiance = 99.9
    
    Call Optimize_VBA(True)
    
    Call fct_clear_audit
    'Call fct_clc_rbevar
    my_tab = fct_GetTab_DateRbevar
    
    last_row_used = UBound(my_tab, 1)
    
    my_tab = fct_combinaisons_4trimestres(my_tab)
    ws_audit.Range("rng_audit_matrice_4trimestres").Resize(UBound(my_tab, 1), UBound(my_tab, 2)).Value = my_tab
     
    nb_combinaisons = Application.WorksheetFunction.Combin(last_row_used, 4)
    
    ReDim samples(1 To nb_combinaisons, 1 To 4)
    ReDim tbl(1 To nb_combinaisons, 1) As Variant
    ReDim samples(1 To nb_combinaisons, 1 To 4)
    
    For i = 1 To nb_combinaisons
        somme = 0
        For j = 1 To 4
            somme = somme + my_tab(i, j)
        Next j
        tbl(i, 1) = somme
    Next i
    
    ws_audit.Range("rng_audit_sum_year").Resize(UBound(tbl, 1), 1).Value = tbl
    quick_sort tbl, LBound(tbl), UBound(tbl)
    ws_audit.Range("rng_audit_sum_year_order").Resize(UBound(tbl, 1), 1).Value = tbl
    
    VaR = fct_clc_quantile_var(2, niveau_confiance, nb_combinaisons, tbl)
    MsgBox "Done , VaR Bootstrap Historical is :" & VaR, vbOKOnly + vbInformation, "CACIB PIL VaR Business"
    
    Call Optimize_VBA(False)

End Sub

Function fct_clc_quantile_var(type_method As Byte, niveau_confiance As Double, nb_combinaisons As Variant, tbl As Variant) As Variant

    Dim num_loss    As Variant
    Dim result_VaR  As Variant
    Dim part_decimal As Double

    Select Case type_method
        Case 1
            num_loss = Int(nb_combinaisons * (100 - niveau_confiance) / 100) + 1
            If nb_combinaisons * (100 - niveau_confiance) / 100 = Int(nb_combinaisons * (100 - niveau_confiance) / 100) Then
                result_VaR = tbl(num_loss, 1)
                ws_inteface.[rng_result] = result_VaR
            Else
                'si p-ieme centile pas un nombre entier, on utilise une interpolation pour calculer le rang fractionnaire
                part_decimal = CDbl(nb_combinaisons * (100 - niveau_confiance / 100) + 1 - Split(Str(nb_combinaisons * (100 - niveau_confiance / 100) + 1), ".")(0))
                result_VaR = (tbl(num_loss + 1, 1) - tbl(num_loss, 1)) * part_decimal + tbl(num_loss, 1)
                ws_inteface.[rng_result] = result_VaR
            End If
    
        Case 2
            result_VaR = WorksheetFunction.Percentile(tbl, ((100 - niveau_confiance) / 100))
            ws_inteface.[rng_result] = result_VaR
    End Select

    fct_clc_quantile_var = result_VaR

End Function


Function fct_combinaisons_4trimestres(arr As Variant) As Variant

    Dim temp()  As Variant
    Dim m       As Variant
    Dim n       As Variant
    Dim i       As Variant
    Dim i1      As Variant
    Dim i2      As Variant
    Dim i3      As Variant
    Dim i4      As Variant
    
    m = UBound(arr, 1)
    ReDim temp(1 To (m * (m - 1) * (m - 2) * (m - 3)) / 24, 1 To 4)
    i = 0
    
    For i1 = 1 To m
    
        For i2 = i1 + 1 To m
        
            For i3 = i2 + 1 To m
            
                For i4 = i3 + 1 To m
                    i = i + 1
                    temp(i, 1) = arr(i1, 2)
                    temp(i, 2) = arr(i2, 2)
                    temp(i, 3) = arr(i3, 2)
                    temp(i, 4) = arr(i4, 2)
                Next i4
                
            Next i3
            
        Next i2
        
    Next i1
    fct_combinaisons_4trimestres = temp
    
End Function

Sub quick_sort(arr() As Variant, low As Variant, high As Variant)

    Dim pivot   As Variant
    Dim i       As Variant
    Dim j       As Variant
    
    If low < high Then
    
        pivot = arr((low + high) \ 2, 1)
        i = low
        j = high
        
        Do
            Do While arr(i, 1) < pivot
                i = i + 1
            Loop
            
            Do While arr(j, 1) > pivot
                j = j - 1
            Loop
            
            If i <= j Then
                Call transfert_quick_sort(arr, i, j)
                i = i + 1
                j = j - 1
            End If
            
        Loop While i <= j
        
    If low < j Then Call quick_sort(arr, low, j)
    If i < high Then Call quick_sort(arr, i, high)
    
    End If
    
End Sub

Sub transfert_quick_sort(arr() As Variant, i As Variant, j As Variant)

    Dim temp    As Variant
    
    temp = arr(i, 1)
    arr(i, 1) = arr(j, 1)
    arr(j, 1) = temp
    
End Sub

Function fct_GetTab_DateRbevar() As Variant

    Dim my_tab()    As Variant
    Dim last_row    As Long
    Dim i           As Long
    Dim j           As Long
    
    last_row = ws_input.Range("A1").End(xlDown).Row
    ReDim my_tab(1 To last_row, 1 To 2)
    my_tab = ws_input.Range("A2").Resize(last_row).Value
    ReDim arr_temp(1 To UBound(my_tab, 1) - 5, 1 To 2)
    
    
    If ws_input.Cells(5, 3) = "" Then
        j = 1
        For i = 2 To UBound(my_tab, 1) - 4
            arr_temp(j, 1) = ws_input.Cells(i + 4, 1)
            arr_temp(j, 2) = ws_input.Cells(i + 4, 3)
            j = j + 1
        Next i
    Else
        j = 1
        For i = 2 To UBound(my_tab, 1) - 4
            arr_temp(j, 1) = ws_input.Cells(i, 1)
            arr_temp(j, 2) = ws_input.Cells(i, 3)
            j = j + 1
        Next i
    
    End If
    
    fct_GetTab_DateRbevar = arr_temp

End Function

Function fct_clc_rbevar()

    Dim last_row    As Long
    Dim i           As Long

   last_row = ws_input.Range("A1").End(xlDown).Row
    
    For i = 2 To last_row
        If i - 4 >= 2 Then
            ws_input.Cells(i, 3) = ws_input.Cells(i, 2).Value - ws_input.Cells(i - 4, 2).Value
        End If
    Next i

End Function

Function fct_clear_audit()

    ws_inteface.Range("rng_result") = ""
    ws_audit.Range("rng_audit_matrice_4trimestres").CurrentRegion.ClearContents
    ws_audit.Range("rng_audit_sum_year").CurrentRegion.ClearContents
    ws_audit.Range("rng_audit_sum_year_order").CurrentRegion.ClearContents
    
End Function

Sub Optimize_VBA(isOn As Boolean)
    Application.EnableEvents = Not (isOn)
    Application.ScreenUpdating = Not (isOn)
    Application.DisplayAlerts = Not (isOn)
End Sub


```

```
import pandas as pd
import numpy as np
from openpyxl import Workbook,load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from itertools import combinations
from datetime import datetime
import os
from tkinter import messagebox
from datetime import datetime
import tkinter

class cls_bootstrap_historical_VaR:
    
    def __init__(self):
        '''
        Configuration ici
        '''
        #Input/output same file
        self.file_path_import=r'C:\.xlsx'
        self.sheet_name_input='(A2) Input Var'
        self.sheet_name_output='Result VaR'
        self.col_name_rbe='RBE var'
        self.col_name_year = "year"
        self.col_name_date = 'date'
        
        #Export result new file
        head, file_name_import = os.path.split(self.file_path_import)
        self.file_name_import =file_name_import 
        now=datetime.now()
        date_time=now.strftime('%d.%m.%Y')
        self.new_file_output="CACIB Business Risk VaR "+date_time +".xlsx"
        self.new_sheet_name_output='Result VaR'
        
    def  import_mapping_file(self):
        data_input=pd.read_excel(self.file_path_import,self.sheet_name_input)
        data_temp=data_input[[self.col_name_year,self.col_name_rbe]]
        return data_input

    def  export_result(self,res):
        file = self.file_name_import 
        file_sheet_name="Result VaR"

        # si ficher existe deja on rajoute
        if os.path.isfile(self.file_name_import):  
            workbook = load_workbook(self.file_name_import)  
            sheet = workbook[self.sheet_name_output] 
            # on supprime le dataframe précédent
            sheet.delete_rows(1,sheet.max_row+1)
            # on rajoute les données dans le fichier en cours
            for row in dataframe_to_rows(res, header =True, index = False):
                sheet.append(row)
            now = datetime.now()
            sheet['G1'] =  now.strftime("%d/%m/%Y %H:%M:%S")
            workbook.save(self.file_name_import)
            workbook.close()
        #else:  # Si fichier existe pas on le crée
        with pd.ExcelWriter(path = self.new_file_output, engine = 'openpyxl') as writer:
            res.to_excel(writer, index = False, sheet_name =self.new_sheet_name_output)

    def export_csv(self,res):
        full_path=r""
        res.to_csv(full_path,sep=',', header=True, index=True)           

    def list_annees(self,df_budget):
        '''
        Liste les années pour lesquelles on a des variations de RBE anticipées/budgettées
        :param df_budget: DataFrame des variations budgettées
        :return: la liste des années auxquelles s'applique le DataFrame
        '''
        return list(df_budget[self.col_name_year].unique())

    def build_artificial_years(self,df_input, col_name_rbe, bootstrap='S'):
        '''
        Crée des années artificielles à partir de l'historique disponible
        :param histo: Historique des deltas trimestriels disponibles
        :param entite: entité traitée
        :param bootstrap: méthode de bootstrap
            'U' (usuelle) : chaque année artificielle est construite en utilisant 4 trimestres, indépendemment de leur position dans les données historiques
        :return: une liste d'années construites artificiellement, permettant d'utiliser plusieurs milliers d'années d'historique
        '''
        if bootstrap == 'U':
            dal = df_input[[self.col_name_date,self.col_name_rbe]]

            val=list(zip((dal[self.col_name_date].to_numpy()).tolist(),(dal[self.col_name_rbe].to_numpy()).tolist()))
            comb = combinations(val, 4)
            out = []
            for elem in comb:
                out.append(elem)
            return out

    def select_crisis_quantile(self,data, scarsity=0.001):
        '''
        Retourne le quantile du pire, qui doit correspondre à la crise millénaire
        :param data: données historiques reconstruites
        :param scarsity: rareté de l'évènement, par défaut 0,1 % pour une crise millénaire
        :return: le quantile correspondant à la crise
        '''
        variations = {}
        dates = {}
        cpt_id = 0        # identifiant qui permettra de garder le lien entre les variations et les trimestres associés
        #print(len(data))
        for y in data:
            somme = 0
            quat = []
            for z in y:
                somme += z[1]
                quat.append(z[0])
            variations[cpt_id] = somme
            dates[cpt_id] = quat
            cpt_id += 1
        var_list = list(variations.values())
        var_list.sort()
        qlim = int(scarsity*len(var_list)) 
        quantile = var_list[qlim]
        rev_var = {v: k for k, v in variations.items()}
        key = rev_var[quantile]          # identifiants du quantile
        quantile_dates = dates[key]      # récupération des trimestres grâce à l'identifiant
        
        # Récuperation de la VaR  (plus précis car méthode interpolation)
        quantile =pd.DataFrame(var_list).quantile(0.001,0).to_string(index=False)
        return quantile, quantile_dates

    def trimestres_to_txt(self,trim):
        '''
        Converti la colonne Date de YYYYMM à format YYYY-MM
        :param trim: les trimestres de crise décrits sous forme de timestamps
        :return: les trimestres de crise décrits au format YYYY-MM
        '''
        txt = "["
        for t in trim:
            s = datetime.strptime(str(int(t)), '%Y%m').strftime('%Y-%m')
            txt += s
            txt += ','
        txt = txt[:-1] + ']'
        return txt
    
    def calcul_BS_VaR(self):
        
        df_data=self.import_mapping_file()
        df_data = df_data.loc[df_data[self.col_name_rbe].notnull(),[self.col_name_date,self.col_name_rbe,self.col_name_year]]
        meth='U'
        res_list = []
        res = pd.DataFrame()
        list_year=self.list_annees(df_data)

        for i,annee in enumerate(list_year):
            
            df_used = df_data[df_data[self.col_name_year] <= annee]

            if not df_used .empty:
                
                    artificial_years = self.build_artificial_years(df_used,self.col_name_rbe, meth)
                    var_crise, dates_crise = self.select_crisis_quantile(artificial_years)
                    
                    tmp = {
                        'Année': annee,
                        'VaR Bootstrap HS': var_crise,
                        'Trimestres de crise': self.trimestres_to_txt(dates_crise),
                        }
                    
                    res_list.append(tmp)           
        return  res.append(res_list)
        

obj_bootstrap_historical_VaR=cls_bootstrap_historical_VaR()
df3=obj_bootstrap_historical_VaR.calcul_BS_VaR()
obj_bootstrap_historical_VaR.export_result(df3)
root=tkinter.Tk()
root.withdraw()
messagebox.showinfo("information","Done !")

```

# gt

## tools


```
Option Explicit

'mode debug class control+G
Sub cc()
    Dim o_test          As New cls_mapping
    Dim ws_data_input   As String
    Dim ws_data_display As String
    Dim type_CTF        As Boolean
    Dim prod
    
    type_CTF = True
    
    If type_CTF = True Then
        ws_data_input = ws_input_CTF.name
    Else
        ws_data_input = ws_input_CTF.name
    End If
    
    prod = o_test.fct_display_MainMapping(display_NumDem_CTF:=type_CTF, ws_data_input:=ws_data_input)

End Sub

Sub bb()
    Dim o_test As New cls_mapping
    o_test.fct_dict_main_mapping (ws_input_CTF.name)

End Sub

Function FctOptimzeVBA(isOn As Boolean)
    Application.EnableEvents = Not (isOn)
    Application.ScreenUpdating = Not (isOn)
    Application.DisplayAlerts = Not (isOn)
    Application.DisplayStatusBar = Not (isOn)
    Application.AskToUpdateLinks = Not (isOn)
End Function

Function FctFillIfEmpty(Field As Variant) As String
    Select Case CStr(Field)
        Case "O", "o", "Oui", "Y", "y", "yes", "YES"
            FctFillIfEmpty = "oui"
        Case "N", "n", "Non", "N", "n", "no", "NO"
            FctFillIfEmpty = "non"
        Case ""
            FctFillIfEmpty = "NA"
        Case Else
            FctFillIfEmpty = Field
    End Select
End Function


Public Function IsString(ByVal v As Variant) As Boolean

    Dim s As String
    On Error Resume Next
    s = v
    If Err.Number = 0 Then
        If Not IsNumeric(v) Then IsString = True
    End If
    
End Function

Function FctColLetter(ColumnNumber As Long) As String
    Dim n As Long
    Dim C As Byte
    Dim s As String

    n = ColumnNumber
    Do
        C = ((n - 1) Mod 26)
        s = Chr(C + 65) & s
        n = (n - C) \ 26
    Loop While n > 0
    FctColLetter = s
End Function

Function FctDebugDict(var_dictionary As Dictionary)

    Dim key As Variant
    For Each key In var_dictionary.Keys
        Debug.Print key, var_dictionary(key)
    Next key

End Function


Function FctGetKeyFromItem(DictTemp As Dictionary, str_item As String) As String

    Dim key As Variant
    For Each key In DictTemp.Keys
        If DictTemp.item(key) = str_item Then
            FctGetKeyFromItem = CStr(key)
            Exit Function
        End If
    Next
    
End Function


Public Function FctSortDictByValues(dict As Object _
                    , Optional sortorder As XlSortOrder = xlAscending) As Object
    
    Dim item        As Variant
    Dim key         As Variant
    Dim value       As Variant
    Dim arrayList   As Object
    Dim DictTemp    As Object
    Dim coll        As Collection

    On Error GoTo ErrorHandler
    
    Set arrayList = CreateObject("System.Collections.ArrayList")
    Set DictTemp = CreateObject("Scripting.Dictionary")
   
    For Each key In dict
        value = dict(key)
        
        If Not DictTemp.Exists(value) Then
            Set coll = New Collection
            DictTemp.Add value, coll
            arrayList.Add value
        End If
        
        DictTemp(value).Add key
    Next key
    
    arrayList.Sort

    If sortorder = xlDescending Then
        arrayList.Reverse
    End If
    
    dict.RemoveAll
    
    For Each value In arrayList
        Set coll = DictTemp(value)
        For Each item In coll
            dict.Add item, value
        Next item
    Next value
    
    Set arrayList = Nothing
    Set FctSortDictByValues = dict
        
Done:
    Exit Function
ErrorHandler:
    If Err.Number = 450 Then
        Err.Raise vbObjectError + 100, "FctSortDictByValues" _
                , "Cannot sort the dictionary if the value is an object"
    End If
    
End Function


Function FctVerifyExtension(sFile As String, TypeFile As String)

    Dim Fso     As Object
    Dim StrType As String
    Set Fso = CreateObject("Scripting.FileSystemObject")
    StrType = Fso.GetExtensionName(sFile)
    
    Select Case TypeFile
    
        Case "xlsx"
            If Not StrType = TypeFile Then
                MsgBox "Erreur Import CTF, l'extension du fichier doit etre un .xlsx", vbInformation, "Import CTF"
                End
            End If
        Case "csv"
            If Not StrType = TypeFile Then
                MsgBox "Erreur Import IFAT, l'extension du fichier : " & sFile & " doit etre un .csv", vbInformation, "Import IFAT"
                End
            End If
        End Select

End Function


Function FctIsWorkbookOpen(name As String) As Boolean

    Dim xWb As Workbook
    On Error Resume Next
    Set xWb = Application.Workbooks.item(name)
    FctIsWorkbookOpen = (Not xWb Is Nothing)
    On Error GoTo 0
    
End Function

Public Function FctPathExist(pname) As Boolean

    If Dir(pname, vbDirectory) = "" Or pname = "" Then
        FctPathExist = False
    Else
        FctPathExist = (GetAttr(pname) And vbDirectory) = vbDirectory
    End If
    
End Function

Public Function FctFolderExists(ByVal str_folder_path As String, Optional ByVal print_error_message As Boolean) As Boolean
    Dim Fso As New FileSystemObject
    FctFolderExists = True
    
    If Not Fso.FolderExists(str_folder_path) Then
        If print_error_message Then MsgBox "Folder '" & str_folder_path & "' not found", vbCritical
        FctFolderExists = False
    End If
    
End Function

Public Function FctFileExist(filepath As String) As Boolean

    Dim test_str As String
    On Error Resume Next
    test_str = Dir(filepath)
    On Error GoTo 0
    If test_str = "" Then
        FctFileExist = False
    Else
        FctFileExist = True
    End If
    
End Function

Public Function FctShtExist(sheetToFind As String, Optional InWorkbook As Workbook) As Boolean
    If InWorkbook Is Nothing Then Set InWorkbook = ThisWorkbook
    
    Dim Sheet As Object
    For Each Sheet In InWorkbook.Sheets
        If sheetToFind = Sheet.name Then
            FctShtExist = True
            Exit Function
        End If
    Next Sheet
    FctShtExist = False
End Function

Sub Get_path_CTF()

    Dim chemin As String
    On Error GoTo ErrorHandler
    
    With Application.FileDialog(msoFileDialogFilePicker)
        '.InitialFileName = ""
        .Title = "Select CTF File"
        .Show
        If .SelectedItems.count = 0 Then
            'MsgBox "Canceled"
        Else
            MsgBox .SelectedItems(1), vbInformation
            chemin = Application.FileDialog(msoFileDialogFolderPicker).SelectedItems(1)
            ws_main.[rng_path_CTF] = chemin
        End If
    End With

Exit Sub


ErrorHandler:
        MsgBox Err.description, vbCritical
End Sub

Sub Get_path_ifat()

    With Application.FileDialog(msoFileDialogFolderPicker)
    .InitialFileName = Application.DefaultFilePath & "\"
    .Title = "Select a IFAT Folder"
    .Show
    If .SelectedItems.count = 0 Then
        'MsgBox "Canceled"
    Else
        ws_main.[rng_path_ifat] = .SelectedItems(1)
    End If
    End With
    
End Sub

Sub Get_FileNameIfat1()
    Dim chemin As String
    On Error GoTo ErrorHandler
    
    With Application.FileDialog(msoFileDialogFilePicker)
        '.InitialFileName = ""
        .Title = "Select IFAT File"
        .Show
        If .SelectedItems.count = 0 Then
            'MsgBox "Canceled"
        Else
            chemin = Application.FileDialog(msoFileDialogFolderPicker).SelectedItems(1)
            ws_main.[rng_ifat_FileName1] = Dir(chemin)
        End If
    End With

Exit Sub


ErrorHandler:
        MsgBox Err.description, vbCritical
End Sub

Sub Get_FileNameIfat2()

    Dim chemin As String
    On Error GoTo ErrorHandler
    
    With Application.FileDialog(msoFileDialogFilePicker)
        '.InitialFileName = ""
        .Title = "Select IFAT File"
        .Show
        If .SelectedItems.count = 0 Then
            'MsgBox "Canceled"
        Else
            chemin = Application.FileDialog(msoFileDialogFolderPicker).SelectedItems(1)
            ws_main.[rng_ifat_FileName2] = Dir(chemin)
        End If
    End With

Exit Sub


ErrorHandler:
        MsgBox Err.description, vbCritical

End Sub

Sub Get_path_folder()


    Dim folder_picker As FileDialog
    Dim my_folder As String

      Set folder_picker = Application.FileDialog(msoFileDialogFolderPicker)
    
      With folder_picker
        .Title = "Select A Export Folder"
        .AllowMultiSelect = False
        If .Show <> -1 Then Exit Sub 'Check if user clicked cancel button
        my_folder = .SelectedItems(1)
        ws_main.[rng_export] = my_folder
      End With

    MsgBox my_folder, vbInformation

End Sub
```

## import

```
Option Explicit
Option Base 1

Function MainImportData(IfCFT As Boolean)

    Dim sht                     As Worksheet
    Dim DictLabelMapping        As Dictionary
    Dim DictFileNameIfat        As Dictionary
    Dim KeyFile                 As Variant
    Dim IfIFA                   As Boolean
    Dim BoolSeveralImportTemp   As Boolean
    Dim PathRange               As String
    Dim RangeAddress            As String
    Dim FullPath                As String
    Dim FullPathFileLight       As String
    Dim StrRepIfat              As String
    Dim StrToFindInCSv          As String
    Dim WsCtf       As String
    Dim WsIfat      As String
    
    On Error GoTo ErrorHandler:
    
    RangeAddress = ws_mapping.Range("rng_mapping_input_CTF").Address
    Set DictLabelMapping = FctLoadDictLabel(StartCellTemp:=RangeAddress, array_type:="v")
    
    If IfCFT = True Then
        PathRange = ws_main.[rng_path_CTF]
        WsCtf = ws_input_CTF.name
    Else 'IFAT
        StrRepIfat = ws_main.[rng_path_ifat]
        WsIfat = ws_input_ifac.name
    End If

    If IfCFT = True Then
        '1)Clear
        Call ClearData(WsNameTemp:=WsCtf, StartCellTemp:="A3", NumMethod:=4)
        '2)Vérification Input
        Set sht = FctDefineShtAndVerifyPath(PathRange)
        Call FctVerifyExtension(PathRange, "xlsx")
        
        '3)Récupération données
        Call TreatmentData("xlsx", ShtTemp:=sht, StrPathRange:=PathRange, WsDisplayResult:=WsCtf, DictLabelMapping:=DictLabelMapping, IfImputCTF:=IfCFT, _
                            BoolSeveralImport:=False, BoolSql:=False)
    Else
        'IFAT
        StrToFindInCSv = ws_main.[rng_ifat_keyword]
        
        '1)Clear
        Call ClearData(WsNameTemp:=WsIfat, StartCellTemp:="A3", NumMethod:=4)
        
        '2)Récuperation des fichiers CSV IFAT
        Set DictFileNameIfat = FctGetDictFileNameIfat(FctCheckRep(StrRepIfat), StrToFindInCSv)
        
        '3)Check label Input - Mapping
        If DictFileNameIfat.count >= 1 Then
            'Vérification des labels IFAT à partir d'un seul fichier IFAT le moins volumineux retrouvé dans le dossier import IFAT
            FullPathFileLight = FctCheckRep(StrRepIfat) & CStr(DictFileNameIfat.Keys(0))
           If FctCheckLabelInput("csv", FullPathFileLight, DictLabelMapping) = False Then
                Exit Function
            End If
        End If
        '4)Récupération données
        BoolSeveralImportTemp = False
        For Each KeyFile In DictFileNameIfat.Keys
        
            Debug.Print KeyFile
            
            '2)Vérification Input
            FullPath = FctCheckRep(StrRepIfat) & CStr(KeyFile)
            '3)Récupération données
            Call TreatmentData("csv", StrPathRange:=FullPath, WsDisplayResult:=WsIfat, DictLabelMapping:=DictLabelMapping, IfImputCTF:=IfCFT, _
                                BoolSeveralImport:=BoolSeveralImportTemp, BoolSql:=True)
            BoolSeveralImportTemp = True
        Next KeyFile
    End If
    
    Set DictLabelMapping = Nothing
    Exit Function
ErrorHandler:
    MsgBox "Error Import, vérifier le mapping", vbCritical
    Err.Raise 1
    Exit Function

End Function

'Récupération données
Sub TreatmentData(TypeImport As String, StrPathRange As String, WsDisplayResult As String, IfImputCTF As Boolean, DictLabelMapping As Dictionary, _
                        BoolSeveralImport As Boolean, Optional ShtTemp As Worksheet, Optional BoolSql As Boolean)

    Dim ArrayResult             As Variant
    Dim LastRow                 As Variant
    Dim WsResult                As Worksheet
    Dim DictInputArrRstAndLabel As Dictionary
    
    'Chargement données dans variable tableau et classement pour création clé concat mapping
    If IfImputCTF = True Then
        ArrayResult = ImportCtf(ShtTemp, DictLabelMapping)
        'Workbooks(Dir(StrPathRange)).Close False
    Else
    
        If BoolSql = False Then
            'Méthode Array
            Set DictInputArrRstAndLabel = FctGetDictInputArrRstAndLabel(TypeImport, StrPathRange, DictLabelMapping)
            ArrayResult = ImportIfatMethodArray(DictLabelMapping, DictInputArrRstAndLabel)
            Set DictInputArrRstAndLabel = Nothing
        Else
            'Méthode SQL
            Call ImportIfatMethodSql(StrPathRange, DictLabelMapping, WsDisplayResult, BoolSeveralImport)
        End If
        
    End If

    If BoolSql = False Then
    
    Set WsResult = Workbooks(CStr(ThisWorkbook.name)).Worksheets(WsDisplayResult)
   
   
        With WsResult
            If BoolSeveralImport = False Then
                .Range("A2").Resize(UBound(ArrayResult, 1), UBound(ArrayResult, 2)).value = ArrayResult
                .Range("A2").Resize(UBound(ArrayResult, 1), UBound(ArrayResult, 2)).HorizontalAlignment = xlCenter
            Else
                LastRow = .Cells(Rows.count, "A").End(xlUp).Offset(1, 0).Row
                .Range("A" & LastRow).Resize(UBound(ArrayResult, 1), UBound(ArrayResult, 2)).value = ArrayResult
                'Suppression ligne title
                .Rows(LastRow).Delete
                .Range("A" & LastRow).Resize(UBound(ArrayResult, 1), UBound(ArrayResult, 2)).HorizontalAlignment = xlCenter
            End If
        End With
        
    End If
    
End Sub

'================================================================================================================='
'================================================Import (CTF)====================================================='
'================================================================================================================='

'Chargement données dans variable tableau et classement pour création clé concat mapping
Function ImportCtf(sht_temp As Worksheet, dico_label As Dictionary) As Variant

    Dim ArrayInput          As Variant
    Dim ArrayResult         As Variant
    Dim key_LabelOrder      As Variant
    Dim key_LabelMissed     As Variant
    Dim dico_LabelMissed    As Dictionary
    Dim msg_LabelMissed     As String
    Dim i                   As Long
    Dim j                   As Integer
    Dim count               As Integer
    Dim without_title       As Byte
    Dim NumRowBegin         As Byte
    Dim LabelFound          As Boolean

    Set dico_LabelMissed = New Dictionary
    without_title = 0 'if true=1
    NumRowBegin = 1 'if true=2
    
    If sht_temp.Range("A1") = "" Then
        MsgBox "Import impossible, les données des inputs doivent débuter en cellule A1", vbCritical
        Exit Function
    End If
    
    'on charge les données dans une variable tableau
    ArrayInput = sht_temp.Range("A1").CurrentRegion
    
    Workbooks(Dir(CStr(ws_main.[rng_path_CTF]))).Close False
  
    ReDim ArrayResult(NumRowBegin To UBound(ArrayInput, 1) + without_title, 1 To dico_label.count)
    count = 1
    For Each key_LabelOrder In dico_label.Keys
        If Not dico_label(key_LabelOrder) = "N contrat" Then
            LabelFound = False
            For j = LBound(ArrayInput, 2) To UBound(ArrayInput, 2)
                'vérification matching avec les labels attendus
                If dico_label.Exists(CStr(ArrayInput(1, j))) = True Then
                    'Boucle+condition pour respecter l'odre précis des champs concatenés du mapping
                    If ArrayInput(1, j) = key_LabelOrder Then
                        LabelFound = True
                        For i = LBound(ArrayInput, 1) + without_title To UBound(ArrayInput, 1)
                            ArrayResult(i, count) = FctFillIfEmpty(ArrayInput(i, j))
                            'On inverse le signe de la colonne montant
                            If ArrayResult(1, count) = ws_mapping.Range("rng_mapping_InputAmount") And i <> 1 Then
                                ArrayResult(i, count) = -(ArrayInput(i, j))
                            End If
                        Next i
                        'on renomme les labels avec ceux du mapping
                        ArrayResult(1, count) = dico_label(key_LabelOrder)
                        count = count + 1
                    End If
                End If
            Next j
            If LabelFound = False Then
                If Not dico_LabelMissed.Exists(key_LabelOrder) Then: dico_LabelMissed.Add key_LabelOrder, ""
            End If
        End If
    Next key_LabelOrder
    
    For Each key_LabelMissed In dico_LabelMissed.Keys
        msg_LabelMissed = msg_LabelMissed & "," & key_LabelMissed
    Next
    
    If Len(msg_LabelMissed) > 1 Then: MsgBox "Attention des champs mapping n'existe pas dans l'input :" & Chr(13) & Chr(10) & msg_LabelMissed _
    & Chr(13) & Chr(10) & "veuillez les ajouter ou modifier le mapping", vbCritical, "Import de CTF"
    
    ImportCtf = ArrayResult
    Set ArrayResult = Nothing
    Set dico_LabelMissed = Nothing
      
End Function

Function FctDefineShtAndVerifyPath(path_range As String) As Worksheet

    Dim target_workbook     As Workbook
    Dim sht                 As Worksheet
    
    If FctFileExist(path_range) = False Then
        MsgBox "The file :" & vbCrLf & vbCrLf & path_range & vbCrLf & vbCrLf & " doesn't exist", vbCritical, "Error input" & Dir(path_range)
        Exit Function
    End If
    
    If FctIsWorkbookOpen(Dir(path_range)) = True Then
        Set target_workbook = Workbooks(Dir(path_range))
        Set FctDefineShtAndVerifyPath = target_workbook.Sheets(1)
    Else
        Set target_workbook = Workbooks.Open(path_range, , True)
        Set FctDefineShtAndVerifyPath = target_workbook.Sheets(1)
    End If

End Function

'================================================================================================================='
'===============================================Import (IFAT)====================================================='
'================================================================================================================='

'Récupérations de tous les fichiers CSV IFAT et de leurs tailles
Function FctGetDictFileNameIfat(StrPathFolder As String, StrToFindInCSv As String) As Dictionary

    Dim OFso                As Object
    Dim OFolder             As Object
    Dim OFile               As Object
    Dim OFileFound          As Object
    Dim DictFileName_Size   As New Dictionary
    Dim StrSearch           As String
    Dim NameFileFound       As String
    Dim FileSize            As Long
    Dim BoolFileFound       As Boolean

    Set OFso = CreateObject("Scripting.FileSystemObject")
    Set OFolder = OFso.GetFolder(StrPathFolder)
    
    StrSearch = StrToFindInCSv
    BoolFileFound = False
    
    'Récuperation de tous les noms des fichiers d'imports IFAT
    If OFso.FolderExists(StrPathFolder) Then
        For Each OFile In OFolder.Files
            If InStrRev(Dir(OFile), StrSearch) > 0 Then
                Call FctVerifyExtension(CStr(OFile), "csv")
                NameFileFound = Right(OFile, Len(OFile) - InStrRev(OFile, "\"))
                BoolFileFound = True
                Set OFileFound = OFso.GetFile(StrPathFolder & NameFileFound)
                FileSize = OFileFound.Size
                'Dictionaire Non Fichier - Taille
                If Not DictFileName_Size.Exists(NameFileFound) Then
                    DictFileName_Size.Add NameFileFound, FileSize
                End If
            End If
        Next OFile
    End If
    
    'Tri décroissant du dictionaire
    Set FctGetDictFileNameIfat = FctSortDictByValues(DictFileName_Size, xlAscending)
    
    Set DictFileName_Size = Nothing
    Set OFso = Nothing
    Set OFolder = Nothing
    Set OFileFound = Nothing
    
    If BoolFileFound = False Then
        MsgBox "Aucun fichier avec le mot clé : " & StrSearch & Chr(13) & Chr(10) & _
                "retrouvé dans le chemin suivant : " & StrPathFolder, vbInformation, "Récuperation des fichiers d'import IFAT"
    End If
    
End Function

'========================================Import Treatment SQL(IFAT)==============================================='

Function ImportIfatMethodSql(FullPath As String, DictLabelMapping As Dictionary, WsDisplayResult As String, BoolSeveralImport As Boolean) As Variant

    Dim cn                      As New ADODB.Connection
    Dim rst                     As ADODB.Recordset
    Dim DictGroupBy             As New Dictionary
    Dim DictLabel               As New Dictionary
    Dim KeyLabel                As Variant
    Dim ArrayRst                As Variant
    Dim Fichier                 As String
    Dim Rep                     As String
    Dim StrGroupByTopIntExt     As String
    Dim StrGroupByZoneFiscale   As String
    Dim StrGroupByCoefTax       As String
    Dim StrGroupByMethAdpt      As String
    Dim StrGroupByZuccursale    As String
    Dim StrGroupByGtva          As String
    Dim StrGroupByNcontrat      As String
    Dim StrPccoSuffixe          As String
    Dim StrPcecEvolan           As String
    Dim StrPcecRglt             As String
    Dim StrAmount               As String
    Dim KeyWordSelect           As String
    Dim SelectSql               As String
    Dim AmountSql               As String
    Dim FullSelect              As String
    Dim KeyWordGroupBy          As String
    Dim GroupBySql              As String
    Dim KeyWordHaving           As String
    Dim AmountHavingSql         As String
    Dim FullRequest             As String
    Dim i                       As Long
    Dim LastRow                 As Long

    On Error GoTo ErrorHandler:
    
    Rep = Left(FullPath, InStrRev(FullPath, Application.PathSeparator))
    Fichier = Dir(FullPath)
    
    ''Modification  base de registre du fichier Schema.ini dans le répertoire qui contient le CSV (ADODB csv USA ',')
    Call FctModifyShemaIniCsv(Rep, Fichier, "Delimited(;)")
   
'    ----------------------------------------------------
'   Objectif créer cette requete de manière dynamique
'    ----------------------------------------------------
'    Select FIRST([PCCO suffixé]) AS [PCCO Suffixe], FIRST([PCEC rest Evolan || 700 - AS]) AS [PCEC de reporting], FIRST([PCEC calc rglt || 31 - AS]) AS [PCEC calcule], [Top int / ext] AS [Top Int-Ext], [Cd Zone fiscale] AS [Zone Fiscale], [Cd famille coef de taxation] AS [Famille Coeff Taxation], [TAX_METH_COD_ADPT] AS [Methode Calcul Coeff Taxation], [FLAG_SUCC] AS [Succursale], [Flag Code partenaire GTVA] AS [GTVA], [N° cont] AS [N contrat], abs(sum([Mt en devise de solde converti en euros])) AS [Amount]
'    FROM [GRPTVA_IFAT_CTF_2022_1#csv]
'    Group By
'    [Top int / ext] , [Cd Zone fiscale], [Cd famille coef de taxation], [TAX_METH_COD_ADPT], [FLAG_SUCC], [Flag Code partenaire GTVA], [N° cont]
'    HAVING
'    Sum ([Mt en devise de solde converti en euros]) < 0
 
    With ws_mapping
        StrGroupByTopIntExt = CStr(.Range("rng_mapping_TopIntExt"))
        StrGroupByZoneFiscale = CStr(.Range("rng_mapping_ZoneFiscale"))
        StrGroupByCoefTax = CStr(.Range("rng_mapping_FamCoeffTax"))
        StrGroupByMethAdpt = CStr(.Range("rng_mapping_MethodClcCoeffTax"))
        StrGroupByZuccursale = CStr(.Range("rng_mapping_Succursale"))
        StrGroupByGtva = CStr(.Range("rng_mapping_GTVA"))
        StrGroupByNcontrat = CStr(.Range("rng_mapping_contrat"))
        DictGroupBy.Add StrGroupByTopIntExt, DictLabelMapping(StrGroupByTopIntExt)
        DictGroupBy.Add StrGroupByZoneFiscale, DictLabelMapping(StrGroupByZoneFiscale)
        DictGroupBy.Add StrGroupByCoefTax, DictLabelMapping(StrGroupByCoefTax)
        DictGroupBy.Add StrGroupByMethAdpt, DictLabelMapping(StrGroupByMethAdpt)
        DictGroupBy.Add StrGroupByZuccursale, DictLabelMapping(StrGroupByZuccursale)
        DictGroupBy.Add StrGroupByGtva, DictLabelMapping(StrGroupByGtva)
        DictGroupBy.Add StrGroupByNcontrat, DictLabelMapping(StrGroupByNcontrat)
        StrPccoSuffixe = CStr(.Range("rng_mapping_input_CTF"))
        StrPcecEvolan = CStr(.Range("rng_mapping_PCECReporting"))
        StrPcecRglt = CStr(.Range("rng_mapping_PCEC_Calcule"))
        DictLabel.Add StrPccoSuffixe, DictLabelMapping(StrPccoSuffixe)
        DictLabel.Add StrPcecEvolan, DictLabelMapping(StrPcecEvolan)
        DictLabel.Add StrPcecRglt, DictLabelMapping(StrPcecRglt)
        StrAmount = CStr(.Range("rng_mapping_InputAmount"))
    End With
        
    KeyWordSelect = "Select "
    For Each KeyLabel In DictLabel.Keys
        SelectSql = SelectSql & "FIRST([" & CStr(KeyLabel) & "]) AS " & "[" & DictLabel(CStr(KeyLabel)) & "], "
    Next KeyLabel
    For Each KeyLabel In DictGroupBy.Keys
        SelectSql = SelectSql & "[" & CStr(KeyLabel) & "] AS " & "[" & DictGroupBy(CStr(KeyLabel)) & "], "
    Next KeyLabel
    AmountSql = "abs(sum([" & StrAmount & "])) AS " & "[" & DictLabelMapping(StrAmount) & "] "
    FullSelect = KeyWordSelect & SelectSql & AmountSql & " FROM [" & Replace(Fichier, ".", "#") & "]"
        
    KeyWordGroupBy = " Group By "
    For Each KeyLabel In DictGroupBy.Keys
        GroupBySql = GroupBySql & "[" & CStr(KeyLabel) & "], "
    Next KeyLabel
    GroupBySql = KeyWordGroupBy & FctDelComa(GroupBySql)

    KeyWordHaving = " HAVING "
    AmountHavingSql = KeyWordHaving & "sum([" & StrAmount & "]) < 0"

    FullRequest = FullSelect & GroupBySql & AmountHavingSql

    Set rst = New ADODB.Recordset
    With cn
        .Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Rep & ";Extended Properties=""Text;HDR=YES;FMT=Delimited(;)"""
        Set rst = .Execute(FullRequest)
        'Affiche des Résultats
        With Worksheets(WsDisplayResult)
            If BoolSeveralImport = False Then
                For i = 0 To rst.Fields.count - 1
                    .Range("A2").Offset(, i) = rst(i).name
                Next i
                .Range("A3").CopyFromRecordset rst
            Else
                LastRow = .Cells(Rows.count, "A").End(xlUp).Offset(1, 0).Row
                .Range("A" & LastRow).CopyFromRecordset rst
            End If
        End With
        rst.Close
        .Close
     End With
     
ErrorExit:
    Set rst = Nothing
    Set cn = Nothing
    Set DictGroupBy = Nothing
    Set DictLabel = Nothing
    Exit Function
      
ErrorHandler:
    MsgBox "Erreur Import IFAT, vérifier correspondance entre le mapping et les libellés des colonnes du fichier :" & FullPath, vbCritical, "Import IFAT"
    Resume ErrorExit
End Function

'==================================Import Treatment Array Dynamic (IFAT)=========================================='

Function ImportIfatMethodArray(DictLabelMapping As Dictionary, DictInputArrRstAndLabel As Dictionary) As Variant
    
    Dim ArrayTempFiltered()         As Variant
    Dim KeyDict                     As Variant
    Dim KeyDictTemp                 As Variant
    Dim ArrayInput                  As Variant
    Dim DictContract                As Dictionary
    Dim DictTemp                    As Dictionary
    Dim DictContractUnique          As Dictionary
    Dim i                           As Long
    Dim j                           As Long
    Dim count                       As Long
    Dim colonneAmount               As Integer
    Dim colonneTypeContrat          As Integer
    Dim colonnePCCOSuffixe          As Integer
    Dim colonnePCECReporting        As Integer
    Dim colonnePECEC_Calcule        As Integer
    Dim colonneTopIntExt            As Integer
    Dim colonneZoneFiscale          As Integer
    Dim colonneFamCoeffTax          As Integer
    Dim colonneMethodClcCoeffTax    As Integer
    Dim colonneSuccursale           As Integer
    Dim colonneGTVA                 As Integer
    Dim KeyInput                    As String
    Dim KeyTemp                     As String
    Dim KeyInputLabel               As String
    Dim StrValue                    As String
    Dim DimMinus                    As Byte

    Set DictContractUnique = New Dictionary
    Set DictContract = New Dictionary
    Set DictTemp = New Dictionary
    ArrayInput = DictInputArrRstAndLabel("ArrayRst")
    
    'Optimisation ram
    DictInputArrRstAndLabel.Remove "ArrayRst"
    
    'Check Label Input - ws_Mapping
    For Each KeyDict In DictLabelMapping.Keys
        If Not DictInputArrRstAndLabel.Exists(CStr(KeyDict)) Then
            MsgBox "Attention des champs mapping n'existe pas dans l'input :" & Chr(13) & Chr(10) _
                    & Chr(13) & Chr(10) & "veuillez vérifier le mapping", vbCritical, "Erreur Import de IFAT "
            Exit Function
        End If
    Next KeyDict
    
    'Récupération position des colonnes
    With ws_mapping
        'Array RecordSet
        DimMinus = 1
        colonneAmount = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_InputAmount"))) - DimMinus
        colonneTypeContrat = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_contrat"))) - DimMinus
        colonnePCCOSuffixe = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_input_CTF"))) - DimMinus
        colonnePCECReporting = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_PCECReporting"))) - DimMinus
        colonnePECEC_Calcule = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_PCEC_Calcule"))) - DimMinus
        colonneTopIntExt = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_TopIntExt"))) - DimMinus
        colonneZoneFiscale = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_ZoneFiscale"))) - DimMinus
        colonneFamCoeffTax = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_FamCoeffTax"))) - DimMinus
        colonneMethodClcCoeffTax = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_MethodClcCoeffTax"))) - DimMinus
        colonneSuccursale = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_Succursale"))) - DimMinus
        colonneGTVA = DictInputArrRstAndLabel(CStr(.Range("rng_mapping_GTVA"))) - DimMinus
    End With

    'Préparation dict somme montant par unicité des categories (n°contrat non utilisable comme clé)
    For i = LBound(ArrayInput, 1) To UBound(ArrayInput, 1)
    
        KeyTemp = FctFillIfEmpty(ArrayInput(i, colonnePCCOSuffixe)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonnePCECReporting)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonnePECEC_Calcule))

        KeyInput = FctFillIfEmpty(ArrayInput(i, colonneTopIntExt)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneZoneFiscale)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneFamCoeffTax)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneMethodClcCoeffTax)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneSuccursale)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneGTVA)) & "__" & _
                    FctFillIfEmpty(ArrayInput(i, colonneTypeContrat))

        If Not DictContract.Exists(KeyInput) Then
            DictContract.Add KeyInput, CDbl(ArrayInput(i, colonneAmount))
            DictTemp.Add CStr(KeyInput), KeyTemp
        ElseIf DictContract.Exists(KeyInput) Then
            DictContract.item(KeyInput) = DictContract.item(KeyInput) + ArrayInput(i, colonneAmount)
        End If
    Next i
    
    'Filtre récuperation seulement des contrats dont le montant<0
    count = 0
    For Each KeyDict In DictContract.Keys
        If DictContract(KeyDict) < 0 Then
            DictContractUnique.Add KeyDict, DictContract(KeyDict)
            count = count + 1
        End If
    Next KeyDict
    
    'Optimisation ram
    Set DictContract = Nothing
    
    ReDim ArrayTempFiltered(1 To count + 1, 1 To 11)
    
    'Récupération des titres
    For j = 1 To 10
        With ws_mapping
            KeyInputLabel = DictLabelMapping(CStr(.Range("rng_mapping_input_CTF"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_PCECReporting"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_PCEC_Calcule"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_TopIntExt"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_ZoneFiscale"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_FamCoeffTax"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_MethodClcCoeffTax"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_Succursale"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_GTVA"))) & "__" & _
                            DictLabelMapping(CStr(.Range("rng_mapping_contrat")))
        End With
        ArrayTempFiltered(1, j) = Split(KeyInputLabel, "__")(j - 1)
    Next j
    ArrayTempFiltered(1, 11) = DictLabelMapping.item(CStr(ws_mapping.Range("rng_mapping_InputAmount")))

    'Optimisation ram
    Erase ArrayInput
    
    'Remplissage de la variable ArrayInput résultat
    i = 2
    For Each KeyDict In DictContractUnique.Keys
        'pour champ  clé mapping
        For j = 1 To UBound(Split(KeyDict, "__")) + 1
            StrValue = Split(KeyDict, "__")(j - 1)
            If StrValue = "empty" Then StrValue = ""
            ArrayTempFiltered(i, 3 + j) = StrValue
        Next j
        'pour champ non clé mapping
        KeyDictTemp = DictTemp.item(KeyDict)
        For j = 1 To UBound(Split(KeyDictTemp, "__")) + 1
            StrValue = Split(KeyDictTemp, "__")(j - 1)
            ArrayTempFiltered(i, j) = StrValue
        Next j
        'on récupère le montant
        ArrayTempFiltered(i, 11) = Abs(DictContractUnique(KeyDict))
        i = i + 1
    Next KeyDict
    
    Set DictTemp = Nothing
    Set DictContractUnique = Nothing
    ImportIfatMethodArray = ArrayTempFiltered
    Erase ArrayTempFiltered

End Function

'================================================================================================================='
'================================================TOOLS IMPORT====================================================='
'================================================================================================================='

'=================================================TOOLS SQL======================================================='

'Préparation de l'import CSV IFAT par méthode CSV
Function FctGetDictInputArrRstAndLabel(TypeImport As String, FullPath As String, DictLabelMapping As Dictionary, Optional BoolNoStockRst As Boolean) As Dictionary

    'Necessite :
    'Microsoft ActiveX Data Objects
    'Microsoft ADO  pour DDL et sécurité.

    Dim cn                  As New ADODB.Connection
    Dim rst                 As ADODB.Recordset
    Dim objCat              As ADOX.Catalog
    Dim ShtName             As ADOX.Table
    Dim ArrayRst            As Variant
    Dim ArrayRst1           As Variant
    Dim DictLabelRst        As New Dictionary
    Dim DictTemp            As New Dictionary
    Dim StrRep              As String
    Dim StrFile             As String
    Dim ListSelectLabelSql  As String
    Dim ShtTable            As String
    Dim i                   As Long
    
    StrRep = Left(FullPath, InStrRev(FullPath, Application.PathSeparator))
    StrFile = Dir(FullPath)
    
    If TypeImport = "csv" Then 'Modification du fichier ini CSV
        Call FctModifyShemaIniCsv(StrRep, StrFile, "Delimited(;)")
    End If
    
    Set rst = New ADODB.Recordset
    With cn
        If TypeImport = "csv" Then
            'connexion à la base de  données (votre StrFile CSV)
            .Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & StrRep & ";Extended Properties=""Text;HDR=YES;FMT=Delimited(;)"""
        ElseIf TypeImport = "xlsx" Then
            .Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & FullPath & ";Extended Properties=""Excel 12.0; HDR=YES; IMEX=1""; Mode=Read;"
        End If
        
        If BoolNoStockRst = True Then
            'Pour Check champs
            ListSelectLabelSql = "TOP 1 * " & ListSelectLabelSql
        Else
            'Récupération des champs
            ListSelectLabelSql = FctListSelectLabelSql(DictLabelMapping)
        End If
        
        If TypeImport = "csv" Then
            Set rst = .Execute("Select " & ListSelectLabelSql & " from [" & Replace(StrFile, ".", "#") & "]")
        ElseIf TypeImport = "xlsx" Then
            Set objCat = New ADOX.Catalog
            Set objCat.ActiveConnection = cn
            For Each ShtName In objCat.Tables
                DictTemp.Add ShtName.name, ""
            Next
            ShtTable = FctAdoGetShtName(DictTemp)
            Set rst = .Execute("Select  * " & " from [" & ShtTable & "] ")
        End If
        
        'on stock la variable tableau dans dictionnaire
        If BoolNoStockRst = False Then 'par défaut
            ArrayRst = rst.GetRows
            ArrayRst = FctTransposeArrayStr(ArrayRst)
            DictLabelRst.Add "ArrayRst", ArrayRst
        End If
        'on stock les labels associé à leurs numeros de colonnes
        For i = 0 To rst.Fields.count - 1
             DictLabelRst.Add CStr(rst(i).name), i + 1
        Next
        'call FctDisplayRst(rst,ws_test)
        rst.Close
        .Close
    End With
    
    Set cn = Nothing
    Set objCat = Nothing
    Set rst = Nothing
    
    Set FctGetDictInputArrRstAndLabel = DictLabelRst
    Set DictLabelRst = Nothing
    Set DictTemp = Nothing
    
End Function

'Modification  base de registre du fichier Schema.ini dans le répertoire qui contient le CSV (car ADODB csv USA ',')
Function FctModifyShemaIniCsv(ByVal Server As String, Fichier As String, Delimited As String)

    Dim txt As String
    If Right(Server, 1) <> "\" Then Server = Server & "\"
    txt = "[" & Fichier & "]" & vbCrLf & "Format= " & Delimited
    With CreateObject("Scripting.FileSystemObject")
        With .OpenTextFile(Server & "Schema.ini", 2, True)
            .Write txt
            .Close
        End With
    End With

End Function

'Récupération du nom correct de la feuille d'un fichier .xlsx par ADO
Function FctAdoGetShtName(DictTemp As Dictionary) As String
    Dim KeyDict As Variant
    Select Case DictTemp.count
        Case 1
            For Each KeyDict In DictTemp.Keys
                FctAdoGetShtName = CStr(KeyDict)
            Next KeyDict
        Case 2
            For Each KeyDict In DictTemp.Keys
                If InStr(CStr(KeyDict), "xlnm") = 0 Then
                    FctAdoGetShtName = CStr(KeyDict)
                End If
            Next KeyDict
        Case 3
            For Each KeyDict In DictTemp.Keys
                If InStr(CStr(KeyDict), "xlnm") = 0 And InStr(CStr(KeyDict), "Feuil1$") = 0 Then
                    FctAdoGetShtName = CStr(KeyDict)
                End If
            Next KeyDict
        Case Else
            MsgBox "Input xlsx a plus d'une feuille, impossible de déterminer l'importe, veuillez laissé qu'une seule feuille", vbCritical, "Import Data xlsx"
    End Select
    If Not Right(FctAdoGetShtName, 1) = "$" Then
        FctAdoGetShtName = FctAdoGetShtName & "$"
    End If
    
End Function

Function FctListSelectLabelSql(DicoLabelMapping As Dictionary) As String

    Dim KeyDict             As Variant
    Dim StrLabel            As String

    For Each KeyDict In DicoLabelMapping.Keys
        StrLabel = StrLabel & "[" & CStr(KeyDict) & "], "
    Next KeyDict

    FctListSelectLabelSql = FctDelComa(StrLabel)

End Function

Function FctDelComa(StrLabel As String) As String
    'suppresion la virgule finale
    If Right(StrLabel, 2) = ", " Then
        StrLabel = Left(StrLabel, Len(StrLabel) - 2)
    End If
    FctDelComa = StrLabel
End Function

Function FctDisplayRst(rst As ADODB.Recordset, Optional sht As Worksheet)
    If IsMissing(sht) Then
        For i = 0 To rst.Fields.count - 1
             ActiveSheet.Range("A1").Offset(, i) = rst(i).name
        Next i
        'Range("A2").Resize(UBound(ArrayRst, 1), UBound(ArrayRst, 2) + 1).value = ArrayRst
        ActiveCell.Range("A2").CopyFromRecordset rst
    Else
        For i = 0 To rst.Fields.count - 1
             sht.Range("A1").Offset(, i) = rst(i).name
        Next i
        sht.Range("A2").CopyFromRecordset rst
    End If
End Function

'=================================================TOOLS MAPPING======================================================='

'Récupération des labels mapping
Public Function FctLoadDictLabel(ByVal StartCellTemp As String, ByVal array_type As String, Optional type_label As String) As Dictionary

    Dim MyArray     As Variant
    Dim DictArray   As Dictionary
    Dim LastCol     As Long
    Dim LastRow     As Long
    Dim x           As Integer
    Dim count       As Integer
    
    Set DictArray = New Dictionary
    count = 1
    If array_type = "v" Then
        With ws_mapping
            LastRow = .Range(StartCellTemp).End(xlDown).Row
            LastCol = .Range(StartCellTemp).Column + 1
            MyArray = .Range(StartCellTemp & ":" & FctColLetter(LastCol) & LastRow)
        End With
        For x = LBound(MyArray, 1) To UBound(MyArray, 1)
            If Not DictArray.Exists(MyArray(x, 1)) Then
                DictArray.Add MyArray(x, 1), MyArray(x, 2)
            End If
            count = count + 1
        Next x
    ElseIf array_type = "h" Then
        Select Case type_label
            Case "mapping"
                With ws_mapping
                    LastCol = .Cells(.Range(StartCellTemp).Row, .Range(StartCellTemp).Column).End(xlToRight).Column
                    LastRow = .Cells(.Rows.count, .Range(StartCellTemp).Column).End(xlUp).Row
                    MyArray = .Range(StartCellTemp & ":" & FctColLetter(LastCol) & LastRow)
                End With
            Case "input_CTF"
                With ws_input_CTF
                    LastCol = .Cells(.Range(StartCellTemp).Row, .Columns.count).End(xlToLeft).Column
                    LastRow = .Cells(.Rows.count, .Range(StartCellTemp).Column).End(xlUp).Row
                    MyArray = .Range(StartCellTemp & ":" & FctColLetter(LastCol) & LastRow)
                End With
            Case "input_ifac"
                With ws_input_ifac
                    LastCol = .Cells(.Range(StartCellTemp).Row, .Columns.count).End(xlToLeft).Column
                    LastRow = .Cells(.Rows.count, .Range(StartCellTemp).Column).End(xlUp).Row
                    MyArray = .Range(StartCellTemp & ":" & FctColLetter(LastCol) & LastRow)
                End With
        End Select
        For x = LBound(MyArray, 2) To UBound(MyArray, 2)
            If Not DictArray.Exists(MyArray(1, x)) Then
                DictArray.Add CStr(MyArray(1, x)), count
            End If
            count = count + 1
        Next
    End If
    
    Set FctLoadDictLabel = DictArray
    Set DictArray = Nothing
    Set MyArray = Nothing
    
End Function

Function FctCheckFilters(amount As Variant) As Boolean

    FctCheckFilters = False
    If amount > 0 Then
        FctCheckFilters = True
     Else
        FctCheckFilters = False
    End If
    
End Function

'=================================================TOOLS CHECK ======================================================='

Function FctCheckLabelInput(TypeInput As String, FileName As String, DictLabelMapping As Dictionary) As Boolean

    Dim KeyDict             As Variant
    Dim DictLabelMissed     As New Dictionary
    Dim DictInputLabel      As Dictionary
    Dim MsgLabelMissed      As String
    Dim BoolLabelMissed     As Boolean
    
    Set DictInputLabel = FctGetDictInputArrRstAndLabel(TypeInput, FileName, DictLabelMapping, True)
    BoolLabelMissed = False
    For Each KeyDict In DictLabelMapping.Keys
        If Not KeyDict = ws_mapping.Range("rng_mapping_contrat") Then
            If Not DictInputLabel.Exists(CStr(KeyDict)) Then
                BoolLabelMissed = True
                DictLabelMissed.Add CStr(KeyDict), ""
            End If
        End If
    Next KeyDict

    If BoolLabelMissed = True Then
        FctCheckLabelInput = False
        For Each KeyDict In DictLabelMissed.Keys
            MsgLabelMissed = MsgLabelMissed & KeyDict & ", "
        Next
        If Right(MsgLabelMissed, 2) = ", " Then
            MsgLabelMissed = Left(MsgLabelMissed, Len(MsgLabelMissed) - 2)
        End If
        
        MsgBox "veuillez vérifier le mapping, pour l'import" & Dir(FileName) & Chr(13) & Chr(10) & "Les champs suivants ne sont pas retrouvés" & Chr(13) & Chr(10) & Chr(10) & MsgLabelMissed _
        & Chr(13) & Chr(10) & Chr(10) & "Veuillez les ajouter ou modifier le mapping, les champs doivent etre identiques pour tous les inputs", _
        vbCritical, "Error on Label Mapping for File Import  :" & Dir(FileName)
    Else
        FctCheckLabelInput = True
    End If
    
    Set DictLabelMissed = Nothing
    Set DictInputLabel = Nothing
    
End Function

Function FctCheckRep(PathTemp As String) As String

    If Not Right(PathTemp, 1) = "\" Then
        FctCheckRep = PathTemp & "\"
    Else
        FctCheckRep = PathTemp
    End If
    
End Function

Function ClearData(WsNameTemp As String, StartCellTemp As String, NumMethod As Byte)

    Dim WsResult   As Worksheet
    Dim RngData    As Range
    Dim LastCol    As Long
    Dim LastRow    As Long
    
    Set WsResult = Workbooks(CStr(ThisWorkbook.name)).Worksheets(WsNameTemp)
    With WsResult
        Select Case NumMethod
            Case 1
                Set RngData = .Range(.Range(StartCellTemp), .Range(StartCellTemp).End(xlDown))
                Set RngData = .Range(RngData, RngData.End(xlToRight))
                RngData.Clear
                Set RngData = Nothing
            Case 2
                LastCol = .Cells(.Range(StartCellTemp).Row, .Columns.count).End(xlToLeft).Column
                LastRow = .Cells(.Rows.count, .Range(StartCellTemp).Column).End(xlUp).Row
                .Range(StartCellTemp & ":" & FctColLetter(LastCol) & LastRow).Clear
            Case 3
                LastCol = .Range(StartCellTemp).Offset(-1, 0).End(xlToRight).Column
                LastRow = .Range(StartCellTemp).Offset(0, -2).End(xlDown).Row
                .Range(.Range(StartCellTemp), .Cells(LastRow, LastCol)).ClearContents
            Case 4
                .Cells.ClearContents
        End Select
    End With
    
End Function

'=================================================TOOLS ======================================================='

Function FctTransposeArrayVar(InputArray As Variant) As Variant

    Dim tmp()   As Variant
    Dim i       As Long
    Dim j       As Long
    
    ReDim tmp(LBound(InputArray, 2) To UBound(InputArray, 2), LBound(InputArray, 1) To UBound(InputArray, 1))
    
    For i = LBound(InputArray, 2) To UBound(InputArray, 2)
        For j = LBound(InputArray, 1) To UBound(InputArray, 1)
            If IsNull(InputArray(j, i)) Then
                tmp(i, j) = ""
            Else
                tmp(i, j) = InputArray(j, i)
            End If
        Next j
    Next i
    FctTransposeArrayVar = tmp
    Erase tmp
    
End Function

Function FctTransposeArrayStr(InputArray As Variant) As String()

    Dim tmp() As String
    Dim i       As Long
    Dim j       As Long

    ReDim tmp(LBound(InputArray, 2) To UBound(InputArray, 2), LBound(InputArray, 1) To UBound(InputArray, 1))
    For i = LBound(InputArray, 1) To UBound(InputArray, 1)
        For j = LBound(InputArray, 2) To UBound(InputArray, 2)
            If Not IsNull(InputArray(i, j)) Then
                tmp(j, i) = InputArray(i, j)
            End If
        Next j
    Next i
    FctTransposeArrayStr = tmp
    Erase tmp
    
End Function

'Non utilisé (en veille)
Function FctGetKeyDict(Dic As Dictionary, str_item As Variant) As String

    Dim key As Variant
    For Each key In Dic.Keys
        If Dic.item(key) = str_item Then
            FctGetKeyDict = CStr(key)
            Exit Function
        End If
    Next
    If FctGetKeyDict = "" Then FctGetKeyDict = ""
       
End Function

'Non utilisé (en veille)
Sub FctSplitCsv(FullPath As String)
    
    Dim Fso     As Object
    Dim csv     As Object
    Dim header  As Variant
    Dim maxRows As Variant
    Dim i       As Variant
    Dim n       As Variant
    Dim out     As Variant
    Dim StrRep  As String
    
    maxRows = 150000
    StrRep = Left(FullPath, InStrRev(FullPath, Application.PathSeparator))
    Const ForReading = 1
    Const ForWriting = 2
    Set Fso = CreateObject("Scripting.FileSystemObject")
    i = 0
    n = 0
    Set out = Nothing
    Set csv = Fso.OpenTextFile(FullPath, ForReading)
    header = csv.ReadLine
    
    Do Until csv.AtEndOfStream
      If i = 0 Then
        If Not out Is Nothing Then out.Close
        Set out = Fso.CreateTextFile(StrRep & "SplitCsv_" & Right("00" & n, 2) & ".csv", ForWriting)
        out.WriteLine (header)
        n = n + 1
      End If
      out.WriteLine (csv.ReadLine)
      i = (i + 1) Mod maxRows
    Loop
    csv.Close
    If Not out Is Nothing Then out.Close

End Sub
```

## cls_logger

```
Option Explicit
Private Sub add_to_text_file(ByVal Content As String, ByVal path As String)

    Dim Fso As New FileSystemObject
    Dim ts As TextStream
    
    Set ts = Fso.OpenTextFile(path, ForAppending)
    ts.WriteLine Content
    ts.Close
    
    Set ts = Nothing
    Set Fso = Nothing

End Sub

Private Sub save_new_text(ByVal Content As String, ByVal path As String)

    Dim Fso As New FileSystemObject
    Dim file As Object
    
    Set file = Fso.CreateTextFile(path)
    file.WriteLine Content
    file.Close
    
    Set Fso = Nothing
    Set file = Nothing

End Sub

Public Sub log_content(ByVal Content As String, Optional header As Boolean, Optional log_ut As Boolean)

    Dim Fso As New FileSystemObject
    Dim logs As String
    Dim path As String
   
    On Error GoTo ErrorHandler

    path = ThisWorkbook.FullName & "\.."
    
    If Not header Then Application.StatusBar = Content
    
    If header Then
        logs = "--------------------------- " & Content & " ---------------------------"
    Else
        If log_ut Then
            logs = Now() & ";" & Environ("UserName") & ";" & Content
        Else
            logs = Content
        End If
    End If
    
    If Not Fso.FileExists(path & "\log.txt") Then
        Call save_new_text(logs, path & "\log.txt")
    Else
        Call add_to_text_file(logs, path & "\log.txt")
    End If
    
ErrorHandler:

End Sub




```


## cls_error_handler

```
Option Explicit
Public description


Sub handle_error(ByVal my_error As ErrObject)

    Select Case my_error.Number
        Case 0
            Exit Sub
        Case 1
            Call Enabled(True)
            Call logger.log_content(Me.description)
            Call end_process_userform
            MsgBox Me.description, vbCritical
            End
        Case Else
            Call Enabled(True)
            Call logger.log_content("Error number : " & my_error.Number & " ----- Description : " & Me.description)
            Call end_process_userform

            MsgBox Me.description, vbCritical
    End Select

End Sub
```

## mapping

```
Public Function fct_BuildMapping_DicOfDic_WithClassItem() As Dictionary

    '------------------------------------------------------------------------------------
    'Création d'un dictionnaire de dictionaire ayant un objet de classe comme valeur
    
    'On stocke dans un dictionnaire pour chaque type de mapping, un dictionnaire qui a
    'pour chaque clé unique (Key_Label_NumDen) de multiples items (les filtres mapping) a
    'vec un objet de Classe cls_mapping
    '------------------------------------------------------------------------------------

    Dim str_MappingLabel_label                      As String:  str_MappingLabel_label = "Label"
    Dim str_MappingLabel_NumDem                     As String:  str_MappingLabel_NumDem = "Numerateur/ Denominateur"
    Dim str_MappingLabel_PccoSuffixe                As String:  str_MappingLabel_PccoSuffixe = "PCCO Suffixe"
    Dim str_MappingLabel_PcecReporting              As String:  str_MappingLabel_PcecReporting = "PCEC de reporting"
    Dim str_MappingLabel_PcecCalcule                As String:  str_MappingLabel_PcecCalcule = "PCEC calcule"
    Dim str_MappingLabel_TopIntExt                  As String:  str_MappingLabel_TopIntExt = "Top Int-Ext"
    Dim str_MappingLabel_Zonefiscale                As String:  str_MappingLabel_Zonefiscale = "Zone Fiscale"
    Dim str_MappingLabel_FamilleCoeffTaxation       As String:  str_MappingLabel_FamilleCoeffTaxation = "Famille Coeff Taxation"
    Dim str_MappingLabel_MethodClcCoeffTaxation     As String:  str_MappingLabel_MethodClcCoeffTaxation = "Methode Calcul Coeff Taxation"
    Dim str_MappingLabel_succursale                 As String:  str_MappingLabel_succursale = "Succursale"
    Dim str_MappingLabel_gtva                       As String:  str_MappingLabel_gtva = "GTVA"
    
    '--------------------------------------------------------------------------------------
    Dim o_cls_mapping                               As New cls_mapping
    Dim dict_type                                   As Dictionary
    Dim key_type_mapping                            As Variant
    Dim tab_mapping                                 As Variant
    Dim row_MappingLabel                            As Integer
    Dim i                                           As Integer
    Dim col_MappingLabel_CodeRubrique               As Integer
    Dim col_mapping_label                           As Integer
    Dim col_MappingLabel_NumDem                     As Integer
    Dim col_MappingLabel_PccoSuffixe                As Integer
    Dim col_MappingLabel_PcecReporting              As Integer
    Dim col_MappingLabel_PcecCalcule                As Integer
    Dim col_MappingLabel_TopIntExt                  As Integer
    Dim col_MappingLabel_Zonefiscale                As Integer
    Dim col_MappingLabel_FamilleCoeffTaxation       As Integer
    Dim col_MappingLabel_MethodClcCoeffTaxation     As Integer
    Dim col_MappingLabel_succursale                 As Integer
    Dim col_MappingLabel_gtva                       As Integer
    Dim Key_Label_NumDen                            As String
    
    Set dict_type = New Dictionary
    Set dict_mapping = New Dictionary
    
    With ws_mapping
        row_MappingLabel = .Range("rng_mapping_prorata").Row
        col_MappingLabel_CodeRubrique = Application.WorksheetFunction.Match("Code rubrique", .Rows(row_MappingLabel), 0)
        col_mapping_label = Application.WorksheetFunction.Match(str_MappingLabel_label, .Rows(row_MappingLabel), 0)
        col_MappingLabel_NumDem = Application.WorksheetFunction.Match(str_MappingLabel_NumDem, .Rows(row_MappingLabel), 0)
        col_MappingLabel_PccoSuffixe = Application.WorksheetFunction.Match(str_MappingLabel_PccoSuffixe, .Rows(row_MappingLabel), 0)
        col_MappingLabel_PcecReporting = Application.WorksheetFunction.Match(str_MappingLabel_PcecReporting, .Rows(row_MappingLabel), 0)
        col_MappingLabel_PcecCalcule = Application.WorksheetFunction.Match(str_MappingLabel_PcecCalcule, .Rows(row_MappingLabel), 0)
        col_MappingLabel_TopIntExt = Application.WorksheetFunction.Match(str_MappingLabel_TopIntExt, .Rows(row_MappingLabel), 0)
        col_MappingLabel_Zonefiscale = Application.WorksheetFunction.Match(str_MappingLabel_Zonefiscale, .Rows(row_MappingLabel), 0)
        col_MappingLabel_FamilleCoeffTaxation = Application.WorksheetFunction.Match(str_MappingLabel_FamilleCoeffTaxation, .Rows(row_MappingLabel), 0)
        col_MappingLabel_MethodClcCoeffTaxation = Application.WorksheetFunction.Match(CStr(str_MappingLabel_MethodClcCoeffTaxation), .Rows(row_MappingLabel), 0)
        col_MappingLabel_succursale = Application.WorksheetFunction.Match(str_MappingLabel_succursale, .Rows(row_MappingLabel), 0)
        col_MappingLabel_gtva = Application.WorksheetFunction.Match(str_MappingLabel_gtva, .Rows(row_MappingLabel), 0)
        
    End With

    dict_type.Add "CTF PRORATA", "rng_mapping_prorata"
    dict_type.Add "CTF Contribution", "rng_mapping_contribution"
    dict_type.Add "CTF ADAPTE", "rng_mapping_adapte"
    
    For Each key_type_mapping In dict_type.Keys
    
        Set dict_mapping_type = New Dictionary
    
        tab_mapping = ws_mapping.Range(dict_type(key_type_mapping)).CurrentRegion
        
        For i = LBound(tab_mapping, 1) + 1 To UBound(tab_mapping, 1)
            Key_Label_NumDen = CStr(tab_mapping(i, col_MappingLabel_CodeRubrique)) & "__" & CStr(tab_mapping(i, col_mapping_label)) & "__" & CStr(tab_mapping(i, col_MappingLabel_NumDem))
           'on ajoute les filtres mapping comme item
            If Not dict_mapping_type.Exists(Key_Label_NumDen) Then
               'création nouvelle objet class mapping
                Set o_cls_mapping = New cls_mapping
                o_cls_mapping.label = tab_mapping(i, col_mapping_label)
                o_cls_mapping.NumDem = tab_mapping(i, col_MappingLabel_NumDem)
                o_cls_mapping.PccoSuffixe = tab_mapping(i, col_MappingLabel_PccoSuffixe)
                o_cls_mapping.PcecReporting = tab_mapping(i, col_MappingLabel_PcecReporting)
                o_cls_mapping.PcecCalcule = tab_mapping(i, col_MappingLabel_PcecCalcule)
                o_cls_mapping.TopIntExt = tab_mapping(i, col_MappingLabel_TopIntExt)
                o_cls_mapping.Zonefiscale = tab_mapping(i, col_MappingLabel_Zonefiscale)
                o_cls_mapping.FamilleCoeffTaxation = tab_mapping(i, col_MappingLabel_FamilleCoeffTaxation)
                o_cls_mapping.MethodClcCoeffTaxation = tab_mapping(i, col_MappingLabel_MethodClcCoeffTaxation)
                o_cls_mapping.succursale = tab_mapping(i, col_MappingLabel_succursale)
                o_cls_mapping.gtva = tab_mapping(i, col_MappingLabel_gtva)
                'on ajoute la paire Key_Label_NumDen et l'object de classe avec tous les attributs
                dict_mapping_type.Add Key_Label_NumDen, o_cls_mapping
            End If
        Next i
        
        If Not dict_mapping.Exists(key_type_mapping) Then
            dict_mapping.Add key_type_mapping, dict_mapping_type
        End If
        
    Set dict_mapping_type = Nothing
    
    Next key_type_mapping
 
    Set tab_mapping = Nothing
    Set o_cls_mapping = Nothing
    Set dict_type = Nothing
    
    'Maintenant toutes les données de la table mapping sont stockée en mémoire dans un dictionaire
    'chaque élement est facilement accessible

    Set fct_BuildMapping_DicOfDic_WithClassItem = dict_mapping
    Set dict_mapping_type = Nothing
end function

Public Function fct_dict_main_mapping(ws_data_input As String) As Dictionary

    Dim k_uda_mapping               As Variant
    Dim k_type                      As Variant
    Dim k_key                       As Variant
    Dim my_tab                      As Variant
    Dim dict_mapping                As Dictionary
    Dim DicoMappingTrue             As Dictionary
    Dim dict_AmountResult           As Dictionary
    Dim dict_type_DictAmount        As Dictionary
    Dim dict_label_NumDem_amount    As Dictionary
    Dim dict_dict_TypeAmount        As Dictionary
    Dim str_UDAConcatMapping        As String
    Dim i                           As Long
    Dim mapping_matching            As Boolean

    Set dict_mapping = fct_BuildMapping_DicOfDic_WithClassItem
    Set dict_type_DictAmount = New Dictionary
    Set dict_dict_TypeAmount = New Dictionary
    
    my_tab = Load_TabInputAmount_Mapping(ws_data_input)
    
    For Each k_type In dict_mapping.Keys
    
        Set dict_label_NumDem_amount = New Dictionary
    
        For Each k_uda_mapping In dict_mapping.item(k_type).Keys
        
            Set dict_AmountResult = New Dictionary
        
            str_UDAConcatMapping = FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).PccoSuffixe)) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).PcecReporting)) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).PcecCalcule)) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).TopIntExt)) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).Zonefiscale)) & "__" & _
                        Right(FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).FamilleCoeffTaxation)), 2) & "__" & _
                        Right(FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).MethodClcCoeffTaxation)), 2) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).succursale)) & "__" & _
                        FctFillIfEmpty(CStr(dict_mapping.item(k_type).item(k_uda_mapping).gtva))
                            
            Set DicoMappingTrue = fct_DicoMappingTrue(CStr(str_UDAConcatMapping))
        
            mapping_matching = False
            For i = LBound(my_tab, 1) + 1 To UBound(my_tab, 1)
            
                For Each k_key In DicoMappingTrue.Keys
                    If InStr(Split(my_tab(i, 2), "__")(k_key), DicoMappingTrue(k_key)) <> 0 Then
                        mapping_matching = True
                    Else
                        mapping_matching = False
                        Exit For
                    End If
                Next k_key
                
                If mapping_matching = True Then
                    If Not dict_AmountResult.Exists(k_uda_mapping) Then
                        dict_AmountResult.Add k_uda_mapping, my_tab(i, 1)
                    ElseIf dict_AmountResult.Exists(k_uda_mapping) Then
                        dict_AmountResult.item(k_uda_mapping) = dict_AmountResult.item(k_uda_mapping) + my_tab(i, 1)
                    End If
                    
                End If
                
                
'                'And dict_AmountResult.Item(k_uda_mapping) > 3800000000#
'                If k_uda_mapping = "PANU1310__01A - IFAT - Contrats d'échange__Numérateur" And i = 14 Then
'                    Stop
'                    Debug.Print dict_AmountResult.Item(k_uda_mapping)
'                End If
            Next i
      
            If Not dict_label_NumDem_amount.Exists(k_uda_mapping) Then
                dict_label_NumDem_amount.Add k_uda_mapping, fct_SumDicoItems(dict_AmountResult)
            Else
                MsgBox "k_uda_mapping"
            End If
      
            'Call FctDebugDict(dict_label_NumDem_amount)
            Set dict_AmountResult = Nothing
            
        Next k_uda_mapping
        
        dict_dict_TypeAmount.Add CStr(k_type), dict_label_NumDem_amount

            Set DicoMappingTrue = Nothing
            Set dict_label_NumDem_amount = Nothing
            'Call fct_print_DictNested(dict_dict_TypeAmount, True)
            
    Next k_type
    
    'ici
    'Call fct_print_DictNested(dict_dict_TypeAmount, True)
    
    Set fct_dict_main_mapping = dict_dict_TypeAmount
    Set dict_mapping = Nothing
    Set dict_dict_TypeAmount = Nothing
    Set my_tab = Nothing
    
End Function

Public Function fct_print_DictNested(my_dict As Dictionary, Optional nested_bool = False)

    Dim my_key      As Variant
    Dim my_element  As Variant
    
    For Each my_key In my_dict.Keys
        Debug.Print my_key
        If nested_bool Then
            For Each my_element In my_dict(my_key).Keys
                Debug.Print vbTab & my_element & " : " & my_dict(my_key)(my_element)
            Next
            Debug.Print "----------"
        Else
            Debug.Print my_dict(my_key)
        End If
    Next
    
End Function

Private Function fct_DicoMappingTrue(var_mapping As String) As Dictionary

    Dim dico_temp   As Dictionary
    Dim k           As Integer
    Set dico_temp = New Dictionary

    For k = 0 To UBound(Split(var_mapping, "__"))
        If Not Split(var_mapping, "__")(k) = "NA" Then
            dico_temp.Add k, CStr(Split(var_mapping, "__")(k))
        End If
    Next k
    Set fct_DicoMappingTrue = dico_temp
    Set dico_temp = Nothing
    
End Function

Function FctFillIfEmpty(Field As Variant) As String
    Select Case CStr(Field)
        Case "O", "o", "Oui", "Y", "yes", "YES"
            FctFillIfEmpty = "oui"
        Case "N", "n", "Non", "no", "No"
            FctFillIfEmpty = "non"
        Case ""
            FctFillIfEmpty = "NA"
        Case Else
            FctFillIfEmpty = Field
    End Select
End Function

Private Function fct_SumDicoItems(dict_temp As Dictionary) As Variant
    Dim key_temp As Variant
    
    For Each key_temp In dict_temp.Keys
        fct_SumDicoItems = fct_SumDicoItems + dict_temp(key_temp)
    Next key_temp
    
End Function

Private Function Load_TabInputAmount_Mapping(ws_data_input As String) As Variant

    Dim tab_input               As Variant
    Dim key_label               As Variant
    Dim tab_input_temp          As Variant
    Dim DicoLabelInput          As Dictionary
    Dim DicoLabelMapping        As Dictionary
    Dim i                       As Long
    Dim j                       As Integer
    Dim col_InputLabel          As Integer
    Dim col_InputAmount         As Integer
    Dim col_ForMappingConcat    As Integer
 
    tab_input = Worksheets(ws_data_input).Range("B2").CurrentRegion
    Set DicoLabelInput = FctLoadDictLabel(StartCellTemp:="A2", array_type:="h", type_label:="input_CTF")
    Set DicoLabelMapping = FctLoadDictLabel(StartCellTemp:=ws_mapping.Range("rng_mapping_label").Address, array_type:="h", type_label:="mapping")

    col_InputAmount = Application.WorksheetFunction.Match("Amount", Worksheets(ws_data_input).Rows(2), 0) 'variable
    
    col_ForMappingConcat = UBound(tab_input, 2) + 1
    ReDim Preserve tab_input(1 To UBound(tab_input, 1), 1 To UBound(tab_input, 2) + 1)
    tab_input(1, col_ForMappingConcat) = "ForMappingConcat"
  
    For Each key_label In DicoLabelMapping.Keys
        If DicoLabelInput.Exists(key_label) Then
            col_InputLabel = Application.WorksheetFunction.Match(key_label, Worksheets(ws_data_input).Rows(2), 0)
        Else
            MsgBox "Le champ suivant :" & key_label & " n'existe pas dans la table des champs des inputs (n'existe pas dans la feuille data", vbCritical
        End If
        
        For i = LBound(tab_input, 1) + 1 To UBound(tab_input, 1)
            tab_input(i, col_ForMappingConcat) = tab_input(i, col_ForMappingConcat) & FctFillIfEmpty(tab_input(i, col_InputLabel)) & "__"
        Next i
    Next key_label
    
    ReDim tab_input_temp(1 To UBound(tab_input), 1 To 2)
    For i = LBound(tab_input, 1) + 1 To UBound(tab_input, 1)
        tab_input_temp(i, 1) = tab_input(i, col_InputAmount)
        tab_input_temp(i, 2) = tab_input(i, col_ForMappingConcat)
    Next i
    
    'ws_test.Range("AB1").Resize(UBound(tab_input_temp, 1), UBound(tab_input_temp, 2)).Value = tab_input_temp
    
    Load_TabInputAmount_Mapping = tab_input_temp
    
    Set tab_input = Nothing
    
    Set DicoLabelInput = Nothing
    Set DicoLabelMapping = Nothing

End Function
```