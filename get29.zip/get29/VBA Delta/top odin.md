ub DataRangeLastRowsColumns()
'Declare variables for last rows and columns
Dim LastRow As Long, LastColumn As Long
Dim LastRowSingleColumn As Long, LastRowSomeColumns As Long
Dim LastColumnSingleRow As Long, LastColumnSomeRows As Long
'Last row of data considering all columns.
LastRow = Cells.Find(What:="*", After:=Range("A1"), _
SearchOrder:=xlByRows, SearchDirection:=xlPrevious).Row
'Last row of data considering just column D.
LastRowSingleColumn = Cells(Rows.Count, 4).End(xlUp).Row
'Last row of data considering just columns B, C, and D.
LastRowSomeColumns = Range("B:D").Find(What:="*", After:=Range("B1"), _
SearchOrder:=xlByRows, SearchDirection:=xlPrevious).Row
'Last column of data considering all rows.
LastColumn = Cells.Find(What:="*", After:=Range("A1"), _
SearchOrder:=xlByColumns, SearchDirection:=xlPrevious).Column
'Last column of data considering just row 3.
LastColumnSingleRow = Cells(3, Cells.Columns.Count).End(xlToLeft).Column
'Last column of data considering just rows 1, 2, and 3.
LastColumnSomeRows = Rows("1:3").Find(What:="*", _
After:=Cells(1, Cells.Columns.Count), _
SearchOrder:=xlByColumns, SearchDirection:=xlPrevious).Column
'Advise the user of last row and column information.
MsgBox _
"Last row of data anywhere: " & LastRow & vbCrLf & _
"Last row of data in column D: " & LastRowSingleColumn & vb


Sub UnknownRange()
Dim FirstRow As Long, FirstCol As Long, LastRow As Long, LastCol As Long
Dim myUsedRange As Range
FirstRow = _
Cells.Find(What:="*", SearchDirection:=xlNext, SearchOrder:=xlByRows).Row
FirstCol = _
Cells.Find(What:="*", SearchDirection:=xlNext, SearchOrder:=xlByColumns).Column
LastRow = _
Cells.Find(What:="*", SearchDirection:=xlPrevious, SearchOrder:=xlByRows).Row
LastCol = Cells.Find(What:="*", SearchDirection:=xlPrevious, SearchOrder:=xlByColumns).Column
Set myUsedRange = Range(Cells(FirstRow, FirstCol), Cells(LastRow, LastCol))
myUsedRange.Select
MsgBox _
"The data range on this worksheet is " & _
myUsedRange.Address(0, 0) & ".", vbInformation, "Range address:"
End Sub



WARNING When you have a lot of formulas on a worksheet for which you 
want to convert all cell and range references from relative to absolute, this macro 
can do the job:
Sub ConvertRelativeToAbsolute()
Dim cell As Range, strFormulaOld As String, strFormulaNew As String
For Each cell In Cells.SpecialCells(xlCellTypeFormulas)
strFormulaOld = cell.Formula
strFormulaNew = _
Application.ConvertFormula _
(Formula:=strFormulaOld, fromReferenceStyle:=xlA1, _
toReferenceStyle:=xlA1, toAbsolute:=xlAbsolute)
cell.Formula = strFormulaNew
Next cell
End Sub
And here’s how you can convert absolute reference formulas to relative references on a worksheet:
Sub ConvertAbsoluteToRelative()
Dim cell As Range, strFormulaOld As String, strFormulaNew As String
For Each cell In Cells.SpecialCells(xlCellTypeFormulas)
strFormulaOld = cell.Formula
strFormulaNew = _
Application.ConvertFormula _
(Formula:=strFormulaOld, fromReferenceStyle:=xlA1, _
toReferenceStyle:=xlA1, toAbsolute:=xlAbsolute)
cell.Formula = WorksheetFunction.Substitute(strFormulaNew, "$", "")
Next cell
End Sub

Public Function LastUsedRowCell() As String 
 Dim lngRow As Long 
 Dim lngColumn As Long 
 lngRow = ActiveSheet.UsedRange.Rows.Count 
 lngColumn = ActiveSheet.UsedRange.Columns.Count 
 LastUsedRowCell = ActiveSheet.UsedRange.Cells(lngRow, lngColumn).End(xlToLeft). Address 
End Function 
Public Function LastUsedColumnCell() As String 
 Dim lngRow As Long 
 Dim lngColumn As Long 
 lngRow = ActiveSheet.UsedRange.Rows.Count 
 lngColumn = ActiveSheet.UsedRange.Columns.Count 
 LastUsedColumnCell = ActiveSheet.UsedRange.Cells(lngRow, lngColumn).End(xlUp). Address 
End Function 


Function MYSUM(ParamArray args() As Variant) As Variant
' Emulates Excel's SUM function
' Variable declarations
Dim i As Variant
Dim TempRange As Range, cell As Range
Dim ECode As String
Dim m, n
MYSUM = 0
' Process each argument
For i = 0 To UBound(args)
' Skip missing arguments
If Not IsMissing(args(i)) Then
' What type of argument is it?
Select Case TypeName(args(i))
Case"Range"
' Create temp range to handle full row or column ranges
Set TempRange = Intersect(args(i).Parent.UsedRange,
args(i))
For Each cell In TempRange
If IsError(cell) Then
MYSUM = cell ' return the error
Exit Function
End If
If cell = True Or cell = False Then
MYSUM = MYSUM + 0
Else
If IsNumeric(cell) Or IsDate(cell) Then _
MYSUM = MYSUM + cell
End If
Next cell
Case"Variant()"
n = args(i)
For m = LBound(n) To UBound(n)
MYSUM = MYSUM(MYSUM, n(m)) 'recursive call
Next m
Case"Null" 'ignore it
Case"Error" 'return the error
MYSUM = args(i)
Exit Function
Case"Boolean"
' Check for literal TRUE and compensate
If args(i) ="True" Then MYSUM = MYSUM + 1
Case"Date"
MYSUM = MYSUM + args(i)
Case Else
MYSUM = MYSUM + args(i)
End Select
End If
Next i
End Function

Private Sub Worksheet_SelectionChange(ByVal Target As Range)
Cells.Interior.ColorIndex = xlNone
With ActiveCell
.EntireRow.Interior.Color = RGB(219, 229, 241)
.EntireColumn.Interior.Color = RGB(219, 229, 241)
End With
End Sub

TOP

Sub CreateTOC()
Dim i As Integer
Sheets.Add Before:=Sheets(1)
For i = 2 To Worksheets.Count
ActiveSheet.Hyperlinks.Add
Anchor:=Cells(i, 1),
Address:="",
SubAddress:="'" & Worksheets(i).Name &"'!A1",
TextToDisplay:=Worksheets(i).Name
Next i
End Sub


Sub DateAndTime()
Dim TheDate As String, TheTime As String
Dim Greeting As String
Dim FullName As String, FirstName As String
Dim SpaceInName As Long
TheDate = Format(Date,"Long Date")
TheTime = Format(Time,"Medium Time")
' Determine greeting based on time
Select Case Time
Case Is < TimeValue("12:00"): Greeting ="Good Morning,"
Case Is >= TimeValue("17:00"): Greeting ="Good Evening,"
Case Else: Greeting ="Good Afternoon,"
End Select
' Append user's first name to greeting
FullName = Application.UserName
SpaceInName = InStr(1, FullName,"", 1)
' Handle situation when name has no space
If SpaceInName = 0 Then SpaceInName = Len(FullName)
FirstName = Left(FullName, SpaceInName)
Greeting = Greeting & FirstName
' Show the message
MsgBox TheDate & vbCrLf & vbCrLf &"It's" & TheTime, vbOKOnly,
Greeting
End Sub


Function FT(t1, t2)
Dim SDif As Double, DDif As Double
If Not (IsDate(t1) And IsDate(t2)) Then
FT = CVErr(xlErrValue)
Exit Function
End If
DDif = Abs(t2 - t1)
SDif = DDif * 24 60 60
If DDif < 1 Then
If SDif < 10 Then FT ="Just now": Exit Function
If SDif < 60 Then FT = SDif &" seconds ago": Exit Function
If SDif < 120 Then FT ="a minute ago": Exit Function
If SDif < 3600 Then FT = Round(SDif 60, 0) &"minutes ago":
Exit Function
If SDif < 7200 Then FT ="An hour ago": Exit Function
If SDif < 86400 Then FT = Round(SDif 3600, 0) &" hours ago":
Exit Function End If
If DDif = 1 Then FT ="Yesterday": Exit Function
If DDif < 7 Then FT = Round(DDif, 0) &" days ago": Exit
Function
If DDif < 31 Then FT = Round(DDif 7, 0) &" weeks ago": Exit
Function
If DDif < 365 Then FT = Round(DDif 30, 0) &" months ago": Exit
Function
FT = Round(DDif / 365, 0) &" years ago"
End Function


Private Function RangeNameExists(nname) As Boolean
' Returns TRUE if the range name exists
Dim n As Name
RangeNameExists = False
For Each n In ActiveWorkbook.Names
If UCase(n.Name) = UCase(nname) Then
RangeNameExists = True
Exit Function
End If
Next n
End Function

adOpenForwardOnly: This is the default setting; if you don’t specify a
CursorType, the Recordset will automatically be adOpenForwardOnly. This
CursorType is the most efficient type because it only allows you to move
through the Recordset one way: from beginning to end. This is ideal for
reporting processes where data only needs to be retrieved and not traversed.
Keep in mind that you cannot make changes to data when using this
CursorType.
adOpenDynamic: This CursorType is typically used in processes where
there is a need for looping, moving up and down through the dataset, or the
ability to dynamically see any edits made to the dataset. This CursorType is
typically memory-and resource-intensive and should be used only when
needed.
adOpenStatic: This CursorType is ideal for the quick return of results as it
essentially returns a snapshot of your data. However, this is different from
the adOpenForwardOnly CursorType as it allows you to navigate the returned
records. In addition, when using this CursorType, the data returned can be
made updateable by setting its LockType to something other than
adLockReadOnly.



Function FileExists3(fname) As Boolean
Dim FileSys As Object 'FileSystemObject
Set FileSys = CreateObject("Scripting.FileSystemObject")
FileExists3 = FileSys.FileExists(fname)
End Function


Function PathExists2(path) As Boolean
Dim FileSys As Object 'FileSystemObject
Set FileSys = CreateObject("Scripting.FileSystemObject")
PathExists2 = FileSys.FolderExists(path)
End Function


Sub ZipFiles()
Dim ShellApp As Object
Dim FileNameZip As Variant
Dim FileNames As Variant
Dim i As Long, FileCount As Long
' Get the file names
FileNames = Application.GetOpenFilename _
(FileFilter:="All Files (.),.",
FilterIndex:=1,
Title:="Select the files to ZIP",
MultiSelect:=True)
' Exit if dialog box canceled
If Not IsArray(FileNames) Then Exit Sub
FileCount = UBound(FileNames)
FileNameZip = Application.DefaultFilePath &"\compressed.zip"
'Create empty Zip File with zip header
Open FileNameZip For Output As #1
Print #1, Chr$(80) & Chr$(75) & Chr$(5) & Chr$(6) & String(18,
0)
Close #1
Set ShellApp = CreateObject("Shell.Application")
'Copy the files to the compressed folder
For i = LBound(FileNames) To UBound(FileNames)
ShellApp.Namespace(FileNameZip).CopyHere FileNames(i)
'Keep script waiting until Compressing is done On Error
Resume Next
Do Until ShellApp.Namespace(FileNameZip).items.Count = i
Application.Wait (Now + TimeValue("0:00:01"))
Loop
Next i
If MsgBox(FileCount &" files were zipped to:" &
vbNewLine & FileNameZip & vbNewLine & vbNewLine &
"View the zip file?", vbQuestion + vbYesNo) = vbYes Then
Shell"Explorer.exe /e," & FileNameZip, vbNormalFocus
End Sub

Sub UnzipAFile()
Dim ShellApp As Object
Dim TargetFile
Dim ZipFolder
' Target file & temp dir
TargetFile = Application.GetOpenFilename
(FileFilter:="Zip Files (*.zip), *.zip")
If TargetFile = False Then Exit Sub
ZipFolder = Application.DefaultFilePath &"\Unzipped\"
' Create a temp folder On Error Resume Next
RmDir ZipFolder
MkDir ZipFolder
On Error GoTo 0
' Copy the zipped files to the newly created folder
Set ShellApp = CreateObject("Shell.Application")
ShellApp.Namespace(ZipFolder).CopyHere
ShellApp.Namespace(TargetFile).items
If MsgBox("The files was unzipped to:" &
vbNewLine & ZipFolder & vbNewLine & vbNewLine &
"View the folder?", vbQuestion + vbYesNo) = vbYes Then _
Shell"Explorer.exe /e," & ZipFolder, vbNormalFocus
End Sub


Sub YourMethodName()
 On Error GoTo errorHandler
 ' Insert code here
 On Error GoTo secondErrorHandler
 Exit Sub 'The exit sub line is essential, as the code will otherwise
 'continue running into the error handling block, likely causing an error
errorHandler:
 MsgBox "Error " & Err.Number & ": " & Err.Description & " in " & _
 VBE.ActiveCodePane.CodeModule, vbOKOnly, "Error"
 Exit Sub
secondErrorHandler:
 If Err.Number = 424 Then 'Object not found error (purely for illustration)
 Application.ScreenUpdating = True
 Application.EnableEvents = True
 Exit Sub
 Else
 MsgBox "Error " & Err.Number & ": " & Err.Desctription
 Application.ScreenUpdating = True
 Application.EnableEvents = True 
 Exit Sub
 End If 
 Exit Sub
End Sub

***
Sub FindJPGFilesInAFolder()
Dim fso As Object
Dim strName As String
Dim strArr(1 To 1048576, 1 To 1) As String, i As Long
' Enter the folder name here
Const strDir As String = "C:\Artwork\"
strName = Dir$(strDir & "*.jpg")
Do While strName <> vbNullString
i = i + 1
strArr(i, 1) = strDir & strName
strName = Dir$()
Loop
Set fso = CreateObject("Scripting.FileSystemObject")
Call recurseSubFolders(fso.GetFolder(strDir),
strArr(), i)
Set fso = Nothing
If i > 0 Then
Range("A1").Resize(i).Value = strArr
End If
' Next, loop through all found files
' and break into path and filename
FinalRow = Cells(Rows.Count, 1).End(xlUp).Row
For i = 1 To FinalRow
ThisEntry = Cells(i, 1)
For j = Len(ThisEntry) To 1 Step -1
If Mid(ThisEntry, j, 1) =
Application.PathSeparator Then
Cells(i, 2) = Left(ThisEntry, j)
Cells(i, 3) = Mid(ThisEntry, j + 1)
Exit For
End If
Next j
Next i
End Sub
Private Sub recurseSubFolders(ByRef Folder As Object, _
ByRef strArr() As String, _
ByRef i As Long)
Dim SubFolder As Object
Dim strName As String
For Each SubFolder In Folder.SubFolders
strName = Dir$(SubFolder.Path & "*.jpg")
Do While strName <> vbNullString
i = i + 1
strArr(i, 1) = SubFolder.Path & strName
strName = Dir$()
Loop
Call recurseSubFolders(SubFolder, strArr(), i)
Next
End Sub

Sub ExcelFileSearch()
Dim srchExt As Variant, srchDir As Variant
Dim i As Long, j As Long, strName As String
Dim varArr(1 To 1048576, 1 To 3) As Variant
Dim strFileFullName As String
Dim ws As Worksheet
Dim fso As Object
Let srchExt = Application.InputBox("Please Enter File Extension",
"Info Request")
If srchExt = False And Not TypeName(srchExt) = "String" Then
Exit Sub
End If
Let srchDir = BrowseForFolderShell
If srchDir = False And Not TypeName(srchDir) = "String" Then
Exit Sub
End If
Application.ScreenUpdating = False
Set ws = ThisWorkbook.Worksheets.Add(Sheets(1))
On Error Resume Next
Application.DisplayAlerts = False
ThisWorkbook.Worksheets("FileSearch Results").Delete
Application.DisplayAlerts = True
On Error GoTo 0
ws.Name = "FileSearch Results"
Let strName = Dir$(srchDir & "\*" & srchExt)
Do While strName <> vbNullString
Let i = i + 1
Let strFileFullName = srchDir & strName
Let varArr(i, 1) = strFileFullName
Let varArr(i, 2) = FileLen(strFileFullName) \ 1024
Let varArr(i, 3) = FileDateTime(strFileFullName)
Let strName = Dir$()
Loop
Set fso = CreateObject("Scripting.FileSystemObject")
Call recurseSubFolders(fso.GetFolder(srchDir), varArr(), i,
CStr(srchExt))
Set fso = Nothing
ThisWorkbook.Windows(1).DisplayHeadings = False
With ws
If i > 0 Then
.Range("A2").Resize(i, UBound(varArr, 2)).Value = varArr
For j = 1 To i
.Hyperlinks.Add anchor:=.Cells(j + 1, 1),
Address:=varArr(j, 1)
Next
End If
.Range(.Cells(1, 4), .Cells(1,
.Columns.Count)).EntireColumn.Hidden = True
.Range(.Cells(.Rows.Count, 1).End(xlUp)(2), _
.Cells(.Rows.Count, 1)).EntireRow.Hidden = True
With .Range("A1:C1")
.Value = Array("Full Name", "Kilobytes", "Last Modified")
.Font.Underline = xlUnderlineStyleSingle
.EntireColumn.AutoFit
.HorizontalAlignment = xlCenter
End With
End With
Application.ScreenUpdating = True
End Sub
Private Sub recurseSubFolders(ByRef Folder As Object, _
ByRef varArr() As Variant, _
ByRef i As Long, _
ByRef srchExt As String)
Dim SubFolder As Object
Dim strName As String, strFileFullName As String
For Each SubFolder In Folder.SubFolders
Let strName = Dir$(SubFolder.Path & "\*" & srchExt)
Do While strName <> vbNullString
Let i = i + 1
Let strFileFullName = SubFolder.Path & "\" & strName
Let varArr(i, 1) = strFileFullName
Let varArr(i, 2) = FileLen(strFileFullName) \ 1024
Let varArr(i, 3) = FileDateTime(strFileFullName)
Let strName = Dir$()
Loop
If i > 1048576 Then Exit Sub
Call recurseSubFolders(SubFolder, varArr(), i, srchExt)
Next
End Sub
Private Function BrowseForFolderShell() As Variant
Dim objShell As Object, objFolder As Object
Set objShell = CreateObject("Shell.Application")
Set objFolder = objShell.BrowseForFolder(0, "Please select a folder",
0, "C:\")
If Not objFolder Is Nothing Then
On Error Resume Next
If IsError(objFolder.Items.Item.Path) Then
BrowseForFolderShell = CStr(objFolder)
Else
On Error GoTo 0
If Len(objFolder.Items.Item.Path) > 3 Then
BrowseForFolderShell = objFolder.Items.Item.Path & _
Application.PathSeparator
Else
BrowseForFolderShell = objFolder.Items.Item.Path
End If
End If
Else
BrowseForFolderShell = False
End If
Set objFolder = Nothing: Set objShell = Nothing
End Function

Sub OpenLargeCSVFast()
Dim buf(1 To 16384) As Variant
Dim i As Long
'Change the file location and name here
Const strFilePath As String = "C:\temp\Sales.CSV"
Dim strRenamedPath As String
strRenamedPath = Split(strFilePath, ".")(0) & "txt"
With Application
.ScreenUpdating = False
.DisplayAlerts = False
End With
'Setting an array for FieldInfo to open CSV
For i = 1 To 16384
buf(i) = Array(i, 2)
Next
Name strFilePath As strRenamedPath
Workbooks.OpenText Filename:=strRenamedPath,
DataType:=xlDelimited, _
Comma:=True, FieldInfo:=buf
Erase buf
ActiveSheet.UsedRange.Copy ThisWorkbook.Sheets(1).Range("A1")
ActiveWorkbook.Close False
Kill strRenamedPath
With Application
.ScreenUpdating = True
.DisplayAlerts = True
End With
End Sub

Sub CombineWorkbooks()
Dim CurFile As String, DirLoc As String
Dim DestWB As Workbook
Dim ws As Object 'allows for different sheet types
DirLoc = ThisWorkbook.Path & "\tst\" 'location of files
CurFile = Dir(DirLoc & ".xls")
Application.ScreenUpdating = False
Application.EnableEvents = False
Set DestWB = Workbooks.Add(xlWorksheet)
Do While CurFile <> vbNullString
Dim OrigWB As Workbook
Set OrigWB = Workbooks.Open(Filename:=DirLoc & CurFile,
ReadOnly:=True)
' Limit to valid sheet names and removes .xls*
CurFile = Left(Left(CurFile, Len(CurFile) - 5), 29)
For Each ws In OrigWB.Sheets
ws.Copy After:=DestWB.Sheets(DestWB.Sheets.Count)
If OrigWB.Sheets.Count > 1 Then
DestWB.Sheets(DestWB.Sheets.Count).Name = CurFile &
ws.Index
Else
DestWB.Sheets(DestWB.Sheets.Count).Name = CurFile
End If
Next
OrigWB.Close SaveChanges:=False
CurFile = Dir
Loop
Application.DisplayAlerts = False
DestWB.Sheets(1).Delete
Application.DisplayAlerts = True
Application.ScreenUpdating = True
Application.EnableEvents = True
Set DestWB = Nothing
End Sub


Public Sub QuickSort(ByRef vntArr As Variant,
Optional ByVal lngLeft As Long = -2, _
Optional ByVal lngRight As Long = -2)
Dim i, j, lngMid As Long
Dim vntTestVal As Variant
If lngLeft = -2 Then lngLeft = LBound(vntArr)
If lngRight = -2 Then lngRight = UBound(vntArr)
If lngLeft < lngRight Then
lngMid = (lngLeft + lngRight) \ 2
vntTestVal = vntArr(lngMid)
i = lngLeft
j = lngRight
Do
Do While vntArr(i) < vntTestVal
i = i + 1
Loop
Do While vntArr(j) > vntTestVal
j = j - 1
Loop
If i <= j Then
Call SwapElements(vntArr, i, j)
i = i + 1
j = j - 1
End If
Loop Until i > j
If j <= lngMid Then
Call QuickSort(vntArr, lngLeft, j)
Call QuickSort(vntArr, i, lngRight)
Else
Call QuickSort(vntArr, i, lngRight)
Call QuickSort(vntArr, lngLeft, j)
End If
End If
End Sub
Private Sub SwapElements(ByRef vntItems As Variant, _
ByVal lngItem1 As Long, _
ByVal lngItem2 As Long)
Dim vntTemp As Variant
vntTemp = vntItems(lngItem2)
vntItems(lngItem2) = vntItems(lngItem1)
vntItems(lngItem1) = vntTemp
End Sub

unction dhIsCharAlphaNumeric(strText As String) As Boolean
 ' Is the first character of strText an alphanumeric character?
 dhIsCharAlphaNumeric = CBool(IsCharAlphaNumericA(Asc(strText)))
End Function

Function dhIsCharNumeric1(strText As String) As Boolean
 ' Is the first character numeric?
 ' Almost identical in speed to calling the two API functions.
 dhIsCharNumeric1 = (strText Like "[0-9]*")
End Function



Public Function dhCountIn(strText As String, strFind As String, _
 Optional lngCompare As VbCompareMethod = vbBinaryCompare) As Long
 Dim lngCount As Long
 Dim lngPos As Long
 
 ' If there's nothing to find, there surely can't be any
 ' found, so return 0.
 If Len(strFind) > 0 Then
 lngPos = 1
 Do
 lngPos = InStr(lngPos, strText, strFind, lngCompare)
 If lngPos > 0 Then
 lngCount = lngCount + 1
 lngPos = lngPos + Len(strFind)
 End If
 Loop While lngPos > 0
 Else
 lngCount = 0
 End If
 dhCountIn = lngCount
End Function
Of course, if there’s nothing to find, the function just returns 0:
If Len(strFind) > 0 Then
 ' the real code goes here
Else
 intCount = 0
End If

Public Function dhCountWords(ByVal strText As String) As Long
 If Len(strText) = 0 Then
 dhCountWords = 0
 Else
 ' Get rid of any extraneous stuff, including delimiters and
 ' spaces. First convert delimiters to spaces, and then
 ' remove all extraneous spaces.
 strText = dhTrimAll(dhTranslate(strText, dhcDelimiters, " "))
 ' If there are three spaces, there are
 ' four words, right?
 dhCountWords = dhCountIn(strText, " ") + 1
 End If
End Function



Public Function dhSoundex(ByVal strIn As String) As String
 
 Dim strOut As String
 Dim intI As Integer
 Dim intPrev As Integer
 Dim strChar As String * 1
 Dim intChar As Integer
 Dim blnPrevSeparator As Boolean
 Dim intPos As Integer
 
 strOut = String(dhcLen, "0")
 strIn = UCase(strIn)
 blnPrevSeparator = False
 
 strChar = Left$(strIn, 1)
 intPrev = CharCode(strChar)
 Mid$(strOut, 1, 1) = strChar
 
 intPos = 1
 For intI = 2 To Len(strIn)
 ' If the output string is full, quit now.
 If intPos >= dhcLen Then
 Exit For
 End If
 ' Get each character, in turn. If the
 ' character's a letter, handle it.
 strChar = Mid$(strIn, intI, 1)
 If dhIsCharAlpha(strChar) Then
 ' Convert the character to its code.
 intChar = CharCode(strChar)
 
 ' If the character's not empty, and if it's not
 ' the same as the previous character, tack it
 ' onto the end of the string.
 If (intChar > 0) Then
 If blnPrevSeparator Or (intChar <> intPrev) Then
 intPos = intPos + 1
 Mid$(strOut, intPos, 1) = intChar
 intPrev = intChar
 End If
 End If
 blnPrevSeparator = (intChar = 0)
 End If
 Next intI
 dhSoundex = strOut
End Function


Public Function dhSoundsLike(ByVal strItem1 As String, _
 ByVal strItem2 As String, _
 Optional blnIsSoundex As Boolean = False) As Integer
 Dim intI As Integer
 
 If Not blnIsSoundex Then
 strItem1 = dhSoundex(strItem1)
 strItem2 = dhSoundex(strItem2)
 End If
 For intI = 1 To dhcLen
 If Mid$(strItem1, intI, 1) <> Mid$(strItem2, intI, 1) Then
 Exit For
 End If
 Next intI
 dhSoundsLike = (intI - 1)
End Function


Public Function dhExtractString(ByVal strIn As String, _
 ByVal intPiece As Integer, _
 Optional ByVal strDelimiter As String = dhcDelimiters) As String
 
 Dim lngPos As Long
 Dim lngPos1 As Long
 Dim lngLastPos As Long
 Dim intLoop As Integer
 lngPos = 0
 lngLastPos = 0
 intLoop = intPiece
 ' If there's more than one delimiter, map them
 ' all to the first one.
 If Len(strDelimiter) > 1 Then
 strIn = dhTranslate(strIn, strDelimiter, _
 Left$(strDelimiter, 1))
 End If
 strIn = dhTrimAll (strIn)
 Do While intLoop > 0
 lngLastPos = lngPos
 lngPos1 = InStr(lngPos + 1, strIn, Left$(strDelimiter, 1))
 If lngPos1 > 0 Then
 lngPos = lngPos1
 intLoop = intLoop - 1
 Else
 lngPos = Len(strIn) + 1
 Exit Do
 End If
 Loop
 ' If the string wasn't found, and this wasn't
 ' the first pass through (intLoop would equal intPiece
 ' in that case) and intLoop > 1, then you've run
 ' out of chunks before you've found the chunk you
 ' want. That is, the chunk number was too large.
 ' Return "" in that case.
 If (lngPos1 = 0) And (intLoop <> intPiece) And (intLoop > 1) Then
 dhExtractString = vbNullString
 Else
 dhExtractString = Mid$(strIn, lngLastPos + 1, _
 lngPos - lngLastPos - 1)
 End If
End Function

Public Function dhFirstWord( _
 ByVal strText As String, _
 Optional ByRef strRest As String = "") As String
 
 Dim strTemp As String
 
 ' This is easy!
 ' Get the first word.
 strTemp = dhExtractString(strText, 1)
 
 ' Extract everything after the first word,
 ' and put that into strRest.
 strRest = Mid$(strText, Len(strTemp) + 1)
 
 ' Return the first word.
 dhFirstWord = strTemp
End Function


Public Function dhRound( _
 ByVal Number As Variant, NumDigits As Long, _
 Optional UseIEEERounding As Boolean = False) As Double
 ' Rounds a number to a specified number of decimal
 ' places. 0.5 is rounded up
 
 Dim dblPower As Double
 Dim varTemp As Variant
 Dim intSgn As Integer
 
 If Not IsNumeric(Number) Then
 ' Raise an error indicating that
 ' you've supplied an invalid parameter.
 Err.Raise 5
 End If
 dblPower = 10 ^ NumDigits
 ' Is this a negative number, or not?
 ' intSgn will contain -1, 0, or 1.
 intSgn = Sgn(Number)
 Number = Abs(Number)
 
 ' Do the major calculation.
 varTemp = CDec(Number) * dblPower + 0.5
 
 ' Now round to nearest even, if necessary.
 If UseIEEERounding Then
 If Int(varTemp) = varTemp Then
 ' You could also use:
 ' varTemp = varTemp + (varTemp Mod 2 = 1)
 ' instead of the next If ...Then statement,
' but we hate counting on True == -1 in code.
 If varTemp Mod 2 = 1 Then
 varTemp = varTemp - 1
 End If
 End If
 End If
 ' Finish the calculation.
 dhRound = intSgn * Int(varTemp) / dblPower
End Function


Public Function dhRandomShuffle(Optional lngItems As Long = 10) _
 As Long()
 Dim alngValues() As Long
 Dim i As Long
 Dim lngPos As Long
 Dim lngTemp As Long
 
 ReDim alngValues(1 To lngItems)
 ' Fill in the original values.
 For i = 1 To lngItems
 alngValues(i) = i
 Next i
 
 ' Loop through all the items except the last one.
 ' Once you get to the last item, there's no point
 ' using Rnd, just get it.
 For i = lngItems To 2 Step -1
 ' Get a random number between 1 and i
 lngPos = Int(Rnd * i) + 1
 lngTemp = alngValues(lngPos)
 alngValues(lngPos) = alngValues(i)
 alngValues(i) = lngTemp
 Next i
 dhRandomShuffle = alngValues()
End Function


Public Function dhCalcPayment(ByVal dblRate As Double, _
 ByVal intNoPmts As Integer, _
 ByVal curPresentValue As Currency, _
 Optional varFutureVal As Variant = 0, _
 Optional varWhenDue As Variant = 0) As Double
 ' Calculates payments using Pmt function
 If varWhenDue <> 0 Then
 ' set to only other possible value
 ' of 1 indicating payment to occur
 ' at beginning of period
 varWhenDue = 1
 End If
 dhCalcPayment = Pmt((dblRate / 12), intNoPmts, _
 -CDbl(curPresentValue), varFutureVal, varWhenDue)
End Function

Public Function dhNetPresentValue(ByVal dblRate As Double, _
 ParamArray varCashFlows()) As Double
 ' Calculates net present value
 Dim varElement As Variant
 Dim i As Integer
 Dim lngUBound As Long
 Static dblValues() As Double
 
 ' get upper bound of ParamArray
 lngUBound = UBound(varCashFlows)
 ' size array to ParamArray
 ReDim dblValues(lngUBound)
 i = 0
 ' place elements of ParamArray into Array
 For Each varElement In varCashFlows
 dblValues(i) = varElement
 i = i + 1
 Next
 dhNetPresentValue = NPV(dblRate, dblValues())
End Function

Public Function dhArrayAverage(varArray As Variant) As Variant
 Dim varItem As Variant
 Dim varSum As Variant
 Dim lngCount As Long
 If IsArray(varArray) Then
 For Each varItem In varArray
 varSum = varItem + varSum
 lngCount = lngCount + 1
 Next
 dhArrayAverage = varSum / lngCount
 Else
 dhArrayAverage = Null
 End If
End Function


Public Function dhArrayMedian(varArray As Variant) As Variant
 Dim varItem As Variant
 Dim varTemp As Variant
 Dim varMedian As Variant
 Dim intI As Integer
 Dim lngTemp As Long
 Dim lngLBound As Long
 Dim lngElements As Long
 If IsArray(varArray) Then
 ' Sort the array
 Call dhQuickSort(varArray)
 ' Compute the number of array elements
 ' and the index of the "middle" one
 lngLBound = LBound(varArray)
 lngElements = (UBound(varArray) - lngLBound + 1)
 ' Find the midpoint in the array. For an odd
 ' number of elements, this is easy (it’s the
 ' middle one)...
 If (lngElements Mod 2) = 1 Then
 dhArrayMedian = varArray(lngLBound + _
 (lngElements \ 2))
 Else
 ' For an even number of elements, it’s the
 ' midpoint between the two middle values...
 lngTemp = ((lngElements - 1) \ 2) + lngLBound
 dhArrayMedian = ((varArray(lngTemp + 1) - _
 varArray(lngTemp)) / 2) + varArray(lngTemp)
 End If
 Else
 dhArrayMedian = Null
 End If
End Function



 
 
Public Function dhArrayStandardDeviation(varArray As Variant) As Double
 Dim lngN As Long
 Dim dblSumX As Double
 Dim dblSumX2 As Double
 Dim dblVar As Double
 Dim intCounter As Integer
 lngN = 0
 dblSumX = 0
 dblSumX2 = 0
 For intCounter = LBound(varArray) To UBound(varArray)
 If Not IsNull(varArray(intCounter)) Then
 lngN = lngN + 1
 dblSumX = dblSumX + varArray(intCounter)
 dblSumX2 = dblSumX2 + varArray(intCounter) ^ 2
 End If
 Next intCounter
 
 dblVar = 0
 If lngN > 0 Then
 dblVar = (lngN * dblSumX2 - dblSumX ^ 2) / (lngN * (lngN - 1))
 If dblVar > 0 Then
 dhArrayStandardDeviation = Sqr(dblVar)
 End If
 End If
End Function


Function dhArrayMax(varArray As Variant) As Variant
 ' Return the maximum value from an array
 Dim varItem As Variant
 Dim varMax As Variant
 Dim i As Long
 
 If IsArray(varArray) Then
 If UBound(varArray) = -1 Then
 dhArrayMax = Null
 Else
 varMax = varArray(UBound(varArray))
 For i = LBound(varArray) To UBound(varArray)
 varItem = varArray(i)
 If varItem > varMax Then
 varMax = varItem
 End If
 Next i
 dhArrayMax = varMax
 End If
 Else
 dhArrayMax = Null
 End If
End Function

Function dhArrayMin(varArray As Variant) As Variant
 ' Return the minimum value from an array
 
 Dim varItem As Variant
 Dim varMin As Variant
 Dim i As Long
 
 If IsArray(varArray) Then
 If UBound(varArray) = -1 Then
 dhArrayMin = Null
 Else
 varMin = varArray(LBound(varArray))
 For i = LBound(varArray) To UBound(varArray)
 varItem = varArray(i)
  If varItem < varMin Then
 varMin = varItem
 End If
 Next i
 dhArrayMin = varMin
 End If
 Else
 dhArrayMin = varArray
 End If
End Function


Public Function dhFirstDayInMonth(Optional dtmDate As Date = 0) As Date
 ' Return the first day in the specified month.
 
 ' Did the caller pass in a date? If not, use
 ' the current date.
 If dtmDate = 0 Then
 dtmDate = Date
 End If
 
 dhFirstDayInMonth = DateSerial( _
 Year(dtmDate), Month(dtmDate), 1)
End Function
Public Function dhLastDayInMonth(Optional dtmDate As Date = 0) As Date
 ' Return the last day in the specified month.
 
 ' Did the caller pass in a date? If not, use
 ' the current date.
 If dtmDate = 0 Then
 dtmDate = Date
 End If
 
 dhLastDayInMonth = DateSerial( _
 Year(dtmDate), Month(dtmDate) + 1, 0)
End Function

Public Function dhCNumDate(ByVal lngdate As Long, _
 ByVal strFormat As String) As Variant
 ' Convert numbers to dates, depending on the specified format
 ' and the incoming number. In this case, the number and the
 ' format must match, or the output will be useless.
 
 Dim intYear As Integer
 Dim intMonth As Integer
 Dim intDay As Integer
 
 Select Case strFormat
 Case "MMDDYY"
 intYear = lngdate Mod 100
 intMonth = lngdate \ 10000
 intDay = (lngdate \ 100) Mod 100
 
 Case "MMDDYYYY"
 intYear = lngdate Mod 10000
 intMonth = lngdate \ 1000000
 intDay = (lngdate \ 10000) Mod 100
 
 Case "DDMMYY"
 intYear = lngdate Mod 100
 intMonth = (lngdate \ 100) Mod 100
 intDay = lngdate \ 10000
 
 Case "DDMMYYYY"
 intYear = lngdate Mod 10000
 intMonth = (lngdate \ 10000) Mod 100
 intDay = lngdate \ 1000000
  Case "YYMMDD", "YYYYMMDD"
 intYear = lngdate \ 10000
 intMonth = (lngdate \ 100) Mod 100
 intDay = lngdate Mod 100
 
 Case Else
 ' Raise an error and get out.
 ' Error 5 normally indicates an invalid parameter.
 Err.Raise 5, "dhCNumDate", "Invalid parameter"
 End Select
 dhCNumDate = DateSerial(intYear, intMonth, intDay)
End Function


Public Function dhCStrDate( _
 strDate As String, Optional strFormat As String = "") As Date
 
 ' Given a string containing a date value, and a format
 ' string describing the information in the date string,
 ' convert the string into a real date value.
 '
 Dim strYear As String
 Dim strMonth As String
 Dim strDay As String
 
 Select Case strFormat
 Case "MMDDYY", "MMDDYYYY"
 strYear = Mid$(strDate, 5)
 strMonth = Left$(strDate, 2)
 strDay = Mid$(strDate, 3, 2)
  Case "DDMMYY", "DDMMYYYY"
 strYear = Mid$(strDate, 5)
 strMonth = Mid$(strDate, 3, 2)
 strDay = Left$(strDate, 2)
 
 Case "YYMMDD"
 strYear = Left$(strDate, 2)
 strMonth = Mid$(strDate, 3, 2)
 strDay = Right$(strDate, 2)
 
 Case "YYYYMMDD"
 strYear = Left$(strDate, 4)
 strMonth = Mid$(strDate, 5, 2)
 strDay = Right$(strDate, 2)
 
 Case "DD/MM/YY", "DD/MM/YYYY"
 strYear = Mid$(strDate, 7)
 strMonth = Mid$(strDate, 4, 2)
 strDay = Left$(strDate, 2)
 
 Case "YY/MM/DD"
 strYear = Left$(strDate, 2)
 strMonth = Mid$(strDate, 4, 2)
 strDay = Right$(strDate, 2)
 
 Case "YYYY/MM/DD"
 strYear = Left$(strDate, 4)
 strMonth = Mid$(strDate, 6, 2)
 strDay = Right$(strDate, 2)
 
 Case Else
 ' If none of the other formats were matched, raise
 ' an error and get out.
 Err.Raise 5, "dhCStrDate", "Invalid parameter"
 End Select
 dhCStrDate = DateSerial(Val(strYear), Val(strMonth), Val(strDay))
End Function


dhBinarySearch to Find a Value in a Sorted Array. 
(BinarySearch.bas)
Function dhBinarySearch( _
 varItems As Variant, varSought As Variant) As Long
 Dim lngLower As Long
 Dim lngMiddle As Long
 Dim lngUpper As Long
 
 lngLower = LBound(varItems)
 lngUpper = UBound(varItems)
 Do While lngLower < lngUpper
 ' Increase lower and decrease upper boundary,
 ' keeping varSought in range, if it's there at all.
 lngMiddle = (lngLower + lngUpper) \ 2
 If varSought > varItems(lngMiddle) Then
 lngLower = lngMiddle + 1
 Else
 lngUpper = lngMiddle
 End If
 Loop
 If varItems(lngLower) = varSought Then
 dhBinarySearch = lngLower
 Else
 dhBinarySearch = -1
 End If
End Function